/*
 * tusb_config.h
 *
 *  Created on: Mar 14, 2026
 *      Author: Andrew
 */

#ifndef INC_TUSB_CONFIG_H_
#define INC_TUSB_CONFIG_H_


#pragma once

#define CFG_TUSB_MCU                OPT_MCU_STM32F1
#define CFG_TUSB_RHPORT0_MODE       (OPT_MODE_DEVICE | OPT_MODE_FULL_SPEED)

#define CFG_TUD_ENDPOINT0_SIZE      64

#define CFG_TUD_VENDOR              1
#define CFG_TUD_VENDOR_RX_BUFSIZE   64
#define CFG_TUD_VENDOR_TX_BUFSIZE   64
#define CFG_TUSB_OS   OPT_OS_NONE   /*no operating system*/


#endif /* INC_TUSB_CONFIG_H_ */

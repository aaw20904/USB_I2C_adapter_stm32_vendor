/*
 * packetize.c
 *
 *  Created on: Mar 6, 2026
 *      Author: Andrew
 */

#include "circ_fifo.h"
#include "packetize.h"
#include <string.h>




/*old functions*/
/*
int packetParcer (packet_params *pars) {
	 int32_t payloadLen;
     int32_t dataAval = ring_available(&fifoHeaderGl);
	if (dataAval >= 4) {
		//when packet length have been already received
          ring_peek(&fifoHeaderGl, (uint8_t*)pars, 4);
        ///-------
		if (dataAval >= pars->packet_length ) {
            ///drain copied later data (packet info)
			   ring_drain(&fifoHeaderGl, 4);
               payloadLen = pars->packet_length-4;
			//when full packet was received - copy data directly into a buffer
             ring_pop(&fifoHeaderGl, pars->data, payloadLen);
			//- return packet length
			return 0;
		}
		return -1;
	}
	return -1;
}

*/
//NOTE: no need a buffer inside the pars, the data only copying from "payload" to the "packet store"
int assemblyPacketInRam (packet_params *pars, uint8_t* payload, uint8_t* packetStore, uint16_t dataLen, uint8_t command, int8_t flags) {
    //type of command, flags, packet size
    dataLen += 4;
    pars->type_of_command = command;
    pars->flags = flags;
    pars->packet_length = dataLen;
    packetStore[0] = command;
    packetStore[1] = flags;
    packetStore[2] = dataLen & 0x00ff;
    packetStore[3] = (dataLen & 0xff00) >> 8;

    if (dataLen > 0){
        memcpy(packetStore+4, payload, dataLen-4);
    }
    return 0;

}



/* new functions**/
/*                |              [  LOW byte| HI byte ]
{ uint8_t COMMAND | uint8_t FLAGS| uint16_t PACKET_LEN| DATA }

*/

/*This function is NON blocking, and statefull
A)- IDLE
B)- ASSEMBLY
C)- DONE


enum packetizerStates {
 PACK_IDLE,
 PACK_ASSEMBLY,
 PACK_DONE
};
*/

int packetParser ( uint8_t* from, packet_params* head, int available ) {
  static int appState = 0;
  switch (appState) {
  case PACK_IDLE:
        //1)Have the header been arrived?
        if (available >= 4) {
             //parse - flags
             head->type_of_command = *from; //first byte
             head->flags = *(from + 1);  //second byte
             head->packet_length = from[2] | (from[3] << 8); //[ 3-LOW | 4-HIGH ]
             //2)is a packet empty (line acknowledge/status)?
             if ((head->packet_length - 4) == 0) {
                //when there are no payload - returns immediately
                appState = PACK_IDLE;
                return PACK_DONE;
             }
             appState = PACK_ASSEMBLY;
             return appState;
        } else {
          return appState;
        }
      break;
  case PACK_ASSEMBLY:
      //2)Have the full packet been received?
      if (head->packet_length <= available) {
        //copy data to the destination
         memcpy(head->data, from+4, head->packet_length-4);
        //assign idle and returns "DONE"
         appState = PACK_IDLE;
         return PACK_DONE;
      } else {

       return appState;
      }

  break;
  default:
  }
}

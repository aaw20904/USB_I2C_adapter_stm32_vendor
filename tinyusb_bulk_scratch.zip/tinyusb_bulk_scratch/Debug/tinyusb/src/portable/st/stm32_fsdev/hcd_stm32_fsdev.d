tinyusb/src/portable/st/stm32_fsdev/hcd_stm32_fsdev.o: \
 ../tinyusb/src/portable/st/stm32_fsdev/hcd_stm32_fsdev.c \
 ../tinyusb/src/tusb_option.h ../tinyusb/src/common/tusb_compiler.h \
 ../Core/Inc/tusb_config.h ../tinyusb/src/common/tusb_mcu.h
../tinyusb/src/tusb_option.h:
../tinyusb/src/common/tusb_compiler.h:
../Core/Inc/tusb_config.h:
../tinyusb/src/common/tusb_mcu.h:

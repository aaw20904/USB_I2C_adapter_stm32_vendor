################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../tinyusb/src/portable/st/stm32_fsdev/dcd_stm32_fsdev.c \
../tinyusb/src/portable/st/stm32_fsdev/fsdev_common.c \
../tinyusb/src/portable/st/stm32_fsdev/hcd_stm32_fsdev.c 

OBJS += \
./tinyusb/src/portable/st/stm32_fsdev/dcd_stm32_fsdev.o \
./tinyusb/src/portable/st/stm32_fsdev/fsdev_common.o \
./tinyusb/src/portable/st/stm32_fsdev/hcd_stm32_fsdev.o 

C_DEPS += \
./tinyusb/src/portable/st/stm32_fsdev/dcd_stm32_fsdev.d \
./tinyusb/src/portable/st/stm32_fsdev/fsdev_common.d \
./tinyusb/src/portable/st/stm32_fsdev/hcd_stm32_fsdev.d 


# Each subdirectory must supply rules for building sources it contributes
tinyusb/src/portable/st/stm32_fsdev/%.o tinyusb/src/portable/st/stm32_fsdev/%.su tinyusb/src/portable/st/stm32_fsdev/%.cyclo: ../tinyusb/src/portable/st/stm32_fsdev/%.c tinyusb/src/portable/st/stm32_fsdev/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103x6 -DUSE_FULL_LL_DRIVER -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I../tinyusb -I../tinyusb/src -I../tinyusb/src/common -I../tinyusb/src/device -I../tinyusb/src/class -I../tinyusb/src/osal -I../tinyusb/src/portable/st/stm32_fsdev -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-tinyusb-2f-src-2f-portable-2f-st-2f-stm32_fsdev

clean-tinyusb-2f-src-2f-portable-2f-st-2f-stm32_fsdev:
	-$(RM) ./tinyusb/src/portable/st/stm32_fsdev/dcd_stm32_fsdev.cyclo ./tinyusb/src/portable/st/stm32_fsdev/dcd_stm32_fsdev.d ./tinyusb/src/portable/st/stm32_fsdev/dcd_stm32_fsdev.o ./tinyusb/src/portable/st/stm32_fsdev/dcd_stm32_fsdev.su ./tinyusb/src/portable/st/stm32_fsdev/fsdev_common.cyclo ./tinyusb/src/portable/st/stm32_fsdev/fsdev_common.d ./tinyusb/src/portable/st/stm32_fsdev/fsdev_common.o ./tinyusb/src/portable/st/stm32_fsdev/fsdev_common.su ./tinyusb/src/portable/st/stm32_fsdev/hcd_stm32_fsdev.cyclo ./tinyusb/src/portable/st/stm32_fsdev/hcd_stm32_fsdev.d ./tinyusb/src/portable/st/stm32_fsdev/hcd_stm32_fsdev.o ./tinyusb/src/portable/st/stm32_fsdev/hcd_stm32_fsdev.su

.PHONY: clean-tinyusb-2f-src-2f-portable-2f-st-2f-stm32_fsdev


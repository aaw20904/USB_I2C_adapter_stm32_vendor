Core/Src/usb_descriptors.o: ../Core/Src/usb_descriptors.c \
 ../tinyusb/src/tusb.h ../tinyusb/src/common/tusb_common.h \
 ../tinyusb/src/tusb_option.h ../tinyusb/src/common/tusb_compiler.h \
 ../Core/Inc/tusb_config.h ../tinyusb/src/common/tusb_mcu.h \
 ../tinyusb/src/common/tusb_verify.h ../tinyusb/src/common/tusb_types.h \
 ../tinyusb/src/common/tusb_debug.h ../tinyusb/src/osal/osal.h \
 ../tinyusb/src/common/tusb_common.h ../tinyusb/src/osal/osal_none.h \
 ../tinyusb/src/common/tusb_fifo.h ../tinyusb/src/osal/osal.h \
 ../tinyusb/src/common/tusb_fifo.h ../tinyusb/src/device/usbd.h \
 ../tinyusb/src/class/vendor/vendor_device.h
../tinyusb/src/tusb.h:
../tinyusb/src/common/tusb_common.h:
../tinyusb/src/tusb_option.h:
../tinyusb/src/common/tusb_compiler.h:
../Core/Inc/tusb_config.h:
../tinyusb/src/common/tusb_mcu.h:
../tinyusb/src/common/tusb_verify.h:
../tinyusb/src/common/tusb_types.h:
../tinyusb/src/common/tusb_debug.h:
../tinyusb/src/osal/osal.h:
../tinyusb/src/common/tusb_common.h:
../tinyusb/src/osal/osal_none.h:
../tinyusb/src/common/tusb_fifo.h:
../tinyusb/src/osal/osal.h:
../tinyusb/src/common/tusb_fifo.h:
../tinyusb/src/device/usbd.h:
../tinyusb/src/class/vendor/vendor_device.h:

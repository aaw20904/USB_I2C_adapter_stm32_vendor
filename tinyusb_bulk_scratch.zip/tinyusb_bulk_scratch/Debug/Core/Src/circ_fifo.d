Core/Src/circ_fifo.o: ../Core/Src/circ_fifo.c ../Core/Inc/circ_fifo.h
../Core/Inc/circ_fifo.h:

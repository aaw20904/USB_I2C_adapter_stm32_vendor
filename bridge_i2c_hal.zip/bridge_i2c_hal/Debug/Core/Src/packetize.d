Core/Src/packetize.o: ../Core/Src/packetize.c ../Core/Inc/circ_fifo.h \
 ../Core/Inc/packetize.h
../Core/Inc/circ_fifo.h:
../Core/Inc/packetize.h:

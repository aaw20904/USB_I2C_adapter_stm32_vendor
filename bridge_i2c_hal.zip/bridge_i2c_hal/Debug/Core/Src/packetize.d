Core/Src/packetize.o: ../Core/Src/packetize.c ../Core/Inc/packetize.h
../Core/Inc/packetize.h:

################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../tinyusb/src/device/usbd.c \
../tinyusb/src/device/usbd_control.c 

OBJS += \
./tinyusb/src/device/usbd.o \
./tinyusb/src/device/usbd_control.o 

C_DEPS += \
./tinyusb/src/device/usbd.d \
./tinyusb/src/device/usbd_control.d 


# Each subdirectory must supply rules for building sources it contributes
tinyusb/src/device/%.o tinyusb/src/device/%.su tinyusb/src/device/%.cyclo: ../tinyusb/src/device/%.c tinyusb/src/device/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DSTM32F103xB -DUSE_FULL_LL_DRIVER -DUSE_HAL_DRIVER -c -I../Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CustomHID/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../tinyusb -I../tinyusb/src -I../tinyusb/src/common -I../tinyusb/src/class -I../tinyusb/src/osal -I../tinyusb/src/portable/st/stm32_fsdev -I../tinyusb/src/device -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-tinyusb-2f-src-2f-device

clean-tinyusb-2f-src-2f-device:
	-$(RM) ./tinyusb/src/device/usbd.cyclo ./tinyusb/src/device/usbd.d ./tinyusb/src/device/usbd.o ./tinyusb/src/device/usbd.su ./tinyusb/src/device/usbd_control.cyclo ./tinyusb/src/device/usbd_control.d ./tinyusb/src/device/usbd_control.o ./tinyusb/src/device/usbd_control.su

.PHONY: clean-tinyusb-2f-src-2f-device


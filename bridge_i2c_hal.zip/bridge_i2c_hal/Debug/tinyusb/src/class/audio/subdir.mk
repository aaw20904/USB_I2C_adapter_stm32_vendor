################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../tinyusb/src/class/audio/audio_device.c 

OBJS += \
./tinyusb/src/class/audio/audio_device.o 

C_DEPS += \
./tinyusb/src/class/audio/audio_device.d 


# Each subdirectory must supply rules for building sources it contributes
tinyusb/src/class/audio/%.o tinyusb/src/class/audio/%.su tinyusb/src/class/audio/%.cyclo: ../tinyusb/src/class/audio/%.c tinyusb/src/class/audio/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DSTM32F103xB -DUSE_FULL_LL_DRIVER -DUSE_HAL_DRIVER -c -I../Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CustomHID/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../tinyusb -I../tinyusb/src -I../tinyusb/src/common -I../tinyusb/src/class -I../tinyusb/src/osal -I../tinyusb/src/portable/st/stm32_fsdev -I../tinyusb/src/device -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-tinyusb-2f-src-2f-class-2f-audio

clean-tinyusb-2f-src-2f-class-2f-audio:
	-$(RM) ./tinyusb/src/class/audio/audio_device.cyclo ./tinyusb/src/class/audio/audio_device.d ./tinyusb/src/class/audio/audio_device.o ./tinyusb/src/class/audio/audio_device.su

.PHONY: clean-tinyusb-2f-src-2f-class-2f-audio


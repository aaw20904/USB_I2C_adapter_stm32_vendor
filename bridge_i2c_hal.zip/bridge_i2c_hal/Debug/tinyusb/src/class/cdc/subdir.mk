################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../tinyusb/src/class/cdc/cdc_device.c \
../tinyusb/src/class/cdc/cdc_host.c 

OBJS += \
./tinyusb/src/class/cdc/cdc_device.o \
./tinyusb/src/class/cdc/cdc_host.o 

C_DEPS += \
./tinyusb/src/class/cdc/cdc_device.d \
./tinyusb/src/class/cdc/cdc_host.d 


# Each subdirectory must supply rules for building sources it contributes
tinyusb/src/class/cdc/%.o tinyusb/src/class/cdc/%.su tinyusb/src/class/cdc/%.cyclo: ../tinyusb/src/class/cdc/%.c tinyusb/src/class/cdc/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DSTM32F103xB -DUSE_FULL_LL_DRIVER -DUSE_HAL_DRIVER -c -I../Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CustomHID/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../tinyusb -I../tinyusb/src -I../tinyusb/src/common -I../tinyusb/src/class -I../tinyusb/src/osal -I../tinyusb/src/portable/st/stm32_fsdev -I../tinyusb/src/device -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-tinyusb-2f-src-2f-class-2f-cdc

clean-tinyusb-2f-src-2f-class-2f-cdc:
	-$(RM) ./tinyusb/src/class/cdc/cdc_device.cyclo ./tinyusb/src/class/cdc/cdc_device.d ./tinyusb/src/class/cdc/cdc_device.o ./tinyusb/src/class/cdc/cdc_device.su ./tinyusb/src/class/cdc/cdc_host.cyclo ./tinyusb/src/class/cdc/cdc_host.d ./tinyusb/src/class/cdc/cdc_host.o ./tinyusb/src/class/cdc/cdc_host.su

.PHONY: clean-tinyusb-2f-src-2f-class-2f-cdc


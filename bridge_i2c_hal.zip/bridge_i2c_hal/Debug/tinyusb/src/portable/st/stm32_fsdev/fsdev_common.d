tinyusb/src/portable/st/stm32_fsdev/fsdev_common.o: \
 ../tinyusb/src/portable/st/stm32_fsdev/fsdev_common.c \
 ../tinyusb/src/tusb_option.h ../tinyusb/src/common/tusb_compiler.h \
 ../Core/Inc/tusb_config.h ../tinyusb/src/common/tusb_mcu.h \
 ../tinyusb/src/portable/st/stm32_fsdev/fsdev_common.h \
 ../tinyusb/src/common/tusb_common.h ../tinyusb/src/common/tusb_verify.h \
 ../tinyusb/src/common/tusb_types.h ../tinyusb/src/common/tusb_debug.h \
 ../tinyusb/src/device/dcd.h ../tinyusb/src/osal/osal.h \
 ../tinyusb/src/osal/osal_none.h ../tinyusb/src/common/tusb_fifo.h \
 ../tinyusb/src/portable/st/stm32_fsdev/fsdev_stm32.h \
 ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f1xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f103xb.h \
 ../Drivers/CMSIS/Include/core_cm3.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Device/ST/STM32F1xx/Include/system_stm32f1xx.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal.h \
 ../Core/Inc/stm32f1xx_hal_conf.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_def.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_exti.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_cortex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash_ex.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pwr.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pcd.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_ll_usb.h \
 ../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pcd_ex.h
../tinyusb/src/tusb_option.h:
../tinyusb/src/common/tusb_compiler.h:
../Core/Inc/tusb_config.h:
../tinyusb/src/common/tusb_mcu.h:
../tinyusb/src/portable/st/stm32_fsdev/fsdev_common.h:
../tinyusb/src/common/tusb_common.h:
../tinyusb/src/common/tusb_verify.h:
../tinyusb/src/common/tusb_types.h:
../tinyusb/src/common/tusb_debug.h:
../tinyusb/src/device/dcd.h:
../tinyusb/src/osal/osal.h:
../tinyusb/src/osal/osal_none.h:
../tinyusb/src/common/tusb_fifo.h:
../tinyusb/src/portable/st/stm32_fsdev/fsdev_stm32.h:
../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f1xx.h:
../Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f103xb.h:
../Drivers/CMSIS/Include/core_cm3.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Device/ST/STM32F1xx/Include/system_stm32f1xx.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal.h:
../Core/Inc/stm32f1xx_hal_conf.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_def.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_exti.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_cortex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash_ex.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pwr.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pcd.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_ll_usb.h:
../Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pcd_ex.h:

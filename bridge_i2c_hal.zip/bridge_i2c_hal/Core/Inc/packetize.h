/*
 * packetize.h
 *
 *  Created on: Mar 6, 2026
 *      Author: Andrew
 */

#ifndef INC_PACKETIZE_H_
#define INC_PACKETIZE_H_

#include  "stdint.h"
typedef struct {
    uint8_t type_of_command;
    uint8_t flags;
    uint16_t packet_length;
    uint8_t *data;
}packet_params;

int assemblyPacketInRam(packet_params *pars, uint8_t* payload, uint8_t* packetStore);

int packetParcer (packet_params *pars);

#define PACKET321_PAYLOAD      1
#define PACKET321_ACKNOWLEDGE  2

#define PACKET321_STATUS_OK    1
#define PACKET321_STATUS_FAIL  2

#endif /* INC_PACKETIZE_H_ */

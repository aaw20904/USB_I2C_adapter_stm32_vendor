/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/**

█▀▄ █▀█   ▀█▀ █░█ █ █▀   ▄▀█ █▀▀ ▀█▀ █▀▀ █▀█   █▀▀ ▄▀█ █▀▀ █░█   █▀▀ █░█ █▄▄ █▀▀
█▄▀ █▄█   ░█░ █▀█ █ ▄█   █▀█ █▀░ ░█░ ██▄ █▀▄   ██▄ █▀█ █▄▄ █▀█   █▄▄ █▄█ █▄█ ██▄

█▀█ █▀▀ ▄▄ █▀▀ █▀▀ █▄░█ █▀▀ █▀█ ▄▀█ ▀█▀ █ █▀█ █▄░█   █ █▄░█   █░█ █▀ █▄▄ █▀▄ ▄▄ █▀▀ █▀▄ █▀▀ ░ █▀▀ ▀
█▀▄ ██▄ ░░ █▄█ ██▄ █░▀█ ██▄ █▀▄ █▀█ ░█░ █ █▄█ █░▀█   █ █░▀█   █▄█ ▄█ █▄█ █▄▀ ░░ █▄▄ █▄▀ █▄▄ ▄ █▄▄ ▄
 * */
/* H E L P:
   To bind  "USB transmission complete" callback
   in HAL USB driver, the following steps recommended:
   1) There are __weak void CDC_TxCpltCallback(void) in usbd_cdc_if.c file.
   2)Insert into middlewares/ST/..../src/usbd_cdc.c the following declaration:

	extern void CDC_TxCpltCallback (void);

   3)Find the transmission callback static uint8_t  USBD_CDC_DataIn(USBD_HandleTypeDef *pdev, uint8_t epnum);
     and insert before    "return USBD_OK;" call of external (implemented im main.c) function

          CDC_TxCpltCallback ();

   4) Define callback function in main.c:

    void CDC_TxCpltCallback(void) {
       adapterSemaphoreUSB &= ~semaphore_await_tx_usb;
    }

 * */
//Author: Andrii Androsovych
/*
==========ARCHITECTURE NOTES=====================
LAYER 1 (USB library wrappers):

sendUsbPacketIn() - sends a packet of data (maybe several transfers) to the IN endpoint. Next calls of this function may returns
					"in progress -IN_BUSY_USB" (many times), or "done" IN_COMPL_USB (only one time,
					after this internal state becomes "ready again to new transfers");NOTE: at the begin there set up an incoming semaphore for
					OUT (income) transfers - to avoid race conditions: the host may response immediately, after 100uSec, so the moment
					of incoming new OUT data was always registered.

readUsbPacketOut() - checking the incoming semaphore , and when the reception in progress, it returned OUT_BUSY_USB, when the reception of;
                   OUT data was done - OUT_COMPL_USB was returned.

 *******L A Y E R  1 (continue)**************LOW***LEVEL***NON**BLOCKING**PERIPHERIAL***I2C***SPI****FUNCTIONS****************

masterReadI2cPacket() - master I2C reads a packet of data from slave I2C device by given address. Call this non-blocking function several times, until
                       I2C_MS_R_COMPL was returned (once) and function be ready for new transfers.

masterWriteI2cPacket() - master I2C write data to slave I2C by given address.Call it non-blocking function several times until I2C_MS_W_COMPL was
                       returned once, and the function be ready for new transfers.

masterFullduplexSpiDMA() - SPI full duplex function for Rx/Tx simultaneously. Call several times until SPI_COMPL was returned once.


customSpiFullduplexMasterSetup() - low level SPI tune

	setSlaveSelectSPI() - dont call it.It used by masterFullduplexSpiDMA().

	i2c_usr_slave_init() -  Dont call it.It is a Low level usr setup, calls from resetI2cSetSpeedSlave()

	i2c_usr_master_init() -  Dont call I! It is a low level usr setup, calls from resetI2cSetSpeedMaster()

resetI2cSetSpeedMaster()  - call it to low level tune I2c master

resetI2cSetSpeedSlave() - call it to low level tune I2c slave


---------------------------------LAYER 2:-------------------------------------

readUsbLastReadDataOfSlave() - write a buffer of slave i2c.It will be consumed when a master start communication

writeUsbSlaveTxBuffer() - write a buffer of slave i2c.It will be consumed when a master start communication

setupI2cInterface() -

setupSpiInterface() -

hostRequestI2cMasterWr() -  when a host sends request "write the data to given I2C address" - call this function.
                           When  the function returned I2C_MS_TX_DONE (once) - all the data was sent to the address.
hostRequestI2cMasterRd() - when a host wants to read data from given address - call this function. When data was consumed or any error
                          occured - I2C_MS_RX_DONE was returned once.


 * */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "string.h"
#include "tusb.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/**

█░░ █ █▀▄▀█ █ ▀█▀ ▄▀█ ▀█▀ █ █▀█ █▄░█ █▀ ░   █▀▀ █▀█ █▄░█ █▀ ▀█▀ █▀█ ▄▀█ █ █▄░█ ▀█▀ █▀
█▄▄ █ █░▀░█ █ ░█░ █▀█ ░█░ █ █▄█ █░▀█ ▄█ █   █▄▄ █▄█ █░▀█ ▄█ ░█░ █▀▄ █▀█ █ █░▀█ ░█░ ▄█
maximum data length of the Master (I2C2) = 1024bytes
maximum data length of the Master (SPI1) = 1024bytes
maximum data Length of the Slave = 256bytes (when more - wrap around)
*/
/*I M P O R T A N T : Set the
  #define USBD_CUSTOM_HID_REPORT_DESC_SIZE     38
  in the usbd_conf.h file if a PC not see your device
  */
// USB externs

//I2C haeders
volatile wrp_i2c_slave_header i2cSlaveHeader;
volatile wrp_i2c_master_header i2cMasterHeader;
volatile wrp_spi_master_header spiMasterHeader;
volatile uint32_t user_systick_counter =0;
volatile uint16_t spiStatusFlags;
  unsigned char usb_buffer_for_report_dev[68];
  unsigned char usb_buffer_for_report_host[68];
uint32_t outIncomeUsbReady;
//volatile unsigned char usb_buffer_for_report[68];

  volatile uint8_t i2cRxSlaveBuffer[260];
  volatile uint8_t i2cTxSlaveBuffer[260]= { "Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, 'and what is the use of a book,'.."};

  volatile uint8_t i2cRxMasterBuffer[1026]={0};
  volatile uint8_t i2cTxMasterBuffer[1026]={0};

  volatile uint8_t spiRxMasterBuffer[1026]={0};
  volatile uint8_t spiTxMasterBuffer[1026]={0};

  char dbgReport[1024];
  uint16_t dbgArray[32];

  uint8_t outUsbBuffer[1024];
  uint8_t inUsbBuffer[1024];

  uint32_t usbOutReceivedDataLength;  // a counter to re-assembling income OUT packet
  uint32_t usbInTransmittedDataLength; //a counter of transmitted data

  uint32_t usbInTransmissionComplete; // a semaphore - data packet (may be >64) was sent
LL_I2C_InitTypeDef I2C_InitStructSlave = {0};

LL_I2C_InitTypeDef I2C_InitStructMaster = {0};

int debug_var, usb_dbg_packet_len, usart_state, outgoing_times;
uint16_t dbgIndex; // dbgArray

volatile uint32_t dbg_uart_semaphore;


//USB semaphore
volatile uint32_t adapterSemaphoreUSB;
//I2C semaphore
volatile uint32_t adapterSemaphoreI2C;

volatile uint32_t adapterSemaphoreSPI;

volatile uint32_t bytesReceived, mySemaphore;

 statesHandle i2cAdapterStates;

 void awaitReportFromHost (void);
 void sendReportToHost( uint8_t* oneFrameBuffer);


/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */


/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

PCD_HandleTypeDef hpcd_USB_FS;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_I2C1_Init(void);
static void MX_I2C2_Init(void);
static void MX_SPI1_Init(void);
static void MX_USB_PCD_Init(void);
static void MX_USART1_UART_Init(void);
/* USER CODE BEGIN PFP */
/*DEBUG UAR DMA notes
1)Set RAM address, peripherial address in DMA1_CH4
2)Set CNDTR4 - amount of data, interrupts DMA1_CCR4 (optinal)
2)Set DMAT bit "dma tx enable" in UART_CR3
4)To start - set DMA1_CCR4_EN bit
When all the data was sent - CNDTR4 becomes empty (0)
And interrupt will generating.To reset flag, use IFCR, to set
CNDTR4, disable channel firstly

*/
//here are****callbacks***TinyUSB stack
//NOTE: here is the example of callbacks for BULK endpoints
void tud_vendor_rx_cb(uint8_t itf,  const uint8_t* buffer, uint32_t bufsize)
{
	uint32_t bytes_to_consume, consumed_data;

	uint32_t receivedBefore=usbOutReceivedDataLength; //only DEBUG
	//{ consuming (draining) data from internal buffer, until available
	  while (tud_vendor_available()) {
		  //a)when data to consume exists - read amount exactly
		  bytes_to_consume = tud_vendor_available();
		  //b)drain data from internal TinyUSB`s buffer to a user buffer
		  consumed_data = tud_vendor_read((outUsbBuffer + usbOutReceivedDataLength), bytes_to_consume);
		  //c)update amount of consumed data
		  usbOutReceivedDataLength += consumed_data;
	  }

	  dbgArray[dbgIndex] = usbOutReceivedDataLength - receivedBefore; //debug: calculating consumed data
	  dbgIndex++;  //debug

	  /////copying consumed data here for next echo after consuming 512 bytes of data
       if (usbOutReceivedDataLength == 512){
    	   memcpy(inUsbBuffer,outUsbBuffer, 512);
    	   outIncomeUsbReady=1;
    	   usbOutReceivedDataLength = 0;
       }

      //wrap-around, only for safety
	  if(usbOutReceivedDataLength > 0x03ff) {
		  GPIOB->BSRR = GPIO_BSRR_BS14;
		  usbOutReceivedDataLength =0;
	  }

}

void tud_vendor_tx_cb(uint8_t itf, uint32_t sent_bytes)
{
	usbInTransmittedDataLength += sent_bytes;
	outgoing_times++;
    // TX finished
	//clear number of received data - to avoid races

}






//--NEW ASYC timeout function, @returned values:  "0"-time has gone, "1" you must waiting
int planTimeout(void){
	static int func_state = 0;
	static int initial_val = 0;
	if (func_state == 0) {
		//remember initial state from a "live" ISR updated variable
	  initial_val = user_systick_counter;
	  //set a counter to active
	  func_state= 1;
	  //busy, must waiting
	  return 1;
	} else if (func_state == 1 ) {
		//when state is waiting for event
		if(user_systick_counter != initial_val){
			//the time has gone
			func_state = 0;
			//ready, the time has gone
			return 0;
		} else {
			//busy, must waiting
			return 1;
		}
	}
	return -1;

}
///DEBUG
void usrInitUart(void) {
	 //enable DMA Tx transfer
	 USART1->CR3 |= USART_CR3_DMAT;
	 //DMA settings
	 DMA1_Channel4->CPAR =(uint32_t) &USART1->DR;
	 DMA1_Channel4->CCR |= DMA_CCR_TCIE;
 }

 /*DEBUG UAR DMA notes
 1)Set RAM address, peripherial address in DMA1_CH4
 2)Set CNDTR4 - amount of data, interrupts DMA1_CCR4 (optinal)
 2)Set DMAT bit "dma tx enable" in UART_CR3
 4)To start - set DMA1_CCR4_EN bit
 When all the data was sent - CNDTR4 becomes empty (0)
 And interrupt will generating.To reset flag, use IFCR, to set
 CNDTR4, disable channel firstly

 */
 uint32_t sendUartMessage (uint8_t* src, uint16_t bytesInMessage) {
	 static uint32_t state=0;
	 switch (state) {
	 case 0:
		 //START NEW MESSAGE
		 //1)Disable DMA channel
		 DMA1_Channel4->CCR &= ~DMA_CCR_EN;
		 //2)Set size of the parcel
		 DMA1_Channel4->CNDTR = bytesInMessage;
		 //3)Set data destination
		 DMA1_Channel4->CMAR = (uint32_t)src;
		 //4)Set up the semaphore
		 dbg_uart_semaphore = 0;
		 state = 1;
		 //5)Start transfer
		 DMA1_Channel4->CCR |= DMA_CCR_EN;
		 return state;
		 break;
	 case 1:
		 if (dbg_uart_semaphore == 1) {
			  //1)Disable DMA channel, clear the semaphore and the state variable
			 DMA1_Channel4->CCR &= ~DMA_CCR_EN;
			 state = 0;
			 dbg_uart_semaphore = 0;
			 return state; ///DONE!
		 } else {
			 return state; //in progress
		 }
		 break;
	 default:

	 }
  return -1;
 }

 void plotDebugData(uint16_t* transactionSize, char* plotPlace ) {
	 char localBuf[64];
	 char* textBufferPtr = plotPlace;
	 uint16_t stringLen;
	 sprintf((char*)localBuf,"IN times: %d \n\r ,OUT_CONSUMED_STAGES: \n\r", outgoing_times);
	 outgoing_times=0;
	 stringLen = strlen(localBuf);
	 memcpy( textBufferPtr, localBuf, stringLen);
	 textBufferPtr += stringLen;
   //dbgArray
	 for(char a=0; a<31; a++) {
		 sprintf((char*)localBuf,"%d => %d \n\r",a, transactionSize[a]);
		 stringLen = strlen(localBuf);
		 memcpy( textBufferPtr, localBuf, stringLen);
		 textBufferPtr += stringLen;
		 transactionSize[a] = 0; //clean for nxt time
	 }
 }

///// SPI procedures
/***
 *

░██████╗██████╗░██╗
██╔════╝██╔══██╗██║
╚█████╗░██████╔╝██║
░╚═══██╗██╔═══╝░██║
██████╔╝██║░░░░░██║
╚═════╝░╚═╝░░░░░╚═╝
 * **/
 void setSlaveSelectSPI(uint8_t pol) {

		 if (pol==0) {
			 GPIOA->BSRR = GPIO_BSRR_BR4;

		 } else {
			 GPIOA->BSRR = GPIO_BSRR_BS4;
		 }

 }


 void clearSlaveSelectSPI(uint8_t pol) {
	 if (pol==0) {
			 GPIOA->BSRR = GPIO_BSRR_BS4;

		 } else {
			 GPIOA->BSRR = GPIO_BSRR_BR4;
		 }
 }
  ///NOTE: The receive and transmit amount of data are EQUAL and THE SAME!
 //all the paameters in according to LL library constants. @SSpol - mens polarity of SS pin
 //-NON BLOCKING

/*
//<<<<WELL-TESTED>>> 19.02.26
█░█░█ █▀▀ █░░ █░░   ▀█▀ █▀▀ █▀ ▀█▀ █▀▀ █▀▄   ▄█ █▀█   █▀█ ▀█   ▀█ █▄▄
▀▄▀▄▀ ██▄ █▄▄ █▄▄   ░█░ ██▄ ▄█ ░█░ ██▄ █▄▀   ░█ ▀▀█   █▄█ █▄   █▄ █▄█
 * */
 void customSpiFullduplexMasterSetup(uint16_t clkPol, uint16_t clkPh, uint16_t baudRate, uint16_t msbLsb, uint8_t ssPol)
 {
     LL_SPI_InitTypeDef SPI_InitStruct = {0};

     // Ensure peripheral clock enabled
     //LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_SPI1);
     //LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOA);

     // Disable SPI before reconfig
     LL_SPI_Disable(SPI1);

     // Basic SPI configuration
     SPI_InitStruct.TransferDirection =LL_SPI_FULL_DUPLEX;
     SPI_InitStruct.Mode = LL_SPI_MODE_MASTER;
     SPI_InitStruct.DataWidth = LL_SPI_DATAWIDTH_8BIT;
     SPI_InitStruct.ClockPolarity = clkPol; // LL_SPI_POLARITY_LOW
     SPI_InitStruct.ClockPhase = clkPh;// LL_SPI_PHASE_1EDGE
     SPI_InitStruct.NSS = LL_SPI_NSS_SOFT;   // <<< important change
     SPI_InitStruct.BaudRate = baudRate; // LL_SPI_BAUDRATEPRESCALER_DIV64
     SPI_InitStruct.BitOrder = msbLsb; // LL_SPI_MSB_FIRST
     SPI_InitStruct.CRCCalculation = LL_SPI_CRCCALCULATION_DISABLE;
     SPI_InitStruct.CRCPoly = 10;

     LL_SPI_Init(SPI1, &SPI_InitStruct);
     //TURN OFF enable (SS) pin:
     clearSlaveSelectSPI(ssPol);
     // Enable SPI peripheral
    // LL_SPI_Enable(SPI1);
 }


///-5)---------newAsyncFunction-----N E W----A S Y N C----
 //full duplex function , works well, tested.MOSI - output, MISO - input.During communication?
 // Tx read byte for transmission from Tx buffer, and received byte write into Rx bufer.So both buffers are used.
 /*
 //<<<<WELL-TESTED>>> 19.02.26
 █░█░█ █▀▀ █░░ █░░   ▀█▀ █▀▀ █▀ ▀█▀ █▀▀ █▀▄   ▄█ █▀█   █▀█ ▀█   ▀█ █▄▄
 ▀▄▀▄▀ ██▄ █▄▄ █▄▄   ░█░ ██▄ ▄█ ░█░ ██▄ █▄▀   ░█ ▀▀█   █▄█ █▄   █▄ █▄█
  * */
 int32_t masterFullduplexSpiDMA (volatile wrp_spi_master_header* spiHeader) {
	 //a state mashine variable
	 static enum mfdsiStatesM func_states;
	 ///here the program choose which part of execution it is:
	 switch(func_states){
	 case SPI_IDLE:
		 //state 1 - idle
		  	adapterSemaphoreSPI &= 0xfffffffe; //clear bit 0
		  	adapterSemaphoreSPI |= 0x00000001;
		  	spiHeader->spiMasterErrorFlags = 0;
		  	//-------------------------------------------
		  	//a) disable SPI
		  	spiHeader->hDevice->CR1 &= ~SPI_CR1_SPE;
		  	//enable DMA on Tx
		  	spiHeader->hDevice->CR2 |= SPI_CR2_TXDMAEN;
		  	//enable DMA on Rx
		  	spiHeader->hDevice->CR2 |= SPI_CR2_RXDMAEN;
		  	   //c)disable interrupts on Tx
		  	spiHeader->hDevice->CR2 &=~(SPI_CR2_TXEIE);
		  	   //disable interrupts on Rx
		  	spiHeader->hDevice->CR2 &= ~SPI_CR2_RXNEIE;
		       //d)Disable DMA channel (Tx)
		      spiHeader->dmaTxChanel->CCR &= ~DMA_CCR_EN;
		  	 //e)Set number data to transmitt
		      spiHeader->dmaTxChanel->CNDTR = spiHeader->spiMasterTxPacketLength-1;
		  	//f)Set memory address (CMAR)
		      spiHeader->dmaTxChanel->CMAR = (uint32_t)spiHeader->spiTxMasterBuffer+1;
		      //g)peripherial addrss
		      spiHeader->dmaTxChanel->CPAR = (uint32_t)&SPI1->DR;
		      //enable DMA interrupt Transmission Complete
		      spiHeader->dmaTxChanel->CCR |= DMA_CCR_TCIE;
		      //--rx dma
		      //d)Disable DMA channel (Rx)
		     	spiHeader->dmaRxChanel->CCR &= ~DMA_CCR_EN;
		     	 //e)Set number data to transmitt
		     	spiHeader->dmaRxChanel->CNDTR = spiHeader->spiMasterRxPacketLength;
		     	//f)Set memory address (CMAR)
		     	spiHeader->dmaRxChanel->CMAR = (uint32_t)spiHeader->spiRxMasterBuffer;
		     	//g)peripherial addrss
		     	spiHeader->dmaRxChanel->CPAR = (uint32_t)&SPI1->DR;
		     	//enable DMA interrupt Transmission Complete
		     	spiHeader->dmaRxChanel->CCR |= DMA_CCR_TCIE;
		      //write the first byte manually
		     	spiHeader->hDevice->DR = spiHeader->spiTxMasterBuffer[0];
		  	 //enable DMA channels
		     	if (spiHeader->dmaTxChanel->CNDTR > 0) {
		     		spiHeader->dmaTxChanel->CCR |= DMA_CCR_EN;
		     	}

		  	 spiHeader->dmaRxChanel->CCR |= DMA_CCR_EN;
		  	 //g)set SS signal in active state
		  	 setSlaveSelectSPI(spiHeader->ssPolarity);
		  	 //dummyDelay(10);

		  	  //c)enable peripherial - start SPI transaction
		  	 spiHeader->hDevice->CR1 |= SPI_CR1_SPE;
		  	 //set busy state
		  	 func_states = SPI_BUSY_FIRST;
		  	 //exit, because of non-blocking
		  	 return func_states;
		 break;
	 case SPI_BUSY_FIRST:
		 //Has txPacketLength-1 bytes been sent?
		 if (!(adapterSemaphoreSPI & 0x00000001)) {
			 func_states = SPI_BUSY_LAST;
			 return func_states;
		 } else {
			 return func_states;
		 }
		 break;
	 case SPI_BUSY_LAST:
         /////has the last byte  been sent?
		 if (!(spiHeader->hDevice->SR & SPI_SR_BSY)) {
			 //when all the data has been transmitted - turn the peripherial off
			      	 //spiHeader->hDevice->CR1 &= ~SPI_CR1_SPE;
			           SPI1->CR1 &= ~SPI_CR1_SPE;
			           //d)Disable DMA channel (Tx)
			          spiHeader->dmaTxChanel->CCR &= ~DMA_CCR_EN;
			      	spiHeader->dmaRxChanel->CCR &= ~DMA_CCR_EN;
			      //clear SS signal to inactive
			  	 clearSlaveSelectSPI(spiHeader->ssPolarity);
			  		//clear TXE flag
			  	 spiHeader->hDevice->DR = 0x00;
			  	  //disable DMA
			  	 spiHeader->hDevice->CR2 &= ~SPI_CR2_TXDMAEN;
			  	 spiHeader->hDevice->CR2 &= ~SPI_CR2_RXDMAEN;
			  	 //ready to next transfers
			  	 func_states = SPI_IDLE;
			  	 //full data has been transmitted/received
			  	 //Notify high level layers - the work has done!
			  	 return SPI_COMPL;
		 } else {
			 return func_states;
		 }
		 break;
	 case SPI_ERROR:
		 //have not realized yet
       break;
	 default:
		 return -1;
	 }
  return 0;
 }






/*

██╗██████╗░░█████╗░
██║╚════██╗██╔══██╗
██║░░███╔═╝██║░░╚═╝
██║██╔══╝░░██║░░██╗
██║███████╗╚█████╔╝
╚═╝╚══════╝░╚════╝░
 * */

/// I2C procedures
//--NON blocking
void i2c_usr_slave_init (volatile wrp_i2c_slave_header*   header) {
	 //disable I2C
	 header->hDevice->CR1 &= ~I2C_CR1_PE;
  //write own address
	 header->hDevice->OAR1 = header->i2cSlaveAddress;
  //enable acknowledgements
	 header->hDevice->CR1 |=  I2C_CR1_ACK;
	 //enable event interrupts and bufer interrupts
	 header->hDevice->CR2 |= I2C_CR2_ITEVTEN|I2C_CR2_ITBUFEN|I2C_CR2_ITERREN;
	  //turn I2C on, enable acknowledge
	 header->hDevice->CR1 |= I2C_CR1_PE|I2C_CR1_ACK;
}
//--NON blocking
void i2c_usr_master_init (volatile wrp_i2c_master_header* header) {
	 //enable own address
	 header->hDevice->CR1 &= ~I2C_CR1_PE;
	  //own address equals zero - master
	 header->hDevice->CR1 |=  I2C_CR1_ACK;
	 //enable event interrupts and bufer interrupts
	 header->hDevice->CR2 |= I2C_CR2_ITEVTEN|I2C_CR2_ITBUFEN|I2C_CR2_ITERREN;
	  //turn I2C on, enable acknowledge
	 header->hDevice->CR1 |= I2C_CR1_PE|I2C_CR1_ACK;

}

//--NON blocking, async
int resetI2cSetSpeedMaster (volatile wrp_i2c_master_header* mHeader, LL_I2C_InitTypeDef *mInitStruct, uint32_t speed) {
      static int func_state=0;
      if(func_state==0) {
    	  //reset master
         I2C2->CR1 |= I2C_CR1_SWRST;
         planTimeout();
         func_state=1;
         return 0;
      } else if (func_state==1) {
    	   I2C2->CR1  = 0;
			///set speed
		   mInitStruct->ClockSpeed = speed;
		 LL_I2C_Init(I2C2, mInitStruct);
		 i2c_usr_master_init(mHeader);
		 func_state=0;
		 ///DONE!
		 return 1;
      }
  return 0;
}

//--NON blocking, async
int resetI2cSetSpeedSlave (volatile wrp_i2c_slave_header* sHeader, LL_I2C_InitTypeDef *sInitStruct, uint32_t speed, uint8_t addr ) {
	 static int func_state=0;
	      if(func_state==0) {
	    	  //reset slave
	        I2C1->CR1 |= I2C_CR1_SWRST;
	         planTimeout();
	         func_state=1;
	         return 0;
	      } else if (func_state==1) {
	      	   I2C1->CR1  = 0;
	      	   	///set speed
	      	   sInitStruct->ClockSpeed = speed;
	      	   sInitStruct->OwnAddress1 = addr;
	      	   sHeader->i2cSlaveAddress = addr;
	      	 LL_I2C_Init(I2C1, sInitStruct);
	      	 i2c_usr_slave_init(sHeader);
			 func_state=0;
			 ///DONE!
			 return 1;
	      }
	      return 0;
}
//--NON blocking
void greenLedOn (void) {
	GPIOC->BSRR = GPIO_BSRR_BR13;
}
//--NON blocking
void greenLedOff (void) {
	GPIOC->BSRR = GPIO_BSRR_BS13;
}


///---3)----N E W----A S Y N C--NON BLOCKING---function------
/*
 enum i2cStatesM {
	I2C_MS_IDLE,
	I2C_MS_DAT_BUSY,
	I2C_MS_COM_BUSY,
	I2C_MS_COMPL,
	I2C_MS_ERROR
};
 * */
/*
 //<<<<WELL-TESTED>>> 19.02.26
 █░█░█ █▀▀ █░░ █░░   ▀█▀ █▀▀ █▀ ▀█▀ █▀▀ █▀▄   ▄█ █▀█   █▀█ ▀█   ▀█ █▄▄
 ▀▄▀▄▀ ██▄ █▄▄ █▄▄   ░█░ ██▄ ▄█ ░█░ ██▄ █▄▀   ░█ ▀▀█   █▄█ █▄   █▄ █▄█
  * */
int32_t masterWriteI2cPacket (volatile wrp_i2c_master_header* i2cHeader, unsigned char address,  volatile unsigned char* bufferPtr, unsigned short amountOfData) {
	static enum i2cStatesM  states_func;

	switch (states_func) {
	case I2C_MS_IDLE:
	//for safety:
			if (amountOfData >= i2cHeader->masterI2cBufferLimit){
				amountOfData = i2cHeader->masterI2cBufferLimit;
			}
	   //clean old saved flags:
		i2cHeader->i2cMasterErrorFlags = 0;
	 //set memory address
		i2cHeader->i2cTxMasterBuffer = bufferPtr;
	  //set slave address-:
		i2cHeader->i2cMasterAddress = address;
	  //set write mode:
		i2cHeader->WriteFlag = 1;
	  //set amount of data:
		i2cHeader->i2cMasterTxPacketLength = amountOfData;
	  //set the semaphore
		adapterSemaphoreI2C |= semaphore_await_tx_i2c;
		//start transaction:
		i2cHeader->hDevice->CR1 |= I2C_CR1_START;
		states_func = I2C_MS_DAT_BUSY;
		return states_func;
		break;
	case I2C_MS_DAT_BUSY:
		//when all the data will be sent
		if ( (adapterSemaphoreI2C & semaphore_await_tx_i2c)==0) {
			states_func = I2C_MS_COM_BUSY;
			return I2C_MS_COM_BUSY;
		} else {
			return states_func;
		}
		break;
	case I2C_MS_COM_BUSY:
		//when stop sequence complete:
		if ((i2cHeader->hDevice->SR2 & I2C_SR2_BUSY)==0) {
			 states_func = I2C_MS_IDLE;
			 return I2C_MS_COMPL;
		} else {
			return I2C_MS_COM_BUSY;
		}
		break;
	default:
		return -1;
	}



}

///----NEW---non blocking-function, it needs for asyncronous performance
uint32_t getI2cMasterError(volatile wrp_i2c_master_header* i2cHeader) {
	//checking for errors:
		switch (i2cHeader->i2cMasterErrorFlags) {
		case I2C_SR1_AF:
			return adapter_AF;
			break;
		case I2C_SR1_BERR:
			return adapter_BERR;
		     break;
		case I2C_SR1_ARLO:
			return adapter_ARLO;
			break;
		case I2C_SR1_OVR:
			return adapter_OVR;
			 break;
		default: //no errors
			return 0;
		}
}

///----NEW---non blocking-function, it needs for asyncronous performance
uint32_t getI2cSlaveError(volatile wrp_i2c_slave_header* i2cHeader) {
	//checking for errors:
		switch (i2cHeader->i2cSlaveErrorFlags) {
		case I2C_SR1_AF:
			return adapter_AF;
			break;
		case I2C_SR1_BERR:
			return adapter_BERR;
		     break;
		case I2C_SR1_ARLO:
			return adapter_ARLO;
			break;
		case I2C_SR1_OVR:
			return adapter_OVR;
			 break;
		default: //no errors
			return 0;
		}
}


//--4)----N E W----A S Y N C---non---blocking---function
/*
enum i2cStatesM {
	I2C_MS_IDLE,
	I2C_MS_DAT_BUSY,
	I2C_MS_COM_BUSY,
	I2C_MS_COMPL,
	I2C_MS_ERROR
};*/
/*
 //<<<<WELL-TESTED>>> 19.02.26
 █░█░█ █▀▀ █░░ █░░   ▀█▀ █▀▀ █▀ ▀█▀ █▀▀ █▀▄   ▄█ █▀█   █▀█ ▀█   ▀█ █▄▄
 ▀▄▀▄▀ ██▄ █▄▄ █▄▄   ░█░ ██▄ ▄█ ░█░ ██▄ █▄▀   ░█ ▀▀█   █▄█ █▄   █▄ █▄█
  * */
int masterReadI2cPacket (volatile wrp_i2c_master_header* i2cHeader, unsigned char address, volatile  unsigned char* bufferPtr, unsigned short amountOfData) {
	static enum i2cStatesM states_func;
	switch (states_func) {
	case I2C_MS_IDLE:
	//for safety
		if (amountOfData >= i2cHeader->masterI2cBufferLimit){
							amountOfData = i2cHeader->masterI2cBufferLimit;
		}
		//clean old saved flags:
			i2cHeader->i2cMasterErrorFlags = 0;
		 //set memory address
			i2cHeader->i2cRxMasterBuffer = bufferPtr;
		  //set slave address-:
			i2cHeader->i2cMasterAddress = address;
		  //set receiver mode
			i2cHeader->WriteFlag = 0;
		  //set amount of data:
			i2cHeader->i2cMasterRxPacketLength = amountOfData;
		  //set the semaphore
			adapterSemaphoreI2C |= semaphore_await_rx_i2c;
			//start transaction:
				i2cHeader->hDevice->CR1 |= I2C_CR1_START;
			states_func = I2C_MS_DAT_BUSY;
		break;
	case I2C_MS_DAT_BUSY:
		//all the data was sent
		if (!(adapterSemaphoreI2C & semaphore_await_rx_i2c)) {
			states_func = I2C_MS_COM_BUSY;
			return states_func;
		} else {
			return states_func;
		}
		break;
	case I2C_MS_COM_BUSY:
		//the stop sequence was complete:
		if (!(i2cHeader->hDevice->SR2 & I2C_SR2_BUSY)) {
			states_func=I2C_MS_IDLE;
			return  I2C_MS_COMPL;
		} else{
            return states_func;
		}
		break;
	default:
		return -1;

	}
 return 0;
}






/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
///===============High-level layer================
int32_t expectOutUsbHostData(uint16_t expectedBytes) {

	if (outIncomeUsbReady==1) {
		outIncomeUsbReady = 0;
		return  USB_RX_DONE; //DONE data had been reassembled completely
	} else {
		return -2; //data not reassembled yet (not received in full volume)
	}
}
/*
 enum usbSend {
	 USB_TR_BEGIN,
	 USB_TR_WRITE_BUFFER,
	 USB_TR_FLUSH_DATA,
	 USB_TR_PROGRESS,
	 USB_TR_DONE
 };
 * */
int32_t sendInUsbDataToHost (uint8_t* data, uint16_t wsize) {
	static enum usbSend func_state;
    static int32_t writtenInIntBuff = 0;
	switch(func_state){
	case USB_TR_BEGIN:
		if (tud_ready()){
				//when enough data available now, write data into an internal buffer:
				writtenInIntBuff += tud_vendor_write((data+writtenInIntBuff), (wsize-writtenInIntBuff));
				 if (writtenInIntBuff == wsize) {
					 writtenInIntBuff = 0;
					 func_state = USB_TR_WRITE_BUFFER;
					 return func_state;
				 }
				 return func_state;
		}
		return func_state;
		break;
	case USB_TR_WRITE_BUFFER:
		if (tud_ready()) {
			//clear "transmission complete" semaphore
			usbInTransmittedDataLength = 0;
			 //start to flushing
			 tud_vendor_write_flush();
			 func_state = USB_TR_PROGRESS;
			 return func_state;
		}
		return func_state;
		break;
	case USB_TR_PROGRESS:
       if (usbInTransmittedDataLength  >= wsize) {
    	   //when data has been sent completely
    	   func_state =  USB_TR_BEGIN;
           return USB_TR_DONE;
       }
		return func_state;
		break;
	case USB_TR_DONE:
		break;
	}
	return func_state;

}


/*

█▀▀ █▀█ █▀▄▀█ █▀▄▀█ ▄▀█ █▄░█ █▀▄   █▀█ █▀█ █░█ ▀█▀ █▀▀ █▀█
█▄▄ █▄█ █░▀░█ █░▀░█ █▀█ █░▀█ █▄▀   █▀▄ █▄█ █▄█ ░█░ ██▄ █▀▄
 * */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
   /*

███╗░░░███╗░█████╗░██╗███╗░░██╗
████╗░████║██╔══██╗██║████╗░██║
██╔████╔██║███████║██║██╔██╗██║
██║╚██╔╝██║██╔══██║██║██║╚████║
██║░╚═╝░██║██║░░██║██║██║░╚███║
╚═╝░░░░░╚═╝╚═╝░░╚═╝╚═╝╚═╝░░╚══╝
     */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_I2C2_Init();
  MX_SPI1_Init();
  MX_USB_PCD_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */

  tusb_init();         // TinyUSB init, insert it after clock ready and HAL initialization

  tud_disconnect();
  HAL_Delay(20);
  tud_connect();

  usrInitUart(); //for debug - terminal plotting

  I2C_InitStructMaster.PeripheralMode = LL_I2C_MODE_I2C;
  I2C_InitStructMaster.ClockSpeed = 100000;
  I2C_InitStructMaster.DutyCycle = LL_I2C_DUTYCYCLE_2;
  I2C_InitStructMaster.OwnAddress1 = 0;
  I2C_InitStructMaster.TypeAcknowledge = LL_I2C_ACK;
  I2C_InitStructMaster.OwnAddrSize = LL_I2C_OWNADDRESS1_7BIT;


  I2C_InitStructSlave.PeripheralMode = LL_I2C_MODE_I2C;
  I2C_InitStructSlave.ClockSpeed = 100000;
  I2C_InitStructSlave.DutyCycle = LL_I2C_DUTYCYCLE_2;
  I2C_InitStructSlave.OwnAddress1 = 64;
  I2C_InitStructSlave.TypeAcknowledge = LL_I2C_ACK;
  I2C_InitStructSlave.OwnAddrSize = LL_I2C_OWNADDRESS1_7BIT;

  /*3) Initialize an instance of a structure,
   these values will be used in initialization and inside interrupts
   to restore options in DMA after transactions*/
      i2cSlaveHeader.hDevice = I2C1;  //device
      i2cSlaveHeader.i2cRxSlaveBuffer = i2cRxSlaveBuffer;  //Rx bufer
      i2cSlaveHeader.i2cTxSlaveBuffer = i2cTxSlaveBuffer; //Tx bufer
      i2cSlaveHeader.i2cSlaveRxPacketLength = 4;
      i2cSlaveHeader.i2cSlaveTxPacketLength = 4;
      i2cSlaveHeader.slaveI2cBufferLimit = 255;  //maximum length (not used)
      i2cSlaveHeader.i2cSlaveAddress = 0x40;  //must be shifted - because bit 0 - R/W
      i2cSlaveHeader.dmaRxChanel = DMA1_Channel7;
      i2cSlaveHeader.dmaTxChanel = DMA1_Channel6;
      //master initialization
	  i2cMasterHeader.dmaRxChanel = 0;
	  i2cMasterHeader.dmaTxChanel = 0;
	  i2cMasterHeader.hDevice = I2C2;
	  i2cMasterHeader.i2cMasterAddress = 0x20;
	  i2cMasterHeader.i2cMasterRxPacketLength = 16; //
	  i2cMasterHeader.i2cMasterTxPacketLength = 16;
	  i2cMasterHeader.i2cRxMasterBuffer = i2cRxMasterBuffer;
	  i2cMasterHeader.i2cTxMasterBuffer =  i2cTxMasterBuffer;
	  i2cMasterHeader.masterI2cBufferLimit = 1024;      ///Attention - master I2C buffer limit is here!
	  i2cMasterHeader.dmaRxChanel = 0;
	  i2cMasterHeader.dmaTxChanel = 0;
	  i2cMasterHeader.WriteFlag = 1;


      //5) Init DMA and slave I2C ind Rx and Tx modes:
      i2c_usr_slave_init(&i2cSlaveHeader);
      //6)When there is the BUSY I2C bug, clear I2C and init again:
        if (I2C1->SR2 & I2C_SR2_BUSY) {
      	  //when busy bug, clean it by reset:
        	resetI2cSetSpeedSlave(&i2cSlaveHeader, &I2C_InitStructSlave, 100000, 64<<1);
        	while(resetI2cSetSpeedSlave(&i2cSlaveHeader, &I2C_InitStructSlave, 100000, 64<<1)!=1){

        	}
         }
	//init a master (RCC, GPIO initialization must be done before)
		i2c_usr_master_init(&i2cMasterHeader);
		if (I2C2->SR2 & I2C_SR2_BUSY) {
			//when the busy bug, clean it by reset:
			resetI2cSetSpeedMaster(&i2cMasterHeader, &I2C_InitStructMaster, 100000);
			while(resetI2cSetSpeedMaster(&i2cMasterHeader, &I2C_InitStructMaster, 100000) !=1) {

			}
		}

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */



		spiMasterHeader.hDevice = SPI1;
		spiMasterHeader.spiMasterTxPacketLength = 16;            //ATTENTION:
		spiMasterHeader.masterSpiBufferLimit = 1024;             //SPI packet limit here!
		spiMasterHeader.spiRxMasterBuffer = spiRxMasterBuffer;
		spiMasterHeader.spiTxMasterBuffer = spiTxMasterBuffer;
		spiMasterHeader.ssPolarity = 0;
		spiMasterHeader.dmaRxChanel = DMA1_Channel2;

		spiMasterHeader.hDevice = SPI1;
		spiMasterHeader.spiMasterRxPacketLength = 16;
		spiMasterHeader.masterSpiBufferLimit = 1024;          //SPI packet limit here!
		spiMasterHeader.spiRxMasterBuffer = spiRxMasterBuffer;
		spiMasterHeader.spiTxMasterBuffer = spiTxMasterBuffer;
		spiMasterHeader.ssPolarity = 0;
		spiMasterHeader.dmaTxChanel = DMA1_Channel3;



/*
			█░█░█ █░█ █ █░░ █▀▀
			▀▄▀▄▀ █▀█ █ █▄▄ ██▄
			 * */
		resetI2cSetSpeedMaster(&i2cMasterHeader, &I2C_InitStructMaster, 100000);
		while(resetI2cSetSpeedMaster(&i2cMasterHeader, &I2C_InitStructMaster, 100000) != 1){

		}
		resetI2cSetSpeedSlave(&i2cSlaveHeader, &I2C_InitStructSlave, 100000, 64<<1);
		while(resetI2cSetSpeedSlave(&i2cSlaveHeader, &I2C_InitStructSlave, 100000, 64<<1)!=1){

		}
       //dbg begin
		  memcpy((void*)i2cTxMasterBuffer,"Alice was beginning to get very tired of sitting by her sister o",64);
		//  writeI2cAndWaitEnd(&i2cMasterHeader, 64, i2cTxMasterBuffer, 64);

		  debug_var=masterReadI2cPacket(&i2cMasterHeader, 64, i2cRxMasterBuffer, 64);
		 while(debug_var !=I2C_MS_COMPL){
		 	debug_var = masterReadI2cPacket(&i2cMasterHeader, 64, i2cRxMasterBuffer, 64);
		 }

		 debug_var= masterReadI2cPacket(&i2cMasterHeader, 64, i2cRxMasterBuffer, 64);
		 		 while(debug_var !=I2C_MS_COMPL){
		 		 	debug_var = masterReadI2cPacket(&i2cMasterHeader, 64, i2cRxMasterBuffer, 64);
		 		 }

		//debug end
		 		GPIOB->BSRR = GPIO_BSRR_BR14; //debug only
		 		 usart_state = 2;
		 		debug_var = 0;
		 		usb_dbg_packet_len = 512;
  while (1)
  {

	  //debug begin
	  tud_task();

	  if((!(GPIOB->IDR & GPIO_IDR_IDR3)) && (usart_state == 2) ) {
		  usart_state=0;
	  }
	  if(usart_state <= 1){
		    if(usart_state == 0) {
		    	plotDebugData(dbgArray,dbgReport);
		    			usart_state++;
		    }
		  if (sendUartMessage(dbgReport,512)==0){
			  dbgIndex=0;//clear index of debug array, to plotting since index 0 exactly next plot time
			  usart_state=2;
		  }
	  }
	  //debug end
	  switch (debug_var){
	  case 0:
		  if (expectOutUsbHostData(usb_dbg_packet_len) ==  USB_RX_DONE) {
			  debug_var = 1;
		  }

		  break;
	  case 1:
		  if (sendInUsbDataToHost(inUsbBuffer,usb_dbg_packet_len) == USB_TR_DONE) {
			   debug_var = 0;
		  }
		  break;
	  }



    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV2;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL12;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  LL_I2C_InitTypeDef I2C_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOB);
  /**I2C1 GPIO Configuration
  PB6   ------> I2C1_SCL
  PB7   ------> I2C1_SDA
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_6|LL_GPIO_PIN_7;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_OPENDRAIN;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_I2C1);

  /* I2C1 interrupt Init */
  NVIC_SetPriority(I2C1_EV_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),2, 0));
  NVIC_EnableIRQ(I2C1_EV_IRQn);
  NVIC_SetPriority(I2C1_ER_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),2, 0));
  NVIC_EnableIRQ(I2C1_ER_IRQn);

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */

  /** I2C Initialization
  */
  LL_I2C_DisableOwnAddress2(I2C1);
  LL_I2C_DisableGeneralCall(I2C1);
  LL_I2C_EnableClockStretching(I2C1);
  I2C_InitStruct.PeripheralMode = LL_I2C_MODE_I2C;
  I2C_InitStruct.ClockSpeed = 100000;
  I2C_InitStruct.DutyCycle = LL_I2C_DUTYCYCLE_2;
  I2C_InitStruct.OwnAddress1 = 64;
  I2C_InitStruct.TypeAcknowledge = LL_I2C_ACK;
  I2C_InitStruct.OwnAddrSize = LL_I2C_OWNADDRESS1_7BIT;
  LL_I2C_Init(I2C1, &I2C_InitStruct);
  LL_I2C_SetOwnAddress2(I2C1, 0);
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  LL_I2C_InitTypeDef I2C_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOB);
  /**I2C2 GPIO Configuration
  PB10   ------> I2C2_SCL
  PB11   ------> I2C2_SDA
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_10|LL_GPIO_PIN_11;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_OPENDRAIN;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_I2C2);

  /* I2C2 interrupt Init */
  NVIC_SetPriority(I2C2_EV_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),1, 0));
  NVIC_EnableIRQ(I2C2_EV_IRQn);
  NVIC_SetPriority(I2C2_ER_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),1, 0));
  NVIC_EnableIRQ(I2C2_ER_IRQn);

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */

  /** I2C Initialization
  */
  LL_I2C_DisableOwnAddress2(I2C2);
  LL_I2C_DisableGeneralCall(I2C2);
  LL_I2C_EnableClockStretching(I2C2);
  I2C_InitStruct.PeripheralMode = LL_I2C_MODE_I2C;
  I2C_InitStruct.ClockSpeed = 100000;
  I2C_InitStruct.DutyCycle = LL_I2C_DUTYCYCLE_2;
  I2C_InitStruct.OwnAddress1 = 0;
  I2C_InitStruct.TypeAcknowledge = LL_I2C_ACK;
  I2C_InitStruct.OwnAddrSize = LL_I2C_OWNADDRESS1_7BIT;
  LL_I2C_Init(I2C2, &I2C_InitStruct);
  LL_I2C_SetOwnAddress2(I2C2, 0);
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  LL_SPI_InitTypeDef SPI_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_SPI1);

  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOA);
  /**SPI1 GPIO Configuration
  PA5   ------> SPI1_SCK
  PA6   ------> SPI1_MISO
  PA7   ------> SPI1_MOSI
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_5|LL_GPIO_PIN_7;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = LL_GPIO_PIN_6;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_FLOATING;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* SPI1 DMA Init */

  /* SPI1_TX Init */
  LL_DMA_SetDataTransferDirection(DMA1, LL_DMA_CHANNEL_3, LL_DMA_DIRECTION_MEMORY_TO_PERIPH);

  LL_DMA_SetChannelPriorityLevel(DMA1, LL_DMA_CHANNEL_3, LL_DMA_PRIORITY_MEDIUM);

  LL_DMA_SetMode(DMA1, LL_DMA_CHANNEL_3, LL_DMA_MODE_NORMAL);

  LL_DMA_SetPeriphIncMode(DMA1, LL_DMA_CHANNEL_3, LL_DMA_PERIPH_NOINCREMENT);

  LL_DMA_SetMemoryIncMode(DMA1, LL_DMA_CHANNEL_3, LL_DMA_MEMORY_INCREMENT);

  LL_DMA_SetPeriphSize(DMA1, LL_DMA_CHANNEL_3, LL_DMA_PDATAALIGN_BYTE);

  LL_DMA_SetMemorySize(DMA1, LL_DMA_CHANNEL_3, LL_DMA_MDATAALIGN_BYTE);

  /* SPI1_RX Init */
  LL_DMA_SetDataTransferDirection(DMA1, LL_DMA_CHANNEL_2, LL_DMA_DIRECTION_PERIPH_TO_MEMORY);

  LL_DMA_SetChannelPriorityLevel(DMA1, LL_DMA_CHANNEL_2, LL_DMA_PRIORITY_LOW);

  LL_DMA_SetMode(DMA1, LL_DMA_CHANNEL_2, LL_DMA_MODE_NORMAL);

  LL_DMA_SetPeriphIncMode(DMA1, LL_DMA_CHANNEL_2, LL_DMA_PERIPH_NOINCREMENT);

  LL_DMA_SetMemoryIncMode(DMA1, LL_DMA_CHANNEL_2, LL_DMA_MEMORY_INCREMENT);

  LL_DMA_SetPeriphSize(DMA1, LL_DMA_CHANNEL_2, LL_DMA_PDATAALIGN_BYTE);

  LL_DMA_SetMemorySize(DMA1, LL_DMA_CHANNEL_2, LL_DMA_MDATAALIGN_BYTE);

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  SPI_InitStruct.TransferDirection = LL_SPI_FULL_DUPLEX;
  SPI_InitStruct.Mode = LL_SPI_MODE_MASTER;
  SPI_InitStruct.DataWidth = LL_SPI_DATAWIDTH_8BIT;
  SPI_InitStruct.ClockPolarity = LL_SPI_POLARITY_LOW;
  SPI_InitStruct.ClockPhase = LL_SPI_PHASE_1EDGE;
  SPI_InitStruct.NSS = LL_SPI_NSS_SOFT;
  SPI_InitStruct.BaudRate = LL_SPI_BAUDRATEPRESCALER_DIV256;
  SPI_InitStruct.BitOrder = LL_SPI_MSB_FIRST;
  SPI_InitStruct.CRCCalculation = LL_SPI_CRCCALCULATION_DISABLE;
  SPI_InitStruct.CRCPoly = 10;
  LL_SPI_Init(SPI1, &SPI_InitStruct);
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  LL_USART_InitTypeDef USART_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_USART1);

  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOA);
  /**USART1 GPIO Configuration
  PA9   ------> USART1_TX
  PA10   ------> USART1_RX
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_9;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ALTERNATE;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = LL_GPIO_PIN_10;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_FLOATING;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USART1 DMA Init */

  /* USART1_TX Init */
  LL_DMA_SetDataTransferDirection(DMA1, LL_DMA_CHANNEL_4, LL_DMA_DIRECTION_MEMORY_TO_PERIPH);

  LL_DMA_SetChannelPriorityLevel(DMA1, LL_DMA_CHANNEL_4, LL_DMA_PRIORITY_LOW);

  LL_DMA_SetMode(DMA1, LL_DMA_CHANNEL_4, LL_DMA_MODE_NORMAL);

  LL_DMA_SetPeriphIncMode(DMA1, LL_DMA_CHANNEL_4, LL_DMA_PERIPH_NOINCREMENT);

  LL_DMA_SetMemoryIncMode(DMA1, LL_DMA_CHANNEL_4, LL_DMA_MEMORY_INCREMENT);

  LL_DMA_SetPeriphSize(DMA1, LL_DMA_CHANNEL_4, LL_DMA_PDATAALIGN_BYTE);

  LL_DMA_SetMemorySize(DMA1, LL_DMA_CHANNEL_4, LL_DMA_MDATAALIGN_BYTE);

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  USART_InitStruct.BaudRate = 9600;
  USART_InitStruct.DataWidth = LL_USART_DATAWIDTH_8B;
  USART_InitStruct.StopBits = LL_USART_STOPBITS_1;
  USART_InitStruct.Parity = LL_USART_PARITY_NONE;
  USART_InitStruct.TransferDirection = LL_USART_DIRECTION_TX_RX;
  USART_InitStruct.HardwareFlowControl = LL_USART_HWCONTROL_NONE;
  USART_InitStruct.OverSampling = LL_USART_OVERSAMPLING_16;
  LL_USART_Init(USART1, &USART_InitStruct);
  LL_USART_ConfigAsyncMode(USART1);
  LL_USART_Enable(USART1);
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USB Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_PCD_Init(void)
{

  /* USER CODE BEGIN USB_Init 0 */

  /* USER CODE END USB_Init 0 */

  /* USER CODE BEGIN USB_Init 1 */

  /* USER CODE END USB_Init 1 */
  hpcd_USB_FS.Instance = USB;
  hpcd_USB_FS.Init.dev_endpoints = 8;
  hpcd_USB_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_FS.Init.battery_charging_enable = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_Init 2 */

  /* USER CODE END USB_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel2_IRQn interrupt configuration */
  NVIC_SetPriority(DMA1_Channel2_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),0, 0));
  NVIC_EnableIRQ(DMA1_Channel2_IRQn);
  /* DMA1_Channel3_IRQn interrupt configuration */
  NVIC_SetPriority(DMA1_Channel3_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),0, 0));
  NVIC_EnableIRQ(DMA1_Channel3_IRQn);
  /* DMA1_Channel4_IRQn interrupt configuration */
  NVIC_SetPriority(DMA1_Channel4_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),0, 0));
  NVIC_EnableIRQ(DMA1_Channel4_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOC);
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOD);
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOA);
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOB);

  /**/
  LL_GPIO_SetOutputPin(GPIOC, LL_GPIO_PIN_13);

  /**/
  LL_GPIO_ResetOutputPin(GPIOA, LL_GPIO_PIN_4);

  /**/
  LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_13|LL_GPIO_PIN_14);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_13;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_MEDIUM;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  LL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_4;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_13|LL_GPIO_PIN_14;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_MEDIUM;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_3;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_UP;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */



void debugReworkedExamples(void){
	///here are code used in async non blocking function`s debug
	//debug begin , main() area
			//1)setup SPI
			customSpiFullduplexMasterSetup(LL_SPI_POLARITY_LOW,LL_SPI_PHASE_1EDGE,LL_SPI_BAUDRATEPRESCALER_DIV64,LL_SPI_MSB_FIRST,0);
			HAL_Delay(1);
			//1.1)Set amount of data, place of data
			spiMasterHeader.spiMasterTxPacketLength = 64;
			//From where get the data:
			spiMasterHeader.spiTxMasterBuffer = spiTxMasterBuffer;
			//Set amount of data to read:
			spiMasterHeader.spiMasterRxPacketLength = 64;
			//Where to stacking received data:
			spiMasterHeader.spiRxMasterBuffer = spiRxMasterBuffer;
			spiMasterHeader.ssPolarity = 0; //EN pin (SS) LOW active
			//OPTIONAL: insert a string into Tx buffer, there will be echo in Rx, because port was interconnected (physically)
	        memcpy((void*)spiTxMasterBuffer, (const void*)"Alice was beginning to get very tired of sitting by her sister o",64);
			//2)Send data through SPI (out->>-in) with interconnected signal wires (physically)
	        debug_var = masterFullduplexSpiDMA(&spiMasterHeader);
			 while (debug_var != SPI_COMPL) {
				 debug_var = masterFullduplexSpiDMA(&spiMasterHeader);

			 }

			 debug_var = masterFullduplexSpiDMA(&spiMasterHeader);
				 while (debug_var != SPI_COMPL) {
					 debug_var = masterFullduplexSpiDMA(&spiMasterHeader);

				 }
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

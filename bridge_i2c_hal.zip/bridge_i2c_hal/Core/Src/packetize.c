/*
 * packetize.c
 *
 *  Created on: Mar 6, 2026
 *      Author: Andrew
 */

#include "circ_fifo.h"
#include "packetize.h"
#include <string.h>

extern ring_t fifoHeaderGl; //decalred in main


int packetParcer (packet_params *pars) {
     int32_t dataAval = ring_available(&fifoHeaderGl);
	if (dataAval >= 4) {
		//when packet length have been already received
          ring_peek(&fifoHeaderGl, pars, 4);
        ///-------
		if (dataAval >= pars->packet_length ) {
            ///drain copied later data (packet info)
			   ring_drain(&fifoHeaderGl, 4);
			   dataAval -= 4;
			//when full packet was received - copy data directly into a buffer
             ring_pop(&fifoHeaderGl, pars->data, dataAval);
			//- return packet length
			return 0;
		}
		return -1;
	}
	return -1;
}


//NOTE: no need a buffer inside the pars, the data only copying from "payload" to the "packet store"
int assemblyPacketInRam(packet_params *pars, uint8_t* payload, uint8_t* packetStore) {
    //type of command, flags, packet size
    memcpy(packetStore,pars,4);
    //when payload exists-copy it into buffer
    if (pars->packet_length > 4) {
        memcpy(packetStore+4, payload, (pars->packet_length - 4) );
    }
    return 0;

}





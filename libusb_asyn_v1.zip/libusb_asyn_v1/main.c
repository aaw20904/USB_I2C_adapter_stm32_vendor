#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <stdbool.h>
#include "libusb_async_wr_v1.h"

#define USB_VID   0xCafe
#define USB_PID   0x4000
#define USB_BCD   0x0100

char testString[1024];
char fileText[1024];
FILE* myFile;
char* textPointer;

 const char myString[] = "Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book h";

int main()
{
    int tmp1;
    textPointer = testString;
    uint16_t reconnect = 0;
    char key = 0;
    uint16_t task = 0;
    int txStatus = 0;
    //open a file n text mode
    FILE* myFile = fopen("Bob.txt","r");
    if(myFile == NULL){
        printf("unale open Bob.txtt!");
        return -1;
    }
    ///usb code begin
    initLibraryX1(256,512,true);
    assignDeviceParamsForSearchX1(USB_PID, USB_VID, USB_BCD);

    while (key != 'q') {
                if ((reconnect & 0x00ff )== 0) {
            //when period was ellapsed
            printf("%d \n", attachUsbDevice(0x81));
       }
            //run until 'q' key was pressed
       if (_kbhit()) {
             key = _getch();
             if (key == 'q'){
                break;
             } else if (key == 's'){
                task=1;
             }
       }

       switch (task){
     case 1:  //read file and send transfer
        fread(fileText,64,1,myFile);
            txStatus = makeOutTransfer (fileText, 64, 0x01);
            task = 2;
        break;
     case 2:
            txStatus = makeOutTransfer (fileText, 64, 0x01);
            if (txStatus != USB_TR_PROGRESS) {
                //when transmission was finished
                task = 0;
                printf("Transmission done, err %d \n", txStatus);
             } else {
                 //when transmission is in progress now
             txStatus = makeOutTransfer (fileText, 64, 0x01);

             }
     break;
    default:
       }
       if  (task == 1 ) {


        }

       if (makeInTransfer() == LIBUSB_TRANSFER_COMPLETED){
          printf("IN transfer done OK! \n");
       }

       reconnect++;
       pushLibUsbEvents();
       tmp1 = newFifoDataAvalCount();
       if (tmp1 >= 64) {
         consumeDataFromFifo(textPointer,tmp1);
         textPointer += tmp1;
       }
       Sleep(2);
    }

    fclose(myFile);
    Sleep(100);

    while (deInitLibraryX1()!=0) {
         pushLibUsbEvents();
         Sleep(1);
    }
      printf("%s \n", testString);
    printf("Hello world!\n");
    getchar();
    return 0;
}

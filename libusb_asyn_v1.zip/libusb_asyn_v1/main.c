#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <stdbool.h>
#include "libusb_async_wr_v1.h"

#define USB_VID   0xCafe
#define USB_PID   0x4000
#define USB_BCD   0x0100

char testString[1024];
char fileText[1024];
FILE* myFile;
char* textPointer;

 const char myString[] = "Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book h";

int main()
{
    int tmp1;
    textPointer = testString;
    uint8_t reconnect = 0;
    char key = 0;
    uint16_t task = 0;
    int txStatus = 0;
    //open a file n text mode
    FILE* myFile = fopen("Alice.txt","r");
    if(myFile == NULL){
        printf("unale open Alice.txtt!");
        return -1;
    }
    ///usb code begin
    initLibraryX1(256,512,true);
    assignDeviceParamsForSearchX1(USB_PID, USB_VID, USB_BCD);

    while (key != 'q') {
                if ((reconnect & 0x1f )== 0) {
            //when period was ellapsed
            printf("%d \n", attachUsbDevice(0x81));
       }
            //run until 'q' key was pressed
       if (_kbhit()) {
             key = _getch();
             if (key == 'q'){
                break;
             } else if (key == 's'){
                task=1;
             }
       }
       if  (task == 1 ) {
            fread(fileText,64,1,myFile);
            txStatus = makeOutTransfer (fileText, 64, 0x01);
             if (txStatus != USB_TR_PROGRESS) {
                task = 0;
                printf("Transmission done! \n");
             }
        }

       makeInTransfer();
       reconnect++;
       pushLibUsbEvents();
       tmp1 = newFifoDataAvalCount();
       if (tmp1 >= 64) {
         consumeDataFromFifo(textPointer,tmp1);
         textPointer += tmp1;
       }
       Sleep(2);
    }

    fclose(myFile);
    freeInTransfer();
    Sleep(100);
    deInitLibraryX1();
      printf("%s \n", testString);
    printf("Hello world!\n");
    getchar();
    return 0;
}

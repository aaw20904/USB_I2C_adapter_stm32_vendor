#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include "libusb_async_wr_v1.h"
char key = 0;
#define USB_VID   0xCafe
#define USB_PID   0x4000
#define USB_BCD   0x0100
int main()
{
    initLibraryX1(64,512);
    assignDeviceParamsForSearchX1(USB_PID,USB_VID,USB_BCD);
    while(key == 0) {
       if (_kbhit()) {
             key = _getch();
             if (key == 'q'){
                break;
             }
       }
       printf("%d \n", attachUsbDevice());
        Sleep(1000);
    }

    deInitLibraryX1();
    printf("Hello world!\n");
    return 0;
}

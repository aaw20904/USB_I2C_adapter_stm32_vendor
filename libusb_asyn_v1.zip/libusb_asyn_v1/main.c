#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <stdbool.h>
#include "libusb_async_wr_v1.h"
#include "packetize.h"
#define USB_VID   0xCafe
#define USB_PID   0x4000
#define USB_BCD   0x0100

char testString[1024];
char fileText[1024];
char incomingPacketData[256];
char outgoingPacketData[256];
FILE* myFile;
char* textPointer;
int inStatus;
  const uint8_t testPack[]={0x01,0xab,0x0e,0x00,0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x0a,0xff,0xff};

 const char myString[] = "Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book h";

 packet_params  incomingPacketPars, outgoingPacketParams;





int main()
{

  /*  packPars.data = fileText;
    memset(packPars.data, 0, 32);

       memset(testString, 0, 32);

    assemblyPacketInRam(&packPars, myString, testString, 32, 3, 7);

    packetParser(testString,&packPars,3);
    packetParser(testString,&packPars,4);
    packetParser(testString,&packPars,6);
    packetParser(testString,&packPars,36);
*/





    int tmp1;
    textPointer = testString;
    uint16_t reconnect = 0;
    char key = 0;
    uint16_t task = 0;
    int txStatus = 0;
    incomingPacketPars.data = incomingPacketData;
    //open a file n text mode
    FILE* myFile = fopen("Bob.txt","rb");
    fseek(myFile,0,SEEK_SET);
    if(myFile == NULL){
        printf("unale open Bob.txtt!");
        return -1;
    }
    ///usb code begin
    initLibraryX1(256,512,true);
    assignDeviceParamsForSearchX1(USB_PID, USB_VID, USB_BCD);

    while (key != 'q') {
        if ((reconnect & 0x003f )== 0) {
          //when the period was ellapsed
          printf("%d \n", attachUsbDevice(0x81));
       }
            //run until 'q' key was pressed
       if (_kbhit()) {
             key = _getch();
             if (key == 'q'){
                break;
             } else if ((key == 's') && (task == 0) ){
                 //when the task (read & send to dev) is going - dont disturb it
                task=1;
             }
       }

       switch (task){
     case 1:  //read file firstly
          fread(fileText,1,60,myFile);

          //create a packet
          assemblyPacketInRam(&outgoingPacketParams,fileText,outgoingPacketData,60,3,8);
          task = 2;
        break;
     case 2:
         //the function is non blocking - run it until the finish
        txStatus = makeOutTransfer (outgoingPacketData, 64, 0x01);
        if (txStatus != USB_TR_PROGRESS) {
            //when transmission was finished
            task = 0;
            printf("Transmission done, err %d \n", txStatus);
         } else {
             //when transmission is in progress now

         }
     break;
    default:
       }
       if  (task == 1 ) {


        }
        inStatus = makeInTransfer();

       if ( inStatus != USB_TR_PROGRESS){
          printf("IN transfer status %d \n", inStatus );
       }

       reconnect++;
       pushLibUsbEvents();

      /* tmp1 = newFifoDataAvalCount();
       if (tmp1 >= 64) {
         consumeDataFromFifo(textPointer,tmp1);
         textPointer += tmp1;
       } */

       if( hasPacketRessembled(&incomingPacketPars)== PACK_DONE) {
        //plot packet params:
        printf("Comm: %d, Flags: %d, Total: %d \n",incomingPacketPars.type_of_command,incomingPacketPars.flags,incomingPacketPars.packet_length);
        printf("%s \n", incomingPacketPars.data);
       }
       Sleep(2);
    }

    fclose(myFile);
    Sleep(100);

    while (deInitLibraryX1()!=0) {
         pushLibUsbEvents();
         Sleep(1);
    }
      printf("%s \n", testString);
    printf("Hello world!\n");
    getchar();
    return 0;
}

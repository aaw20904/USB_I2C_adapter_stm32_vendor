#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <stdbool.h>
#include "libusb_async_wr_v1.h"
char key = 0;
#define USB_VID   0xCafe
#define USB_PID   0x4000
#define USB_BCD   0x0100
int main()
{

    initLibraryX1(64,512,true);
    assignDeviceParamsForSearchX1(USB_PID, USB_VID, USB_BCD);
    while(key == 0) {
       if (_kbhit()) {
             key = _getch();
             if (key == 'q'){
                break;
             }
       }
       printf("%d \n", attachUsbDevice());
        Sleep(100);
    }

    deInitLibraryX1();
    printf("Hello world!\n");
    getchar();
    return 0;
}

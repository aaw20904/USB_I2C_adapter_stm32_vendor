#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <stdbool.h>
#include "libusb_async_wr_v1.h"

#define USB_VID   0xCafe
#define USB_PID   0x4000
#define USB_BCD   0x0100
 const char myString[] = "Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book h";

int main()
{
    uint8_t reconnect = 0;
    char key = 0;
    uint16_t task = 0;
    int txStatus = 0;
    initLibraryX1(128,512,true);
    assignDeviceParamsForSearchX1(USB_PID, USB_VID, USB_BCD);

    while (key != 'q') {
                if ((reconnect & 0x1f )== 0) {
            //when period was ellapsed
            printf("%d \n", attachUsbDevice(0x81));
       }
            //run until 'q' key was pressed
       if (_kbhit()) {
             key = _getch();
             if (key == 'q'){
                break;
             } else if (key == 's'){
                task=1;
             }
       }
        if (task == 1 ) {

            txStatus = makeOutTransfer (myString, 64, 0x01);
             if (txStatus != USB_TR_PROGRESS) {
                task = 0;
                printf("Transmission done! \n");
             }
        }

       if( makeInTransfer() == 0){

       }


       reconnect++;
       pushLibUsbEvents();
       Sleep(2);
    }

    freeInTransfer();
    Sleep(100);
    deInitLibraryX1();
    printf("Hello world!\n");
    getchar();
    return 0;
}

#include "libusb_load.h"
#include "libusb.h"
#include "libusb_async_wr_v1.h"
#include "string.h"
#include <stdlib.h>
#include <stdio.h>

//a strtucture with PID, HID, device handle and physical state .Must be initialized
usbDeviceState myUsbDeviceHead;
usrEpBuffers userEndpointsArrays;
libusb_context *myLibUsbContext;

int initLibraryX1( uint16_t fifoSize, uint16_t  endpointsRamSize) {
  myUsbDeviceHead.myDevicehandle = NULL; //util will opened any device
    //1)Upload  executable code from the .dll inside app
 if (load_libusb() != 0) {
    return -1;
 }
   //2)Allocate memory for the FIFO (IN endpoint stream reconstructing)
  userEndpointsArrays.fifosArray = malloc(fifoSize);
  userEndpointsArrays.inEpArray = malloc(endpointsRamSize);
  userEndpointsArrays.outEpArray = malloc(endpointsRamSize);
  if ( (userEndpointsArrays.fifosArray == NULL) || (userEndpointsArrays.inEpArray== NULL) || (userEndpointsArrays.outEpArray== NULL) ) {
   return -1;
  }
  //initializing the libusb context
  if (libusb_init_d(&myLibUsbContext) != 0) {
    myLibUsbContext = NULL;
    return -1;
  }

  //3)When OK
  return 0;
}
//must be initialized!
void assignDeviceParamsForSearchX1(uint16_t pid, uint16_t vid, uint16_t bcd ){
  myUsbDeviceHead.pid = pid;
  myUsbDeviceHead.vid = vid;
  myUsbDeviceHead.bcd = bcd;
}

int deInitLibraryX1 ( void ) {
    //close a device
    if (myUsbDeviceHead.myDevicehandle != NULL) {
        //release interface
        libusb_release_interface_d (myUsbDeviceHead.myDevicehandle,0);
        //close device
        libusb_close_d (myUsbDeviceHead.myDevicehandle);
    }
       //1)free memory, if exist
     if (userEndpointsArrays.fifosArray != NULL) {
        free(userEndpointsArrays.fifosArray);
     }

     if (userEndpointsArrays.inEpArray != NULL) {
        free(userEndpointsArrays.inEpArray);
     }

     if (userEndpointsArrays.outEpArray != NULL) {
        free(userEndpointsArrays.outEpArray);
     }
      //close cotext of libusb
      if (myLibUsbContext != NULL) {
        libusb_exit_d(myLibUsbContext);
      }

       //2)release RAM from executable code of DLL, uploaded lated
      unload_libusb();
      return 0;
}
//This function requires a list of connected devices from a system,
// when a device was disconnected and appeared again - connect, get descriptor, clam and connect it again
// when a device was connected and disappeared again - close the device, claims the interface
   int findUsbDeviceX1 (void) {
       libusb_device* myDevice = NULL;
       libusb_device**  listOfConnected;
       ssize_t     howManyWasFound;
       struct libusb_device_descriptor  myDevDescriptor;

       //1) get the list of connected devices
       howManyWasFound = libusb_get_device_list_d(myLibUsbContext, &listOfConnected);

       if (howManyWasFound == 0) {
            //no connected devices was found
            libusb_free_device_list_d(listOfConnected,0);
            //clear handle
            myUsbDeviceHead.myDevicehandle = NULL;
             return 0;
       }
       //2)Iterate devices
       for (int devI=0; devI<howManyWasFound; devI++) {
             //a)get descriptor
             libusb_get_device_descriptor_d( listOfConnected[devI],&myDevDescriptor);
             //b)Compare PID, VID
             if ((myDevDescriptor.bcdDevice == myUsbDeviceHead.bcd) && (myDevDescriptor.idProduct == myUsbDeviceHead.pid) && (myDevDescriptor.idVendor == myUsbDeviceHead.vid)){
                //when matched - assign a device
                myDevice = listOfConnected[devI];
                break;
             }
       }
       //if the device with exactly PID, VID was found:
       if (myDevice != NULL) {
            //3)Connection with libusb_open
             if (libusb_open_d(myDevice, &myUsbDeviceHead.myDevicehandle) != 0){
                    //when open was fail
                libusb_free_device_list_d(listOfConnected,0);
                //clear handle
               myUsbDeviceHead.myDevicehandle = NULL;
                return -1;
             }
            //4)Claim the interface with number 0
             if (libusb_claim_interface_d(myUsbDeviceHead.myDevicehandle,0) !=0 ){
               return -1;
             }
              //5)Clean the list
            libusb_free_device_list_d(listOfConnected,0);
            return 0;

       } else {
          //clear handle, because device ws not found
            myUsbDeviceHead.myDevicehandle = NULL;
            //5)Clean the  list
            libusb_free_device_list_d(listOfConnected,0);
            return 1;
       }





   }





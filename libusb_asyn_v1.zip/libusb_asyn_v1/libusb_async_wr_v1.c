#include "libusb_load.h"
#include "libusb.h"
#include "libusb_async_wr_v1.h"
#include "string.h"
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include "ring_fifo.h"
///Author: Andrii Androsovych
/***
1)move function states to a structure  "usbDevTransfers" to make access to it outside the functions (for IN/OUT transfer sending)
2)Run periodically the function "runUsbProcesses" in the following way:
   -when both transfers IDLE - do nothing to avoid long stucking on 1 minute
   -when any transfer in PROGRESS - run libusb_handle_events();
BENEFIT: less races.

***/


#define IN_ENDP_TRANSFER_SIZE 64



//a strtucture with PID, HID, device handle and physical state .Must be initialized
usbDeviceState myUsbDeviceHead;

libusb_context *myLibUsbContext;
//transfers and memory buffers for IN FIFO and endpoints
usbDevTransfers myTransfers;
//a timeout for transfers
struct timeval trTimeouts;

 void  dbgMessageCallback (libusb_context *ctx, enum libusb_log_level level, const char *str) {
     //NOTE When the console is not available in app - use OWN ,another callback realization to avoid app crash
   printf("%s , \n", str);
 }

 void outUserCallback (struct libusb_transfer *transfer) {
    int* done;
    //when the data was sent/error/cancelled/timeout - set the flag "done"

    done = (int*)transfer->user_data;
    *done = 1;
            //save the status in user structure

 }

  void inUserCallback (struct libusb_transfer *transfer) {
    int* done;
    //when the data was sent/error/cancelled/timeout - set the flag "done"

    done = (int*)transfer->user_data;
    *done = 1;
            //save the status in user structure
 }

 ///==========INIT===IN===TANSFERS============
 //this function allocates and fill libusb_transfer to  have a ready transfer object to sending to OK kernel
 //The same does  the attachUsbDevice function,when it was called.So maybe it is useless
 int allocateInTransfer (uint8_t endPoint) {
      //allocate transfer
      myTransfers.inTransfer = libusb_alloc_transfer_d(0);
      //fill the one
            //preaparing the transfer
      libusb_fill_bulk_transfer(myTransfers.inTransfer,
                               myUsbDeviceHead.myDevicehandle,
                               endPoint,
                                myTransfers.inEpArray,
                                IN_ENDP_TRANSFER_SIZE,  //64 bytes - IN packet size
                                inUserCallback,
                                &myTransfers.inCbDone, //the flag "a callback was done recently"
                                0); //infinity, the host waiting until new transfer
                    return 0;

 }
 //to clean libusb_transfer object, when it is in progress.The function closeLibrary do the same
 int freeInTransfer (void) {
     static int flow = 2;
     switch (flow){
   case 2:
        //when any transfer is in progress - remove it firstly
        if (myTransfers.inTransferFlow == USB_TR_PROGRESS) {
            libusb_cancel_transfer_d(myTransfers.inTransfer);
            flow = 1;
            return flow;
        }  else {
            //when no current transfer is running - clean iimediately
            if (myTransfers.inTransfer != NULL) {
                libusb_free_transfer_d(myTransfers.inTransfer);
                myTransfers.inTransfer = NULL;
                flow = 2;
                return 0;
            }

        }
    break;
   case 1:
       if (myTransfers.inCbDone == 1) {
            myTransfers.inCbDone = 0;
            //when cancel event was happened and callback has been called
            if (myTransfers.inTransfer != NULL) {
                libusb_free_transfer_d(myTransfers.inTransfer);
                myTransfers.inTransfer = NULL;
                flow = 2;
                return 0;
            }
       } else {
       //hen cancel is in progress
       return flow;
       }
    break;
     }

      if (myTransfers.inTransfer != NULL) {
         libusb_free_transfer_d(myTransfers.inTransfer);
         myTransfers.inTransfer = NULL;
      }
 }

 ///============OUT===TRANSFER==========
 int makeOutTransfer(uint8_t *parcel, uint16_t dataSize, uint8_t endPoint) {
    static int transferDone = 0; //it is the indicator "a callback was processed"
   int sysErr;
   //was a device open?
   if (myUsbDeviceHead.myDevicehandle == NULL){
        //when not open- returns error
    return LIBUSB_ERROR_NO_DEVICE;
   }
   switch (myTransfers.outTransferFlow){
 case USB_TR_IDLE:
     //allocate memory for the transfer:

     myTransfers.outTransfer = libusb_alloc_transfer_d(0);
      //preaparing the transfer
     libusb_fill_bulk_transfer(myTransfers.outTransfer,
                               myUsbDeviceHead.myDevicehandle,
                               endPoint,
                                parcel,
                                dataSize,
                                outUserCallback,
                                &myTransfers.outCbDone,
                                5000);
      //send to the core
      sysErr = libusb_submit_transfer_d(myTransfers.outTransfer);
    if (sysErr != 0) {

        //release resources
         libusb_free_transfer_d(myTransfers.outTransfer);
         myTransfers.outTransfer = NULL;
         myTransfers.outTransferFlow = USB_TR_IDLE;
         /* sysErr may be: LIBUSB_ERROR_NO_DEVICE,
          LIBUSB_ERROR_INVALID_PARAM ,
          LIBUSB_ERROR_BUSY,
          LIBUSB_ERROR_NOT_SUPPORTED, */
         return sysErr;
    } else {
    //the request was sent successfully  :
       myTransfers.outTransferFlow = USB_TR_PROGRESS;
       //handling events - but outside this function
         /*libusb_handle_events_d(myLibUsbContext);*/
       return myTransfers.outTransferFlow;
    }

    break;
 case USB_TR_PROGRESS:
     //has transfer been finished?
     if (myTransfers.outCbDone) {
           // The transfer was finished (success/error/timeout/cancel)
        myTransfers.outCbDone = 0;
        //save status
        sysErr = myTransfers.outTransfer->status;

        //when the device was disappeared occasionally:
        if (sysErr == LIBUSB_TRANSFER_NO_DEVICE) {

             ///release interface 0
                libusb_release_interface_d (myUsbDeviceHead.myDevicehandle,0);
               //close the device
                libusb_close_d (myUsbDeviceHead.myDevicehandle);
                //assign null to a pointer
                myUsbDeviceHead.myDevicehandle = NULL;

        }
        //clean resources
        libusb_free_transfer_d(myTransfers.outTransfer);
        myTransfers.outTransfer = NULL;
        myTransfers.outTransferFlow = USB_TR_IDLE;
        printf("status of OUT transfer: %d /n", sysErr);
        //return error code to user
        return sysErr;
     } else {
         //transfer was not finished - handle events ,outside this function
          // libusb_handle_events_d(myLibUsbContext);
          return myTransfers.outTransferFlow;
     }
    break;
 default:
    return -1;

   }
 }
 ///=================IN====TRANSFERS==========
 int makeInTransfer(void) {
     int result;
     if ( myUsbDeviceHead.myDevicehandle == NULL) {
            //when a device was not opened:
        return LIBUSB_ERROR_NO_DEVICE;
     }
    //states switch
    switch (myTransfers.inTransferFlow) {
      case USB_TR_IDLE:

          if (myTransfers.inTransfer == NULL) {
                //when transfer was not allocated:
             return LIBUSB_ERROR_NO_DEVICE;
          }

          //send transfer to OS kernel:
          result = libusb_submit_transfer_d(myTransfers.inTransfer);
          if (result != 0) {
            //when error happened
            myTransfers.inTransferFlow= USB_TR_IDLE;
            return result;
          } else {
              myTransfers.inTransferFlow = USB_TR_PROGRESS;
              return myTransfers.inTransferFlow;
          }
        break;
      case USB_TR_PROGRESS:
          //has the transfer done?
         if (myTransfers.inCbDone) {
            myTransfers.inCbDone = 0;
            myTransfers.inTransferFlow = USB_TR_IDLE;
            result = myTransfers.inTransfer->status;
             if (result == LIBUSB_TRANSFER_COMPLETED){
                //when success - move data into FIFO:
                ring_push(&myTransfers.rxFifoHeader, myTransfers.inTransfer->buffer, myTransfers.inTransfer->actual_length );
                return result;
             } else {
               //return error code, no any push inside the fIFO
                //when the device was disappeared occasionally:
                    if (result == LIBUSB_TRANSFER_NO_DEVICE) {

                         ///release interface 0
                            libusb_release_interface_d (myUsbDeviceHead.myDevicehandle,0);
                           //close the device
                            libusb_close_d (myUsbDeviceHead.myDevicehandle);
                            //assign null to a pointer
                            myUsbDeviceHead.myDevicehandle = NULL;
                            //free transfer
                            libusb_free_transfer_d(myTransfers.inTransfer);
                            myTransfers.inTransfer = NULL;
                    }
               return result;
             }
         } else {
             //when transfer is in progress yet
            return myTransfers.inTransferFlow;
         }
        break;

    }
 }

 ///run it periodically to handle events
 //==============================================================================
 void pushLibUsbEvents (void) {


          libusb_handle_events_timeout_completed_d(myLibUsbContext,&trTimeouts,NULL);

}



///library initialization

int initLibraryX1( uint16_t fifoSize, uint16_t  endpointsRamSize, bool debug ) {
  myUsbDeviceHead.myDevicehandle = NULL; //util will opened any device
  //write  zeros in transfer pointers to avoid running with "garbage pointer":
  myTransfers.outTransferFlow = USB_TR_IDLE;
  myTransfers.inTransferFlow = USB_TR_IDLE;
  myTransfers.inTransfer = NULL;
  myTransfers.outTransfer = NULL;
  //timeouts
  trTimeouts.tv_sec = 0;
  trTimeouts.tv_usec = 0;
    //1)Upload  executable code from the .dll inside app
 if (load_libusb() != 0) {
    return -1;
 }
   //2)Allocate memory for the FIFO (IN endpoint stream reconstructing)
  myTransfers.fifosArray = malloc(fifoSize);
  myTransfers.inEpArray = malloc(endpointsRamSize);
  myTransfers.outEpArray = malloc(endpointsRamSize);
  if ( (myTransfers.fifosArray == NULL) || (myTransfers.inEpArray == NULL) || (myTransfers.outEpArray== NULL) ) {
   return -1;
  }
  //3)initializing the libusb context
  if (libusb_init_d(&myLibUsbContext) != 0) {
    myLibUsbContext = NULL;
    return -1;
  }
  //4) Init FIFO, to be ready for working with the fifo (only IN endpoint uses FIFO for reconstruct stream):
    ring_init(&myTransfers.rxFifoHeader, myTransfers.fifosArray,fifoSize);
   //4)add debug features
     if (debug) {
            myUsbDeviceHead.isDebug = true;
            //turn debug info , set debug message level
           libusb_set_debug_d(myLibUsbContext, LIBUSB_LOG_LEVEL_WARNING);
           //attach the callback to the given context
           libusb_set_log_cb_d(myLibUsbContext, dbgMessageCallback, LIBUSB_LOG_CB_CONTEXT);
     }

  //end) When OK
  return 0;
}
//must be initialized!
void assignDeviceParamsForSearchX1 (uint16_t pid, uint16_t vid, uint16_t bcd ) {
  myUsbDeviceHead.pid = pid;
  myUsbDeviceHead.vid = vid;
  myUsbDeviceHead.bcd = bcd;
};
///library deinitialization
int deInitLibraryX1 ( void ) {
    //close a device
    if (myUsbDeviceHead.myDevicehandle != NULL) {
        //release interface
        libusb_release_interface_d (myUsbDeviceHead.myDevicehandle,0);
        //close device
        libusb_close_d (myUsbDeviceHead.myDevicehandle);
        myUsbDeviceHead.myDevicehandle = NULL;
    }
       //1)free memory, if exist
     if (myTransfers.fifosArray != NULL) {
        free(myTransfers.fifosArray);
     }

     if (myTransfers.inEpArray != NULL) {
        free(myTransfers.inEpArray);
     }

     if (myTransfers.outEpArray != NULL) {
        free(myTransfers.outEpArray);
     }
      //close cotext of libusb
      if (myLibUsbContext != NULL) {
        libusb_exit_d(myLibUsbContext);
      }

       //2)release RAM from executable code of DLL, uploaded lated
      unload_libusb();
      return 0;
}
//This function requires a list of connected devices from a system,
// when a device was disconnected and appeared again - connect, get descriptor, clam and connect it again
// when a device was connected and disappeared again - close the device, claims the interface
   int findUsbDeviceX1 (void) {
       libusb_device* myDevice = NULL;
       libusb_device**  listOfConnected;
       ssize_t     howManyWasFound;
       struct libusb_device_descriptor  myDevDescriptor;

       //1) get the list of connected devices
       howManyWasFound = libusb_get_device_list_d(myLibUsbContext, &listOfConnected);

       if (howManyWasFound == 0) {
            //no connected devices was found
            libusb_free_device_list_d(listOfConnected,1);
            //clear handle
            myUsbDeviceHead.myDevicehandle = NULL;
             return 0;
       }
       //2)Iterate devices
       for (int devI=0; devI<howManyWasFound; devI++) {
             //a)get descriptor
             libusb_get_device_descriptor_d( listOfConnected[devI],&myDevDescriptor);
             //b)Compare PID, VID
             if ((myDevDescriptor.bcdDevice == myUsbDeviceHead.bcd) && (myDevDescriptor.idProduct == myUsbDeviceHead.pid) && (myDevDescriptor.idVendor == myUsbDeviceHead.vid)){
                //when matched - assign a device
                myDevice = listOfConnected[devI];
                break;
             }
       }
       //if the device with exactly PID, VID was found:
       if (myDevice != NULL) {
            //3)Connection with libusb_open
             if (libusb_open_d(myDevice, &myUsbDeviceHead.myDevicehandle) != 0){
                    //when open was fail
                libusb_free_device_list_d(listOfConnected,1);
                //clear handle
               myUsbDeviceHead.myDevicehandle = NULL;
                return -1;
             }
            //4)Claim the interface with number 0
             if (libusb_claim_interface_d(myUsbDeviceHead.myDevicehandle,0) !=0 ){
                //close device
                libusb_close_d (myUsbDeviceHead.myDevicehandle);
                libusb_free_device_list_d(listOfConnected,1);
               return -1;
             }
              //5)Clean the list
            libusb_free_device_list_d(listOfConnected,1);
            return 0;

       } else {
          //clear handle, because device ws not found
            myUsbDeviceHead.myDevicehandle = NULL;
            //5)Clean the  list
            libusb_free_device_list_d(listOfConnected,1);
            return 1;
       }


   }
  ///iterate a list of connected devices, find interested device
  /*1)When disconnected: case a: handle =  NULL -> do nothing;
                         case b: handle != NULL -> release interface, disconnect, assign NULL to the handle
                         --------------------------------------------------
    2)When connected:    case a: handle = NULL  -> connect, claim interface
                         case b: handle != NULL ->  do nothing
    */
  int attachUsbDevice(uint8_t inEndpNumber){
      //when any endpoint is doing transfer (in progress) - don`t run this function to avoid races
      if (myTransfers.inTransferFlow == USB_TR_PROGRESS || myTransfers.outTransferFlow == USB_TR_PROGRESS) {
        return 0xff; //busy
      }
        libusb_device* myDevice = NULL;  //interested device
       libusb_device**  listOfConnected;
       ssize_t     howManyWasFound;  //length of the list
       struct libusb_device_descriptor  myDevDescriptor;  //device descriptor

       //1) get the list of connected devices
       howManyWasFound = libusb_get_device_list_d(myLibUsbContext, &listOfConnected);

       //when there was any error when the list was required:
       if (howManyWasFound < 0) {
            libusb_free_device_list_d(listOfConnected,1);
        return -1;
       }
        ///when was found any USB devcie on the bus of the host:
       if (howManyWasFound > 0) {
        //when something device(s) was found - iterate the list

               for (int devI=0; devI < howManyWasFound; devI++) {
                 //a)get the descriptor
                 libusb_get_device_descriptor_d( listOfConnected[devI],&myDevDescriptor);
                 //b)Compare PID, VID
                     if ((myDevDescriptor.bcdDevice == myUsbDeviceHead.bcd) && (myDevDescriptor.idProduct == myUsbDeviceHead.pid) && (myDevDescriptor.idVendor == myUsbDeviceHead.vid)){
                        //when PID, VID, BCD was matched - assign the device to the pointer
                        myDevice = listOfConnected[devI];
                        break;
                     }
              }
       }
       /*now we know - is device on a physical host`s  bus or not  */
       /*<<<< So, the first case - the DEVICE IS IN SYSTEM NOW (present now) >>>>*/
       if (myDevice != NULL) {
            //a) Was the device connected later?
            if (myUsbDeviceHead.myDevicehandle == NULL)  {
                 //1)when was disconnected - re-connect again

                 if (libusb_open_d(myDevice, &myUsbDeviceHead.myDevicehandle) != 0){
                        //when open was fail clean the list
                    libusb_free_device_list_d(listOfConnected,1);
                    //clear handle
                   myUsbDeviceHead.myDevicehandle = NULL;
                    return -1;
                 }


                 //2)Claim the interfce with number 0:
                 if (libusb_claim_interface_d(myUsbDeviceHead.myDevicehandle,0) !=0 ){
                       //when claim was fail -  close the device
                    libusb_close_d (myUsbDeviceHead.myDevicehandle);
                       //free the list
                    libusb_free_device_list_d(listOfConnected,1);
                        //clear handle
                   myUsbDeviceHead.myDevicehandle = NULL;
                   return -1;
                 }
                 //allocate a new transfer
                   if (myTransfers.inTransfer == NULL){
                     myTransfers.inTransfer = libusb_alloc_transfer_d(0);
                   }


                       libusb_fill_bulk_transfer(myTransfers.inTransfer,
                               myUsbDeviceHead.myDevicehandle,
                               inEndpNumber,
                                myTransfers.inEpArray,
                                IN_ENDP_TRANSFER_SIZE,  //64 bytes - IN packet size
                                inUserCallback,
                                &myTransfers.inCbDone, //the flag "a callback was done recently"
                                0); //infinity, the host waiting until new transfer

            }
            ///when a device was already connect later - do nothing, only clean the list
           libusb_free_device_list_d(listOfConnected,1);
           return 1;

       } else {

        /*<<<<< So, the second case - the DEVICE IS NOT IN SYSTEM NOW (absent) >>>>>*/
        //a) Was the device connected later?
            if (myUsbDeviceHead.myDevicehandle != NULL)  {
                 //free IN object, assign null, to avoid using in Rx operations:
                 if (myTransfers.inTransfer != NULL) {
                    libusb_free_transfer_d(myTransfers.inTransfer);
                 }

                myTransfers.inTransfer = NULL;
                ///release interface 0
                libusb_release_interface_d (myUsbDeviceHead.myDevicehandle,0);
               //close the device
                libusb_close_d (myUsbDeviceHead.myDevicehandle);
                //assign null to a pointer
                myUsbDeviceHead.myDevicehandle = NULL;

            }
            ///when device was disconnected in past - do nothing
            //clean the list
             libusb_free_device_list_d(listOfConnected,1);
             return 0;
       }

  }
   //how many data available in FIFO
 uint32_t newFifoDataAvalCount(void) {
    return ring_available(&myTransfers.rxFifoHeader);
  }

  uint32_t consumeDataFromFifo(uint8_t* dest, int amount) {
     ring_pop(&myTransfers.rxFifoHeader,dest,amount);
  }



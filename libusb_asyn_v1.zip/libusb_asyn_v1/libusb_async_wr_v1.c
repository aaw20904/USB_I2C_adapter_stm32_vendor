#include "libusb_load.h"
#include "libusb.h"
#include "libusb_async_wr_v1.h"


//a strtucture with PID, HID, device handle and physical state .Must be initialized
usbDeviceState myDeviceHead;

#include "libusb_load.h"
#include "libusb.h"
#include "libusb_async_wr_v1.h"
#include "string.h"
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>
#include "ring_fifo.h"
///Author: Andrii Androsovych
/***
1)move function states to a structure  "usbDevTransfers" to make access to it outside the functions (for IN/OUT transfer sending)
2)Run periodically the function "runUsbProcesses" in the following way:
   -when both transfers IDLE - do nothing to avoid long stucking on 1 minute
   -when any transfer in PROGRESS - run libusb_handle_events();
BENEFIT: less races.

***/


#define IN_ENDP_TRANSFER_SIZE 64

 //int deInitializationFlow1;
//a strtucture with PID, HID, device handle and physical state .Must be initialized
//usbDeviceState myUsbDeviceHead;

//libusb_context *myLibUsbContext;
//transfers and memory buffers for IN FIFO and endpoints
//usbDevTransfers myTransfers;
//a timeout for transfers
//struct timeval trTimeouts;

//ring_t rxFifoHeader;

 void  dbgMessageCallback (libusb_context *ctx, enum libusb_log_level level, const char *str) {
     //NOTE When the console is not available in app - use OWN ,another callback realization to avoid app crash
   printf("%s , \n", str);
 }

 void outUserCallback (struct libusb_transfer *transfer) {
    int* done;
    //when the data was sent/error/cancelled/timeout - set the flag "done"

    done = (int*)transfer->user_data;
    *done = 1;
            //save the status in user structure

 }

  void inUserCallback (struct libusb_transfer *transfer) {
    int* done;
    //when the data was sent/error/cancelled/timeout - set the flag "done"

    done = (int*)transfer->user_data;
    *done = 1;
            //save the status in user structure
 }

 ///==========INIT===IN===TANSFERS============
 //this function allocates and fill libusb_transfer to  have a ready transfer object to sending to OK kernel
 //The same does  the attachUsbDevice function,when it was called.So maybe it is useless
 int allocateInTransfer (wrpUsbCtx* wrpCtx, uint8_t endPoint) {
      //allocate transfer
      wrpCtx->myTransfers.inTransfer = libusb_alloc_transfer_d(0);
      //fill the one
            //preaparing the transfer
      libusb_fill_bulk_transfer(wrpCtx->myTransfers.inTransfer,
                               wrpCtx->myUsbDeviceHead.myDevicehandle,
                               endPoint,
                                wrpCtx->myTransfers.inEpArray,
                                IN_ENDP_TRANSFER_SIZE,  //64 bytes - IN packet size
                                inUserCallback,
                                 &wrpCtx->myTransfers.inCbDone, //the flag "a callback was done recently"
                                0); //infinity, the host waiting until new transfer
                    return 0;

 }
 //to clean libusb_transfer object, when it is in progress.The function closeLibrary do the same
 int freeInTransfer (wrpUsbCtx* wrpCtx) {
     static int flow = 2;
     switch (flow){
   case 2:
        //when any transfer is in progress - remove it firstly
        if (wrpCtx->myTransfers.inTransferFlow == USB_TR_PROGRESS) {
            libusb_cancel_transfer_d(wrpCtx->myTransfers.inTransfer);
            flow = 1;
            return flow;
        }  else {
            //when no current transfer is running - clean iimediately
            if ( wrpCtx->myTransfers.inTransfer != NULL) {
                libusb_free_transfer_d(wrpCtx->myTransfers.inTransfer);
                wrpCtx->myTransfers.inTransfer = NULL;
                flow = 2;
                return 0;
            }

        }
    break;
   case 1:
       if (wrpCtx->myTransfers.inCbDone == 1) {
            wrpCtx->myTransfers.inCbDone = 0;
            //when cancel event was happened and callback has been called
            if (wrpCtx->myTransfers.inTransfer != NULL) {
                libusb_free_transfer_d( wrpCtx->myTransfers.inTransfer);
                wrpCtx->myTransfers.inTransfer = NULL;
                flow = 2;
                return 0;
            }
       } else {
       //hen cancel is in progress
       return flow;
       }
    break;
     }

      if (wrpCtx->myTransfers.inTransfer != NULL) {
         libusb_free_transfer_d(wrpCtx->myTransfers.inTransfer);
         wrpCtx->myTransfers.inTransfer = NULL;
      }
      return 0xffffffff;
 }

 ///============OUT===TRANSFER==========
 int makeOutTransfer(wrpUsbCtx* wrpCtx, uint8_t *parcel, uint16_t dataSize, uint8_t endPoint) {

   int sysErr;
   //was a device open?
   if (wrpCtx->myUsbDeviceHead.myDevicehandle == NULL){
        //when not open- returns error
    return LIBUSB_ERROR_NO_DEVICE;
   }
   switch (wrpCtx->myTransfers.outTransferFlow){
 case USB_TR_IDLE:
     //allocate memory for the transfer:

     wrpCtx->myTransfers.outTransfer = libusb_alloc_transfer_d(0);
      //preaparing the transfer
     libusb_fill_bulk_transfer(wrpCtx->myTransfers.outTransfer,
                               wrpCtx->myUsbDeviceHead.myDevicehandle,
                               endPoint,
                                parcel,
                                dataSize,
                                outUserCallback,
                                &wrpCtx->myTransfers.outCbDone,
                                5000);
      //send to the core
      sysErr = libusb_submit_transfer_d(wrpCtx->myTransfers.outTransfer);
    if (sysErr != 0) {

        //release resources
         libusb_free_transfer_d(wrpCtx->myTransfers.outTransfer);
         wrpCtx->myTransfers.outTransfer = NULL;
         wrpCtx->myTransfers.outTransferFlow = USB_TR_IDLE;
         /* sysErr may be: LIBUSB_ERROR_NO_DEVICE,
          LIBUSB_ERROR_INVALID_PARAM ,
          LIBUSB_ERROR_BUSY,
          LIBUSB_ERROR_NOT_SUPPORTED, */
         return sysErr;
    } else {
    //the request was sent successfully  :
       wrpCtx->myTransfers.outTransferFlow = USB_TR_PROGRESS;
       //handling events - but outside this function
         /*libusb_handle_events_d(myLibUsbContext);*/
       return wrpCtx->myTransfers.outTransferFlow;
    }

    break;
 case USB_TR_PROGRESS:
     //has transfer been finished?
     if (wrpCtx->myTransfers.outCbDone) {
           // The transfer was finished (success/error/timeout/cancel)
        wrpCtx->myTransfers.outCbDone = 0;
        //save status
        sysErr = wrpCtx->myTransfers.outTransfer->status;

        //when the device was disappeared occasionally:
        if (sysErr == LIBUSB_TRANSFER_NO_DEVICE) {

             ///release interface 0
                libusb_release_interface_d (wrpCtx->myUsbDeviceHead.myDevicehandle,0);
               //close the device
                libusb_close_d (wrpCtx->myUsbDeviceHead.myDevicehandle);
                //assign null to a pointer
                wrpCtx->myUsbDeviceHead.myDevicehandle = NULL;

        }
        //clean resources
        libusb_free_transfer_d(wrpCtx->myTransfers.outTransfer);
        wrpCtx->myTransfers.outTransfer = NULL;
        wrpCtx->myTransfers.outTransferFlow = USB_TR_IDLE;
        printf("status of OUT transfer: %d /n", sysErr);
        //return error code to user
        return sysErr;
     } else {
         //transfer was not finished - handle events ,outside this function
          // libusb_handle_events_d(myLibUsbContext);
          return wrpCtx->myTransfers.outTransferFlow;
     }
    break;
 default:
    return -1;

   }
 }
 ///=================IN====TRANSFERS==========
 /*Call this statefull non blocking function several times , while USB_TR_PROGRESS returned.
 When uses FIFO, it must call continuously in the infinite "USB loop"   */

 int makeInTransfer(wrpUsbCtx* wrpCtx) {
     int result;
     if ( wrpCtx->myUsbDeviceHead.myDevicehandle == NULL) {
            //when a device was not opened:
        return LIBUSB_ERROR_NO_DEVICE;
     }
    //states switch
    switch (wrpCtx->myTransfers.inTransferFlow) {
      case USB_TR_IDLE:

          if (wrpCtx->myTransfers.inTransfer == NULL) {
                //when transfer was not allocated:
             return LIBUSB_ERROR_NO_DEVICE;
          }

          //send transfer to OS kernel:
          result = libusb_submit_transfer_d(wrpCtx->myTransfers.inTransfer);
          if (result != 0) {
            //when error happened during sending transfer to the OS kernel:
            wrpCtx->myTransfers.inTransferFlow= USB_TR_IDLE;
            return result;
          } else {
              wrpCtx->myTransfers.inTransferFlow = USB_TR_PROGRESS;
              return wrpCtx->myTransfers.inTransferFlow;
          }
        break;
      case USB_TR_PROGRESS:
          //has the transfer done?
         if (wrpCtx->myTransfers.inCbDone) {
            wrpCtx->myTransfers.inCbDone = 0;
            wrpCtx->myTransfers.inTransferFlow = USB_TR_IDLE;
            result = wrpCtx->myTransfers.inTransfer->status;
             if (result == LIBUSB_TRANSFER_COMPLETED){
                //when success - move data into FIFO:
                ring_push(&wrpCtx->rxFifoHeader, wrpCtx->myTransfers.inTransfer->buffer, wrpCtx->myTransfers.inTransfer->actual_length );
                return result;
             } else {
               //return error code, no any push inside the fIFO
                //when the device was disappeared occasionally:
                    if (result == LIBUSB_TRANSFER_NO_DEVICE) {

                         ///release interface 0
                            libusb_release_interface_d (wrpCtx->myUsbDeviceHead.myDevicehandle,0);
                           //close the device
                            libusb_close_d (wrpCtx->myUsbDeviceHead.myDevicehandle);
                            //assign null to a pointer
                            wrpCtx->myUsbDeviceHead.myDevicehandle = NULL;
                            //free transfer
                            libusb_free_transfer_d(wrpCtx->myTransfers.inTransfer);
                            wrpCtx->myTransfers.inTransfer = NULL;
                    }
               return result;
             }
         } else {
             //when transfer is in progress yet
            return wrpCtx->myTransfers.inTransferFlow;
         }
        break;

    }
    return 0xffffffff;
 }

 ///run it periodically to handle events
 //==============================================================================
 void pushLibUsbEvents (wrpUsbCtx* wrpCtx) {

          libusb_handle_events_timeout_completed_d(wrpCtx->myLibUsbContext,&wrpCtx->trTimeouts,NULL);
}



///library initialization, must be STEP 1

int initLibraryX1(wrpUsbCtx* wrpCtx, uint16_t fifoSize, uint16_t  endpointsRamSize, bool debug ) {
  wrpCtx->myUsbDeviceHead.myDevicehandle = NULL; //util will opened any device
  //write  zeros in transfer pointers to avoid running with "garbage pointer":
  wrpCtx->myTransfers.outTransferFlow = USB_TR_IDLE;
  wrpCtx->myTransfers.inTransferFlow = USB_TR_IDLE;
  wrpCtx->myTransfers.inTransfer = NULL;
  wrpCtx->myTransfers.outTransfer = NULL;
  wrpCtx->deInitializationFlow1 = 5;
  //timeouts
  wrpCtx->trTimeouts.tv_sec = 0;
  wrpCtx->trTimeouts.tv_usec = 0;
    //1)Upload  executable code from the .dll inside app
 if (load_libusb() != 0) {
    return -1;
 }
   //2)Allocate memory for the FIFO (IN endpoint stream reconstructing)
  wrpCtx->myTransfers.fifosArray = malloc(fifoSize);
  memset(wrpCtx->myTransfers.fifosArray,0,fifoSize);
  wrpCtx->myTransfers.inEpArray = malloc(endpointsRamSize);
  memset(wrpCtx->myTransfers.fifosArray,0,fifoSize);
  wrpCtx->myTransfers.outEpArray = malloc(endpointsRamSize);
  memset(wrpCtx->myTransfers.fifosArray,0,fifoSize);
  if ( (wrpCtx->myTransfers.fifosArray == NULL) || (wrpCtx->myTransfers.inEpArray == NULL) || (wrpCtx->myTransfers.outEpArray== NULL) ) {
   return -1;
  }
  //3)initializing the libusb context
  if (libusb_init_d(&wrpCtx->myLibUsbContext) != 0) {
    wrpCtx->myLibUsbContext = NULL;
    return -1;
  }
  //4) Init FIFO, to be ready for working with the fifo (only IN endpoint uses FIFO for reconstruct stream):
    ring_init(&wrpCtx->rxFifoHeader, wrpCtx->myTransfers.fifosArray,fifoSize);
   //4)add debug features
     if (debug) {
            wrpCtx->myUsbDeviceHead.isDebug = true;
            //turn debug info , set debug message level
           libusb_set_debug_d(wrpCtx->myLibUsbContext, LIBUSB_LOG_LEVEL_WARNING);
           //attach the callback to the given context
           libusb_set_log_cb_d(wrpCtx->myLibUsbContext, dbgMessageCallback, LIBUSB_LOG_CB_CONTEXT);
     }

  //end) When OK
  return 0;
}
//must be initialized! Must be STEP 2
void assignDeviceParamsForSearchX1 (wrpUsbCtx* wrpCtx, uint16_t pid, uint16_t vid, uint16_t bcd ) {
  wrpCtx->myUsbDeviceHead.pid = pid;
  wrpCtx->myUsbDeviceHead.vid = vid;
  wrpCtx->myUsbDeviceHead.bcd = bcd;
};
///library de-initialization.
int deInitLibraryX1 ( wrpUsbCtx* wrpCtx ) {

    /* EXPLANATION of states
    5-cancel in
    4-waiting for cancel IN completion,
    3-cancel out
    2-waiting cancel OUT completion
    1 - free transfers, release interface, close device, clean memory, close libusb
    0 - done!
    */

    switch(wrpCtx->deInitializationFlow1) {
  case 5:
    //When something is in progress - send request to cancel:
      if (wrpCtx->myTransfers.inTransferFlow == USB_TR_PROGRESS) {
          libusb_cancel_transfer_d(wrpCtx->myTransfers.inTransfer);
          wrpCtx->deInitializationFlow1 = 4;
      } else {
          //when transfer is not in progress - go to OUT cancellation directly
       wrpCtx->deInitializationFlow1 = 3;
      }
      /*
      }*/
    return wrpCtx->deInitializationFlow1;
    break;
  case 4:
    if (wrpCtx->myTransfers.inCbDone) {
          //when cancellation was finished:
        wrpCtx->deInitializationFlow1 = 3;
        wrpCtx->myTransfers.inCbDone = 0;
      }
      return wrpCtx->deInitializationFlow1;
  break;
  case 3:
      //if the output transfer is ongoing - cancel it
      if (wrpCtx->myTransfers.outTransferFlow == USB_TR_PROGRESS) {
            libusb_cancel_transfer_d(wrpCtx->myTransfers.outTransfer);
            wrpCtx->deInitializationFlow1 = 2;
            return wrpCtx->deInitializationFlow1;
      } else {
        //when there are no output transfer in progress - go to state 1
          wrpCtx->deInitializationFlow1 = 1;
          return wrpCtx->deInitializationFlow1;
      }

    break;
  case 2:
       if (wrpCtx->myTransfers.outCbDone) {
          //when cancellation was finished:
        wrpCtx->deInitializationFlow1 = 1;
        wrpCtx->myTransfers.outCbDone = 0;
      }
      return wrpCtx->deInitializationFlow1;

    break;
  case 1:
      //release interface, close device, clean transfers, memory
      if (wrpCtx->myTransfers.inTransfer) {
          libusb_free_transfer_d(wrpCtx->myTransfers.inTransfer);
      }
      if (wrpCtx->myTransfers.outTransfer){
              libusb_free_transfer_d(wrpCtx->myTransfers.outTransfer);
      }


      //release interface, close device
      if (wrpCtx->myUsbDeviceHead.myDevicehandle != NULL) {
          //release interface
          libusb_release_interface_d (wrpCtx->myUsbDeviceHead.myDevicehandle,0);
          //close device
          libusb_close_d (wrpCtx->myUsbDeviceHead.myDevicehandle);
          wrpCtx->myUsbDeviceHead.myDevicehandle = NULL;
      }
       //1)free memory, if exist
     if (wrpCtx->myTransfers.fifosArray != NULL) {
        free(wrpCtx->myTransfers.fifosArray);
     }

     if (wrpCtx->myTransfers.inEpArray != NULL) {
        free(wrpCtx->myTransfers.inEpArray);
     }

     if (wrpCtx->myTransfers.outEpArray != NULL) {
        free(wrpCtx->myTransfers.outEpArray);
     }
      //close context of libusb
      if (wrpCtx->myLibUsbContext != NULL) {
        libusb_exit_d(wrpCtx->myLibUsbContext);
      }
       //2)release RAM from executable code of DLL, uploaded lated
      unload_libusb();
     wrpCtx->deInitializationFlow1 = 5;
      return 0;
    break;
    default:

    }
return 0xffffffff;
}
//This function requires a list of connected devices from a system,
// when a device was disconnected and appeared again - connect, get descriptor, clam and connect it again
// when a device was connected and disappeared again - close the device, claims the interface
   int findUsbDeviceX1 (wrpUsbCtx* wrpCtx) {
       libusb_device* myDevice = NULL;
       libusb_device**  listOfConnected;
       ssize_t     howManyWasFound;
       struct libusb_device_descriptor  myDevDescriptor;

       //1) get the list of connected devices
       howManyWasFound = libusb_get_device_list_d(wrpCtx->myLibUsbContext, &listOfConnected);

       if (howManyWasFound == 0) {
            //no connected devices was found
            libusb_free_device_list_d(listOfConnected,1);
            //clear handle
            wrpCtx->myUsbDeviceHead.myDevicehandle = NULL;
             return 0;
       }
       //2)Iterate devices
       for (int devI=0; devI<howManyWasFound; devI++) {
             //a)get descriptor
             libusb_get_device_descriptor_d( listOfConnected[devI],&myDevDescriptor);
             //b)Compare PID, VID
             if (( myDevDescriptor.bcdDevice == wrpCtx->myUsbDeviceHead.bcd) && (myDevDescriptor.idProduct == wrpCtx->myUsbDeviceHead.pid) && ( myDevDescriptor.idVendor == wrpCtx->myUsbDeviceHead.vid)){
                //when matched - assign a device
                myDevice = listOfConnected[devI];
                break;
             }
       }
       //if the device with exactly PID, VID was found:
       if (myDevice != NULL) {
            //3)Connection with libusb_open
             if (libusb_open_d(myDevice, &wrpCtx->myUsbDeviceHead.myDevicehandle) != 0){
                    //when open was fail
                libusb_free_device_list_d(listOfConnected,1);
                //clear handle
               wrpCtx->myUsbDeviceHead.myDevicehandle = NULL;
                return -1;
             }
            //4)Claim the interface with number 0
             if (libusb_claim_interface_d(wrpCtx->myUsbDeviceHead.myDevicehandle, 0) !=0 ){
                //close device
                libusb_close_d (wrpCtx->myUsbDeviceHead.myDevicehandle);
                libusb_free_device_list_d(listOfConnected,1);
               return -1;
             }
              //5)Clean the list
            libusb_free_device_list_d(listOfConnected,1);
            return 0;

       } else {
          //clear handle, because device ws not found
            wrpCtx->myUsbDeviceHead.myDevicehandle = NULL;
            //5)Clean the  list
            libusb_free_device_list_d(listOfConnected,1);
            return 1;
       }


   }
  ///iterate a list of connected devices, find interested device.
  // This function must be called in the "infinite USB loop" to auto connect a device, before Tx, Rx functions.
  /*1)When disconnected: case a: handle =  NULL -> do nothing;
                         case b: handle != NULL -> release interface, disconnect, assign NULL to the handle
                         --------------------------------------------------
    2)When connected:    case a: handle = NULL  -> connect, claim interface
                         case b: handle != NULL ->  do nothing
    */
  int attachUsbDevice (wrpUsbCtx* wrpCtx,uint8_t inEndpNumber) {
      //when any endpoint is doing transfer (in progress) - don`t run this function to avoid races
      if (wrpCtx->myTransfers.inTransferFlow == USB_TR_PROGRESS || wrpCtx->myTransfers.outTransferFlow == USB_TR_PROGRESS) {
        return 0xff; //busy
      }
        libusb_device* myDevice = NULL;  //interested device
       libusb_device**  listOfConnected;
       ssize_t     howManyWasFound;  //length of the list
       struct libusb_device_descriptor  myDevDescriptor;  //device descriptor

       //1) get the list of connected devices
       howManyWasFound = libusb_get_device_list_d(wrpCtx->myLibUsbContext, &listOfConnected);

       //when there was any error when the list was required:
       if (howManyWasFound < 0) {
            libusb_free_device_list_d(listOfConnected,1);
        return -1;
       }
        ///when was found any USB devcie on the bus of the host:
       if (howManyWasFound > 0) {
        //when something device(s) was found - iterate the list

               for (int devI=0; devI < howManyWasFound; devI++) {
                 //a)get the descriptor
                 libusb_get_device_descriptor_d( listOfConnected[devI],&myDevDescriptor);
                 //b)Compare PID, VID
                     if ((myDevDescriptor.bcdDevice == wrpCtx->myUsbDeviceHead.bcd) && (myDevDescriptor.idProduct == wrpCtx->myUsbDeviceHead.pid) && (myDevDescriptor.idVendor == wrpCtx->myUsbDeviceHead.vid)){
                        //when PID, VID, BCD was matched - assign the device to the pointer
                        myDevice = listOfConnected[devI];
                        break;
                     }
              }
       }
       /*now we know - is device on a physical host`s  bus or not  */
       /*<<<< So, the first case - the DEVICE IS IN SYSTEM NOW (present now) >>>>*/
       if (myDevice != NULL) {
            //a) Was the device connected later?
            if (wrpCtx->myUsbDeviceHead.myDevicehandle == NULL)  {
                 //1)when was disconnected - re-connect again

                 if (libusb_open_d(myDevice, &wrpCtx->myUsbDeviceHead.myDevicehandle) != 0){
                        //when open was fail clean the list
                    libusb_free_device_list_d(listOfConnected,1);
                    //clear handle
                   wrpCtx->myUsbDeviceHead.myDevicehandle = NULL;
                    return -1;
                 }


                 //2)Claim the interfce with number 0:
                 if (libusb_claim_interface_d(wrpCtx->myUsbDeviceHead.myDevicehandle,0) !=0 ){
                       //when claim was fail -  close the device
                    libusb_close_d (wrpCtx->myUsbDeviceHead.myDevicehandle);
                       //free the list
                    libusb_free_device_list_d(listOfConnected,1);
                        //clear handle
                   wrpCtx->myUsbDeviceHead.myDevicehandle = NULL;
                   return -1;
                 }
                 //allocate a new transfer
                   if (wrpCtx->myTransfers.inTransfer == NULL){
                     wrpCtx->myTransfers.inTransfer = libusb_alloc_transfer_d(0);
                   }


                       libusb_fill_bulk_transfer(wrpCtx->myTransfers.inTransfer,
                               wrpCtx->myUsbDeviceHead.myDevicehandle,
                               inEndpNumber,
                                wrpCtx->myTransfers.inEpArray,
                                IN_ENDP_TRANSFER_SIZE,  //64 bytes - IN packet size
                                inUserCallback,
                                &wrpCtx->myTransfers.inCbDone, //the flag "a callback was done recently"
                                0); //infinity, the host waiting until new transfer

            }
            ///when a device was already connect later - do nothing, only clean the list
           libusb_free_device_list_d(listOfConnected,1);
           return 1;

       } else {

        /*<<<<< So, the second case - the DEVICE IS NOT IN SYSTEM NOW (absent) >>>>>*/
        //a) Was the device connected later?
            if (wrpCtx->myUsbDeviceHead.myDevicehandle != NULL)  {
                 //free IN object, assign null, to avoid using in Rx operations:
                 if (wrpCtx->myTransfers.inTransfer != NULL) {
                    libusb_free_transfer_d(wrpCtx->myTransfers.inTransfer);
                 }

                wrpCtx->myTransfers.inTransfer = NULL;
                ///release interface 0
                libusb_release_interface_d (wrpCtx->myUsbDeviceHead.myDevicehandle,0);
               //close the device
                libusb_close_d (wrpCtx->myUsbDeviceHead.myDevicehandle);
                //assign null to a pointer
                wrpCtx->myUsbDeviceHead.myDevicehandle = NULL;

            }
            ///when device was disconnected in past - do nothing
            //clean the list
             libusb_free_device_list_d(listOfConnected,1);
             return 0;
       }

  }

/*  A function for the raw "data blocks" transfer */
  uint32_t hasChunkReceived(wrpUsbCtx* wrpCtx, uint8_t* dest, uint16_t length) {
    int aval = ring_available(&wrpCtx->rxFifoHeader);
     if(aval >= length) {
        //a chunk was received
         ring_pop(&wrpCtx->rxFifoHeader, dest, length);
         return 0;
     }
     //a chunk not accumulated yet
     return 1;
  }
 /*A function for "protocol transfer" [command | flags | length | data(optional)]*/
  uint32_t hasPacketReassembled (wrpUsbCtx* wrpCtx, packet_params* parameters) {
      //when available data  > 4, parse data
      int aval, result;
      char subBuffer[4096];
      result = PACK_IDLE;
      aval = ring_available(&wrpCtx->rxFifoHeader);

      if (aval >= 4) {
        ring_peek(&wrpCtx->rxFifoHeader,subBuffer,aval);
        result = packetParser(subBuffer, parameters, aval);
      }
      //when a packet was assembled, drain FIFO - and returns DONE
      if (result == PACK_DONE) {
        //drain
        ring_drain(&wrpCtx->rxFifoHeader,parameters->packet_length);
        //
      }

      return result;
  }



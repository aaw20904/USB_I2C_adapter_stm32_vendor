#ifndef LIBUSB_ASYNC_WR_V1_H_INCLUDED
#define LIBUSB_ASYNC_WR_V1_H_INCLUDED
#include <stdbool.h>
#include "libusb.h"
//state of device
enum devPhyState{
DEV_USB_DISCONNECTED,
DEV_USB_CONNECTED,
};
//states of USB transfer, for non-blocking functions, for internal static variables of statesfull functions
enum usbTransferState{
USB_TR_IDLE,
USB_TR_PROGRESS,
USB_TR_ERROR
USB_TR_DONE
};

//a structure for device state (plug/unplug)
typedef struct {
  enum devPhyState deviceState;
  struct libusb_device_handle * myDevicehandle; //NULL when disconnected
  uint16_t pid;
  uint16_t vid;
  uint16_t bcd;
 bool isDebug;

}usbDeviceState;

typedef struct {
    uint8_t* fifosArray;
    uint8_t* inEpArray;
    uint8_t* outEpArray;
}usrEpBuffers;

typedef struct {
  libusb_transfer* inTansfer;
  enum libusb_transfer_status inTransferStatus;
  libusb_transfer* outTransfer;
  enum libusb_transfer_status outTransferStatus;
  uint8_t* fifosArray;
  uint8_t* inEpArray;
  uint8_t* outEpArray;
}usbDevTransfers;


int initLibraryX1( uint16_t fifoSize, uint16_t  endpointsRamSize, bool bebug);
int deInitLibraryX1 ( void );
void assignDeviceParamsForSearchX1(uint16_t pid, uint16_t vid, uint16_t bcd );
int findUsbDeviceX1 (void);
int attachUsbDevice(void);
int makeOutTansfer(uint8_t *parcel, uint16_t dataSize, uint8_t endPoint)


#endif // LIBUSB_ASYNC_WR_V1_H_INCLUDED

#ifndef LIBUSB_ASYNC_WR_V1_H_INCLUDED
#define LIBUSB_ASYNC_WR_V1_H_INCLUDED
#include <stdbool.h>
#include "libusb.h"
#include "ring_fifo.h"
#include "packetize.h"
///Author: Andrii Androsovych


//state of device
enum devPhyState{
    DEV_USB_DISCONNECTED,
    DEV_USB_CONNECTED,
};


//states of USB transfer, for non-blocking functions, for internal static variables of statesfull functions
enum usbTransferState{ USB_TR_IDLE,
 USB_TR_PROGRESS = 0xFFFF, //to avoid of conflict with libusb constants
 };

//a structure for device state (plug/unplug)
typedef struct {
      enum devPhyState deviceState;
      struct libusb_device_handle * myDevicehandle; //NULL when disconnected
      int endPointSize;
      uint16_t pid;
      uint16_t vid;
      uint16_t bcd;
      bool isDebug;
}usbDeviceState;

typedef struct {
    uint8_t* fifosArray;
    uint8_t* inEpArray;
    uint8_t* outEpArray;
}usrEpBuffers;

typedef struct {   int outCbDone; //markers - "the callback was called""
               int inCbDone; //markers - "the callback was called""
               int inTransferFlow; //internal function state
             struct libusb_transfer* inTransfer;
               int outTransferFlow; //internal function state
             struct libusb_transfer* outTransfer;
              uint8_t* fifosArray;
              uint8_t* inEpArray;
              uint8_t* outEpArray;
  }usbDevTransfers;
/////a new structure for the context//////////////
typedef struct {
    ring_t rxFifoHeader;
    usbDevTransfers myTransfers;
    usbDeviceState myUsbDeviceHead;
    libusb_context *myLibUsbContext;
    int deInitializationFlow1;
    struct timeval trTimeouts;
} wrpUsbCtx;



int initLibraryX1(wrpUsbCtx* wrpCtx, uint16_t fifoSize, uint16_t  endpointsRamSize, bool debug );
int deInitLibraryX1 ( wrpUsbCtx* wrpCtx );
void assignDeviceParamsForSearchX1 (wrpUsbCtx* wrpCtx, uint16_t pid, uint16_t vid, uint16_t bcd );
 int findUsbDeviceX1 (wrpUsbCtx* wrpCtx); //not used
  int attachUsbDevice (wrpUsbCtx* wrpCtx,uint8_t inEndpNumber);
int makeOutTransfer(wrpUsbCtx* wrpCtx, uint8_t *parcel, uint16_t dataSize, uint8_t endPoint);
 void pushLibUsbEvents (wrpUsbCtx* wrpCtx);
 int makeInTransfer(wrpUsbCtx* wrpCtx);
int freeInTransfer (wrpUsbCtx* wrpCtx);
  uint32_t hasPacketReassembled (wrpUsbCtx* wrpCtx, packet_params* parameters);
  uint32_t hasChunkReceived(wrpUsbCtx* wrpCtx, uint8_t* dest, uint16_t length);



#endif // LIBUSB_ASYNC_WR_V1_H_INCLUDED

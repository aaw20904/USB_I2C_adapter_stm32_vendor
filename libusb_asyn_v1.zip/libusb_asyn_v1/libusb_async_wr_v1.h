#ifndef LIBUSB_ASYNC_WR_V1_H_INCLUDED
#define LIBUSB_ASYNC_WR_V1_H_INCLUDED
#include <stdbool.h>
#include "libusb.h"
#include "ring_fifo.h"
#include "packetize.h"
///Author: Andrii Androsovych


//state of device
enum devPhyState{
    DEV_USB_DISCONNECTED,
    DEV_USB_CONNECTED,
};


//states of USB transfer, for non-blocking functions, for internal static variables of statesfull functions
enum usbTransferState{ USB_TR_IDLE,
 USB_TR_PROGRESS = 0xFFFF, //to avoid of conflict with libusb constants
 };

//a structure for device state (plug/unplug)
typedef struct {
      enum devPhyState deviceState;
      struct libusb_device_handle * myDevicehandle; //NULL when disconnected
      int endPointSize;
      uint16_t pid;
      uint16_t vid;
      uint16_t bcd;
      bool isDebug;
}usbDeviceState;

typedef struct {
    uint8_t* fifosArray;
    uint8_t* inEpArray;
    uint8_t* outEpArray;
}usrEpBuffers;

typedef struct { volatile int outCbDone; //markers - "the callback was called""
     volatile int inCbDone; //markers - "the callback was called""
     volatile int inTransferFlow; //internal function state
     struct libusb_transfer* inTransfer;
     volatile int outTransferFlow; //internal function state
     struct libusb_transfer* outTransfer;
      uint8_t* fifosArray;
      uint8_t* inEpArray;
      uint8_t* outEpArray;
  }usbDevTransfers;
/////a new structure for the context//////////////
typedef struct {
    ring_t rxFifoHeader;
    usbDevTransfers myTransfers;
    usbDeviceState myUsbDeviceHead;
    libusb_context *myLibUsbContext;
    int deInitializationFlow1;
    struct timeval trTimeouts;
}wrpUsbContext;



int initLibraryX1( uint16_t fifoSize, uint16_t  endpointsRamSize, bool bebug);
int deInitLibraryX1 ( void );
void assignDeviceParamsForSearchX1(uint16_t pid, uint16_t vid, uint16_t bcd );
int findUsbDeviceX1 (void);
int attachUsbDevice(uint8_t inEndpNumber);
int makeOutTransfer(uint8_t *parcel, uint16_t dataSize, uint8_t endPoint);
void pushLibUsbEvents (void);
int makeInTransfer (void);
int freeInTransfer (void);
 uint32_t hasPacketReassembled (packet_params* parameters);

uint32_t newFifoDataAvalCount(void);
uint32_t consumeDataFromFifo(uint8_t* dest, int amount);

#endif // LIBUSB_ASYNC_WR_V1_H_INCLUDED

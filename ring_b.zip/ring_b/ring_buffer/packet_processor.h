#ifndef PACKET_PROCESSOR_H_INCLUDED
#define PACKET_PROCESSOR_H_INCLUDED
#include "stdint.h"

typedef struct {
short head;
short tail;
unsigned char* data;
short bufferLength;
}ringBuffer;

typedef struct {
 uint8_t* data;
 uint8_t* head;
 uint8_t* tail;
 uint8_t* bitmask;
 unsigned short bufferLength;
}ringBufferB;

 void ringBufferInit(short length, unsigned char* buf);
 int ringBufferPut(unsigned char *newData, unsigned short newDataLength);
 void ringBufferClear(void);


#endif // PACKET_PROCESSOR_H_INCLUDED

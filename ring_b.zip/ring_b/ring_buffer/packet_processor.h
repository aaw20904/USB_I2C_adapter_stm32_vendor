#ifndef PACKET_PROCESSOR_H_INCLUDED
#define PACKET_PROCESSOR_H_INCLUDED
#include "stdint.h"

#define RING_OK      0
#define RING_EMPTY  -1
#define RING_FULL   -2

typedef struct {
 uint8_t* data;//buffer address
 uint32_t head;//cell num
 uint32_t tail;//cell num
 uint32_t bitmask;//cell bitmask
 uint32_t bufferLength;//length of the buffer
}ringBufferHandle;

void initRingB(ringBufferHandle* rH,uint8_t* lake, uint32_t len /*must be power of 2*/);
int pushInRingB(ringBufferHandle* rH, uint8_t data);
int popFromRingB(ringBufferHandle* rH, uint8_t* dataplace);
int isFreeSpaceInRingB (ringBufferHandle* rH);
int isNewDataInRingB (ringBufferHandle* rH);

#endif // PACKET_PROCESSOR_H_INCLUDED

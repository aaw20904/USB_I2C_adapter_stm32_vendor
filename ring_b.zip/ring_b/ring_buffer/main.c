#include <stdio.h>
#include <stdlib.h>
 #include "packet_processor.h"

 unsigned char x[36];



int main()
{
    ringBufferClear();
    ringBufferInit(31, x);
    ringBufferPut("{11111}",7);
    ringBufferPut("{222222222222222222222222222}",29);
    ringBufferPut("{333333333333}",14);
    ringBufferPut("{is_the_president}",18);
    ringBufferPut("{of_the_USA}",12);
    printf("Hello world!\n");
    return 0;
}

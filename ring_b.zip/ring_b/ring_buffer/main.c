#include <stdio.h>
#include <stdlib.h>
 #include "packet_processor.h"

 unsigned char x[10];
ringBufferHandle rHandle;
uint8_t tmp[8];

int main()
{
initRingB(&rHandle,x,8);
pushInRingB(&rHandle,'A');
popFromRingB(&rHandle,tmp);
printf("%c \n",tmp[0]);
popFromRingB(&rHandle,tmp);
printf("%c \n",tmp[0]);
pushInRingB(&rHandle,'B');
pushInRingB(&rHandle,'C');
pushInRingB(&rHandle,'D');
pushInRingB(&rHandle,'E');
pushInRingB(&rHandle,'F');
popFromRingB(&rHandle,tmp);
printf("%c \n",tmp[0]);
popFromRingB(&rHandle,tmp);
printf("%c \n",tmp[0]);
pushInRingB(&rHandle,'G');
popFromRingB(&rHandle,tmp);
printf("%c \n",tmp[0]);
popFromRingB(&rHandle,tmp);
printf("%c \n",tmp[0]);
pushInRingB(&rHandle,'H');
pushInRingB(&rHandle,'I');
popFromRingB(&rHandle,tmp);
printf("%c \n",tmp[0]);
popFromRingB(&rHandle,tmp);
printf("%c \n",tmp[0]);
pushInRingB(&rHandle,'J');
pushInRingB(&rHandle,'K');
popFromRingB(&rHandle,tmp);
printf("%c \n",tmp[0]);
popFromRingB(&rHandle,tmp);
printf("%c \n",tmp[0]);
pushInRingB(&rHandle,'L');
pushInRingB(&rHandle,'M');
popFromRingB(&rHandle,tmp);
printf("%c \n",tmp[0]);

    printf("Hello world!\n");
    return 0;
}

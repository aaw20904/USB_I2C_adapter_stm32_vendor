

#include <stdlib.h>
#include <string.h>
#include "stdint.h"
 #include "packet_processor.h"


//init a structure
ringBuffer myRingBufferStr;
ringBufferB myRingHeaderB;

void initRingBufferB(uint8_t* lake /*must be aligned!*/, uint16_t length/*must be power of 2*/) {
 myRingHeaderB.data = myRingHeaderB.head = myRingHeaderB.tail = lake;
 myRingHeaderB.bufferLength = length;
 myRingHeaderB.bitmask =(uint8_t*) length-1; //for example for 32 bits = 31 = 0b....011111
}

int pushByteRingBuffer(uint8_t data) {
    uint32_t a, b;

  uint8_t* ptr  = myRingHeaderB.tail + 1;
  a = (uint32_t)ptr;
  b = (uint32_t)myRingHeaderB.bitmask;
  b &= a;
  ptr &= (void*)myRingHeaderB.bitmask;
  //has the buffer free space?
  if ((ptr &  myRingHeaderB.bitmask) == myRingHeaderB.head) {
        //when not
    return -1;
  }
  ptr  = myRingHeaderB.head;
  //assign data
  *myRingHeaderB.head = data;
  //wrap pointer around
  ptr++;
  ptr &=  myRingHeaderB.bitmask;
  //assign new value to the pointer
  myRingHeaderB.head = (uint8_t*)ptr;
  return 0;
}


int popByteRingBuffer(uint8_t * dataStore) {
    uint8_t* ptr;
 //are there any new data to consume?
 if (myRingHeaderB.head == myRingHeaderB.tail) {
        //no any new data to consume
    return -1;
 }
 //consume data
 *dataStore = *myRingHeaderB.tail;
 //wrap around
 ptr = myRingHeaderB.tail + 1;
 ptr &= myRingHeaderB.bitmask;

}

int isAvaliableNewInRingBuffer(void) {
  //are there any new data to consume?
 if (myRingHeaderB.head == myRingHeaderB.tail) {
        //no any new data to consume
    return -1;
 } else {
   return 1;
 }
}







void ringBufferClear(void) {
    //clear to zero cell
  myRingBufferStr.head = 0;
  myRingBufferStr.tail = 0;
}

void ringBufferInit(short length, unsigned char* buf) {
  myRingBufferStr.data = buf;
  myRingBufferStr.bufferLength = length;
  myRingBufferStr.head = 0;
  myRingBufferStr.tail = 0;
}

short ringBufferNewDataAvailable(void) {
    short remainder = myRingBufferStr.head - myRingBufferStr.tail;
  if (remainder > 0 ){
    return remainder;
  } else {
   return (myRingBufferStr.tail - (myRingBufferStr.bufferLength-1)) + abs(remainder);
  }
}

short ringBufferConsumeLast(unsigned char* uStore) {

    short remainder = myRingBufferStr.head - myRingBufferStr.tail;

      if (remainder ==0 ) {
        return 0; //no new data available
      } else  if (remainder > 0 ){
            memcpy(uStore, myRingBufferStr.data + myRingBufferStr.head, remainder);
            myRingBufferStr.tail=myRingBufferStr.head;
    return remainder;
  } else {
      remainder = myRingBufferStr.tail - myRingBufferStr.bufferLength;
      memcpy (uStore, myRingBufferStr.data + myRingBufferStr.tail, remainder );
      memcpy (uStore+remainder,myRingBufferStr.data,myRingBufferStr.head);
   return (myRingBufferStr.tail - (myRingBufferStr.bufferLength-1)) + abs(remainder);
  }
}

int ringBufferPut(unsigned char *newData, unsigned short newDataLength) {
  short remainder, firstPart, secondPart;
  remainder = (   (myRingBufferStr.bufferLength-1) - myRingBufferStr.head) - newDataLength;
  //when data fit until the buffer end
  if (remainder >= 0) {
    //only copying data
    memcpy (myRingBufferStr.data+myRingBufferStr.head, newData, newDataLength);
    //update tail; and head
   // myRingBufferStr.tail = myRingBufferStr.head;
    myRingBufferStr.head += newDataLength;
    return remainder;
  }
  //when there must be wrap around
  if (remainder < 0) {
   //a)copy the first part - until the end of array
     firstPart = newDataLength -  abs(remainder);
     memcpy(myRingBufferStr.data + myRingBufferStr.head, newData, firstPart+1);
   //b)copy the second part
     memcpy(myRingBufferStr.data, newData+firstPart, abs(remainder));
    //c)update indexes of an array
     //myRingBufferStr.tail = myRingBufferStr.head;
     myRingBufferStr.head = abs(remainder);
     return remainder;
  }
}

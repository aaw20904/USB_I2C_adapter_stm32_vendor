

#include <stdlib.h>
#include <string.h>
#include "stdint.h"
 #include "packet_processor.h"

ringBufferHandle ringHandle;
//structure initialization
void initRingB(ringBufferHandle* rH,uint8_t* lake, uint32_t len /*must be power of 2*/) {
   rH->data = lake;
   rH->head = 0;
   rH->bitmask = len-1;
   rH->tail = 0;
   rH->bufferLength = len;
}
//insert one byte
int pushInRingB(ringBufferHandle* rH, uint8_t data) {
  //is free space available? One gap cell used as a border for safety
  if (((rH->head + 1) & rH->bitmask) == rH->tail ) {
    return RING_FULL; //no space
  }
  //assign new data
  rH->data[rH->head] = data;
  //increase head (array index)
  rH->head++;
  //wrap it around (array index)
  rH->head &= rH->bitmask;
  return RING_OK; //data was written
}

int popFromRingB(ringBufferHandle* rH, uint8_t* dataplace) {
   uint8_t x;
  //are there new data available?
  if (rH->head == rH->tail) {
    return RING_EMPTY;
  }
  //remember tail data
  x= rH->data[rH->tail];
  //add and wrap around the tail
  rH->tail++;
  rH->tail &= rH->bitmask;
  //return consumed data
  *dataplace = x;
  return RING_OK;
}

int isNewDataInRingB (ringBufferHandle* rH) {
   //are there new data available?
  if (rH->head == rH->tail) {
    return RING_EMPTY;
  }
  return RING_OK;
}

int isFreeSpaceInRingB (ringBufferHandle* rH) {
   //is free space available? One gap cell used as a border for safety
  if (((rH->head + 1) & rH->bitmask) == rH->tail ) {
    return RING_FULL; //no space
  }
  return RING_OK;
}

int pushBlockInRingB(ringBufferHandle* rH, uint8_t* src, uint32_t len) {
     //are there enough space available for the block?
   uint32_t var1, var2, var3;
   if (len > rH->bufferLength-1) {
     //when the chunk is too big:
    return RING_FULL;
   }

}

int getFreeSpRingB (ringBufferHandle* rH) {
  //maximum free space when the buffer is  empty is the array length - 1
  int firstPart, secondPart, aval;
  int remainder = rH->head - rH->tail;
  if (remainder > 0) {

      aval = rH->head % rH->bufferLength
  }
}

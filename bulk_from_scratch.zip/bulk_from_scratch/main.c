#include <stdio.h>
#include <stdlib.h>
#include "libusb.h"
#include "libusb_load.h"
#include "usb_wrap.h"

int main()
{
    initLibraryW(64);
    deInitLibraryW();
    printf("Hello world!\n");
    return 0;
}

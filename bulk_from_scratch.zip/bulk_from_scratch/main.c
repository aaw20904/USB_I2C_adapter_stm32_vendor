#include <stdio.h>
#include <stdlib.h>
#include "libusb.h"
#include "libusb_load.h"


int main()
{
    printf("Hello world!\n");
    return 0;
}

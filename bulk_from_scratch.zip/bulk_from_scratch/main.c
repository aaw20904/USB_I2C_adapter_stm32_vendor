#include <stdio.h>
#include <stdlib.h>
#include "libusb.h"
#include "libusb_load.h"
#include "usb_wrap.h"

extern libusb_context* myLibusbCtx;
uint8_t errors;
volatile transferUsbStatus outStH;
 char str[]="Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, �and what is the use of a book,� thought Alice 'without pictures or conversations?";
int state =1;
int result;
int main()
{
    outStH.statesMachine = USB_TH_IDLE;
outStH.bulkTransferDone = 0;
outStH.flagsOfTransfer = 0;
outStH.sentBytes = 0;
    initLibraryW(64);
    openDevice(0xCafe, 0x4000);

    while(state ==1) {


        result = writeDataToUsb(str,96,&errors,&outStH);
        if (result == USB_TH_DONE || result == USB_TH_ERR) {
            state=0;
            break;
        }
         libusb_handle_events_d(myLibusbCtx);

        Sleep(1);

    }

    state = 1;
        while(state ==1) {


        result = writeDataToUsb(str+96,96,&errors,&outStH);
        if (result == USB_TH_DONE || result == USB_TH_ERR) {
            state=0;
            break;
        }
        libusb_handle_events_d(myLibusbCtx);


        Sleep(1);

    }
    //all the active transfers had been finished now
    deInitLibraryW();
    printf("Hello world!\n");
    return 0;
}

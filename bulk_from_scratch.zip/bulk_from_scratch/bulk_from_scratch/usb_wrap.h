#ifndef USB_WRAP_H_INCLUDED
#define USB_WRAP_H_INCLUDED

int initLibraryW(void);
int deInitLibraryW(void);
int attachDeviceW (uint16_t vid, uint16_t pid, int outBufferLength);

enum libInit {
 UNABLE_OPEN_LIB = -1;
 UNABLE_INIT_LIB = -2;
 UNABLE_ALLOC_MEM_LIB = -3;
};

enum libDevOpen {
 DEV_NOT_FOUND = -1;
 UNABLE_CLAIM_I = -2;
 UNABLE_DEATACH_K = -3;
};

#endif // USB_WRAP_H_INCLUDED

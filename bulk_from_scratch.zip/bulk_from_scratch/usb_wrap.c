///The library-wrapper arund the LibUSB
#include <stdio.h>
#include <stdlib.h>
#include "libusb.h"
#include "usb_wrap.h"
#include <string.h>
#include <windows.h>
#include "libusb_load.h"


#define EP_OUT 0x01   // endpoint 1 OUT
#define EP_IN  0x81   // endpoint 1 IN

#define USB_VID   0xCafe
#define USB_PID   0x4000
#define USB_BCD   0x0100

uint8_t* fifo_in_buffer;

uint32_t fifo_buffer_length;

//libusb runtime instance. Global library state
libusb_context* myLibusbCtx;

//a handle of a device, that libUSB will open
libusb_device_handle* myDevHandle;
//------------------------------------
struct libusb_transfer * transferDescritor;

uint8_t dataTransferBuffer[65535];


//***********the callback************

void cb_xfer (struct libusb_transfer *tr) {
  tr->actual_length;
  tr->buffer;
  tr->user_data;
}


int initializeLibrary(uint32_t fifoSize) {

 if (load_libusb() != 0) {
        printf ("Unable to open library!");
        return UNABLE_OPEN_LIB;
 }

  ///init Libusb`s state structure:
  if (libusb_init(&myLibusbCtx) != 0 ) {
    return UNABLE_INIT_LIB;
  }

  /////
  fifo_in_buffer = malloc(fifoSize);
  if (fifo_in_buffer == NULL) {
    return UNABLE_ALLOC_MEM_LIB;
  }

  fifo_buffer_length = fifoSize;
  return 0;
  //////----------


}

 int openDevice(uint16_t VID, uint16_t PID) {
     //try to open device firstly
     myDevHandle = libusb_open_device_with_vid_pid(myLibusbCtx, USB_VID, USB_PID);

      if (myDevHandle == NULL) {
            printf("Unable to open device! \n");
        return DEV_NOT_FOUND;
      }
      //claim interface
   if ( libusb_claim_interface(myDevHandle, 0) !=0 ){
     printf ("Unable to claim interface! \n");
     return UNABLE_CLAIM_I;
   }

  if ( libusb_detach_kernel_driver (myDevHandle, 0) !=0 ){
    printf ("Unable to detch driver \n");
    return UNABLE_DEATACH_K;
  }

 }



  int writeDataToUsb( uint8_t* dPtr, int data_length) {
      //Allocate transfer
     transferDescritor = libusb_alloc_transfer(0);
     //Then fill transfer:
     libusb_fill_bulk_transfer(transferDescritor, //Your allocated transfer descriptor.
                                myDevHandle,  //opened device`s handle
                                1, //endpoint 0x01   OUT, 0x81   IN
                                dataTransferBuffer,
                                data_length,

                                );
  }







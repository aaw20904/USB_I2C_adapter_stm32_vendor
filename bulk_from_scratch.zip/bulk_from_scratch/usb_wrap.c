///The library-wrapper arund the LibUSB
#include <stdio.h>
#include <stdlib.h>
#include "libusb.h"
#include "usb_wrap.h"
#include <string.h>
#include <windows.h>
#include "libusb_load.h"


#define EP_OUT 0x01   // endpoint 1 OUT
#define EP_IN  0x81   // endpoint 1 IN

#define USB_VID   0xCafe
#define USB_PID   0x4000
#define USB_BCD   0x0100

uint8_t* fifo_in_buffer;

uint32_t fifo_buffer_length;

//libusb runtime instance. Global library state
libusb_context* myLibusbCtx;

//a handle of a device, that libUSB will open
libusb_device_handle* myDevHandle;
//------------------------------------
struct libusb_transfer * transferDescritor;

uint8_t dataTransferBuffer[65535];

int32_t cbStatus;

volatile transferOutStatus outStH;




//***********the callback************

void  out_callback ( struct libusb_transfer *tr) {
    //acces to the static structure
   // transferOutStatus * transfStat = tr->user_data;
       outStH.flagsOfTransfer = tr->status;
       outStH.bulkTransferDone = 1;
         outStH.sentBytes += tr->actual_length;


}


void  in_callback (struct libusb_transfer *tr) {
  tr->actual_length;
  tr->buffer;
  tr->user_data;
}


int initLibraryW(uint32_t fifoSize) {

 if (load_libusb() != 0) {
        printf ("Unable to open library!");
        return UNABLE_OPEN_LIB;
 }

  ///init Libusb`s state structure:
  if (libusb_init_d(&myLibusbCtx) != 0 ) {
    return UNABLE_INIT_LIB;
  }

  /////
  fifo_in_buffer = malloc(fifoSize);
  if (fifo_in_buffer == NULL) {
    return UNABLE_ALLOC_MEM_LIB;
  }

  fifo_buffer_length = fifoSize;
  return 0;
  //////----------


}




void deInitLibraryW(void) {
    if (myDevHandle) {
        libusb_close_d(myDevHandle); ///close device
    }

    libusb_exit_d(myLibusbCtx);  ///exit libusb
    unload_libusb();
    if (fifo_in_buffer){
        free(fifo_in_buffer);
    }

}

 int openDevice(uint16_t VID, uint16_t PID) {
     //try to open device firstly
     myDevHandle = libusb_open_device_with_vid_pid_d(myLibusbCtx,  VID,  PID);

      if (myDevHandle == NULL) {
            printf("Unable to open device! \n");
        return DEV_NOT_FOUND;
      }
      //claim interface
   if ( libusb_claim_interface_d(myDevHandle, 0) !=0 ){
     printf ("Unable to claim interface! \n");
     return UNABLE_CLAIM_I;
   }

 /* if ( libusb_detach_kernel_driver_d (myDevHandle, 0) !=0 ){
    printf ("Unable to detch driver \n");
    return UNABLE_DEATACH_K;
  }*/
  return 0; //OK

 }



  int writeDataToUsb( uint8_t* dPtr, int data_length, uint8_t* errors ) {
   int var1;
     switch (outStH.statesMachine) {
      case USB_OUT_IDLE:
          outStH.sentBytes = 0;
          //1)fill the libusb structure and plan the transfers of data:
          //Allocate transfer
         transferDescritor = libusb_alloc_transfer_d(0);
         //Then fill transfer:
         libusb_fill_bulk_transfer(transferDescritor, //Your allocated transfer descriptor.
                                    myDevHandle,  //opened device`s handle
                                    0x01, //endpoint 0x01   OUT, 0x81   IN
                                    dPtr,  //pointer to data to be send
                                    data_length, //length of data to be send
                                    out_callback, //the callback
                                    &outStH,  //void* user data
                                     5000 //timeout
                                    );
        //This function will fire off the USB transfer and then return immediately.
        var1 = libusb_submit_transfer_d(transferDescritor);
        if (var1 != 0) {
            //when any error occured - report about error
            *errors = (int)var1;
             outStH.statesMachine = USB_OUT_IDLE;
            return -1;
        }
        outStH.statesMachine = USB_OUT_PROGRESS; //the structre with taskws sent to the library.It will execute by the kernel in near future
        return  USB_OUT_PROGRESS;
        break;
      case USB_OUT_PROGRESS:
          if (outStH.bulkTransferDone){
                    outStH.bulkTransferDone = 0;
                  //reporting about errors-save in the variable
                   *errors = (uint8_t) outStH.flagsOfTransfer;
                   //are there any error?
                    /*LIBUSB_TRANSFER_COMPLETED = OK, LIBUSB_TRANSFER_ERROR,
                    LIBUSB_TRANSFER_TIMED_OUT, LIBUSB_TRANSFER_CANCELLED,
                    LIBUSB_TRANSFER_STALL, LIBUSB_TRANSFER_NO_DEVICE,
                    LIBUSB_TRANSFER_OVERFLOW*/
                    //when there are no error:
                   if (outStH.flagsOfTransfer != LIBUSB_TRANSFER_COMPLETED) {
                        //when error occured during transfer - terminate , free descriptor
                        libusb_free_transfer_d(transferDescritor);
                        outStH.statesMachine = USB_OUT_IDLE;
                        outStH.flagsOfTransfer = 0;
                        return USB_OUT_ERR;
                   }

                   if (outStH.sentBytes == data_length) {
                        //when all he data was sent
                      libusb_free_transfer_d(transferDescritor);
                      outStH.statesMachine = USB_OUT_IDLE;
                      outStH.flagsOfTransfer = 0;
                      return USB_OUT_DONE;
                   }

              }

           //when full data volume has not been transferred yet
           return USB_OUT_PROGRESS;
        break;

     }


  }







///The library-wrapper arund the LibUSB
#include <stdio.h>
#include <stdlib.h>
#include "libusb.h"
#include "usb_wrap.h"
#include <string.h>
#include <windows.h>
#include "libusb_load.h"
#include "ring_fifo.h"
/*
-------OUT------(transmit principle)---in-async--API-in libUSB
One trasaction (packet) - means one callback.
1)Allocate transfer
2)fill bulk transfer by data
3)Submit transfer to the OS kernel
4)Awaiting of callback, read result in the one.Set user data (flags, etc).Nothing more.Exit from calmack
5)Free transfer
6)Read results (sucess , fail)
---IMPORANT--NOTE!!!-----
runs  libusb_handle_events_d(myLibusbCtx);   ONLY AFTER submitting transfer to OS kernel, otherwise
you will have a VERY LONG DELAY (60 seconds) and get stuck.Dont call it before, or without any task (transfer) -
you will have a long delay.


*/

#define EP_OUT 0x01   // endpoint 1 OUT
#define EP_IN  0x81   // endpoint 1 IN

#define USB_VID   0xCafe
#define USB_PID   0x4000
#define USB_BCD   0x0100

uint8_t* fifo_in_buffer;

uint32_t fifo_buffer_length;

//libusb runtime instance. Global library state
libusb_context* myLibusbCtx;

//a handle of a device, that libUSB will open
libusb_device_handle* myDevHandle;
//------------------------------------
struct libusb_transfer * transferOutDescriptor;
struct libusb_transfer * transferInDescriptor;

uint8_t dataTransferBuffer[65535];

int32_t cbStatus;

ring_t inFifoHeader;




//***********the callback************

void  out_callback ( struct libusb_transfer *tr ) {

    transferUsbStatus * transfStat = tr->user_data;
   //1) read status of transfer inside a structure
       transfStat->flagsOfTransfer = tr->status;
    //2)Transfer - done
       transfStat->bulkTransferDone = 1;
    //3)Accumulate received data
         transfStat->sentBytes  = tr->actual_length;

    printf("cb status=%d len=%d\n", tr->status, tr->actual_length);
}


void  in_callback (struct libusb_transfer *tr) {

  transferUsbStatus * transfStat = tr->user_data;

  transfStat->flagsOfTransfer = tr->status;
  if (tr->status == LIBUSB_TRANSFER_COMPLETED) {
        transfStat->bulkTransferDone = 0;
      //when there are no errors
      if (tr->actual_length > 0) {
            //push data into the FIFO
        ring_push(&inFifoHeader,tr->buffer,tr->actual_length);
      }
      //send new transfer to a device
      if(libusb_submit_transfer_d(tr) != 0) {

            transfStat->bulkTransferDone = -1;
        }


  } else {
  transfStat->bulkTransferDone = -1;//error

  }



}


int initLibraryW(uint32_t fifoSize) {

 if (load_libusb() != 0) {
        printf ("Unable to open library!");
        return UNABLE_OPEN_LIB;
 }

  ///init Libusb`s state structure:
  if (libusb_init_d(&myLibusbCtx) != 0 ) {
    return UNABLE_INIT_LIB;
  }

  /////
  fifo_in_buffer = malloc(fifoSize);
  if (fifo_in_buffer == NULL) {
    return UNABLE_ALLOC_MEM_LIB;
  }
  //initialize FIFO
  ring_init(&inFifoHeader, fifo_in_buffer, fifo_buffer_length);
  fifo_buffer_length = fifoSize;
  return INIT_LIB_DONE;
  //////----------


}
///it starts to have IN data continously.When any data arrived, in callback the other transfer runs again
int startInTransfers(transferUsbStatus* inUsrStat) {
    int var1;
 //1)allocate transfer.It will use all the program
 transferInDescriptor  = libusb_alloc_transfer_d(0);
         if (transferInDescriptor == NULL) {
                //when a transfer was not allocated
             inUsrStat->statesMachine = USB_TH_IDLE;
             inUsrStat->flagsOfTransfer = 0;
            return  USB_TH_ERR;
         }
 //2)fill bulk transfer
 libusb_fill_bulk_transfer(
        transferInDescriptor,
        myDevHandle,
        EP_IN,
        dataTransferBuffer, //buffer for libusb IN endpoint
        64,
        in_callback,
        inUsrStat,
        5000
    );
 //3)send to core
         var1 = libusb_submit_transfer_d(transferInDescriptor);
        if (var1 != 0) {
            //when any error occured - report about error
            // libusb_free_transfer_d(transferInDescritor);
             inUsrStat->statesMachine = USB_TH_IDLE;
             inUsrStat->flagsOfTransfer = 0;
            return  USB_TH_ERR;
        }
 //4)set status "transfer in progress"
             inUsrStat->statesMachine = USB_TH_PROGRESS;
             inUsrStat->flagsOfTransfer = 0;
            return  USB_TH_PROGRESS;
}


///!!!!!--IMPORTANT!---Stop IN transfers before application terminated, by this function:
//All the transfers MUST be finished before!
int stopInTransfers(transferUsbStatus* inUsrStat){
    static int state = 0;
    //terminate transfer
    //free transfer
    switch(state){
    case 0:
         libusb_cancel_transfer_d(transferInDescritor);
         state = 1;
         return state;
        break;
    case 1:
        if (inUsrStat->flagsOfTransfer == (LIBUSB_TRANSFER_CANCELLED|LIBUSB_TRANSFER_COMPLETED )) {
            libusb_free_transfer_d(transferInDescriptor);
            state=0;
        }
          return state;

        break;
    }




}

void deInitLibraryW(void) {
    if (myDevHandle) {
        libusb_close_d(myDevHandle); ///close device
    }

    libusb_exit_d(myLibusbCtx);  ///exit libusb
    unload_libusb();
    if (fifo_in_buffer){
        free(fifo_in_buffer);
    }

}

 int openDevice(uint16_t VID, uint16_t PID) {
     //try to open device firstly
     myDevHandle = libusb_open_device_with_vid_pid_d(myLibusbCtx,  VID,  PID);

      if (myDevHandle == NULL) {
            printf("Unable to open device! \n");
        return DEV_NOT_FOUND;
      }
      //claim interface
   if ( libusb_claim_interface_d(myDevHandle, 0) !=0 ){
     printf ("Unable to claim interface! \n");
     return UNABLE_CLAIM_I;
   }

 /* if ( libusb_detach_kernel_driver_d (myDevHandle, 0) !=0 ){
    printf ("Unable to detch driver \n");
    return UNABLE_DEATACH_K;
  }*/
  return 0; //OK

 }



  int writeDataToUsb( uint8_t* dPtr, int data_length, uint8_t* errors ,transferUsbStatus* outUsrStat ) {
   int var1;
     switch ( outUsrStat->statesMachine) {
      case USB_TH_IDLE:
           outUsrStat->sentBytes = 0;
           outUsrStat->bulkTransferDone = 0;
          outUsrStat->flagsOfTransfer = 0;
          //1)fill the libusb structure and plan the transfers of data:
          //Allocate transfer
         transferOutDescriptor = libusb_alloc_transfer_d(0);
         if (transferOutDescriptor == NULL) {
             outUsrStat->statesMachine = USB_TH_IDLE;
             outUsrStat->flagsOfTransfer = 0;
            return  USB_TH_ERR;
         }
         //Then fill transfer:
         libusb_fill_bulk_transfer ( transferOutDescriptor, //Your allocated transfer descriptor.
                                     myDevHandle,  //opened device`s handle
                                     EP_OUT, //endpoint 0x01   OUT, 0x81   IN
                                     dPtr,  //pointer to data to be send
                                     data_length, //length of data to be send
                                     out_callback, //the callback
                                     outUsrStat,  //void* user data
                                     5000 //timeout
                                    );
        //This function will fire off the USB transfer and then return immediately.
        var1 = libusb_submit_transfer_d(transferOutDescriptor);
        if (var1 != 0) {
            //when any error occured - report about error
            *errors = (int)var1;
             libusb_free_transfer_d(transferOutDescriptor);
             outUsrStat->statesMachine = USB_TH_IDLE;
             outUsrStat->flagsOfTransfer = 0;
            return  USB_TH_ERR;
        }
        outUsrStat->statesMachine = USB_TH_PROGRESS; //the structre with taskws sent to the library.It will execute by the kernel in near future
        return  USB_TH_PROGRESS;
        break;
      case USB_TH_PROGRESS:
          if (outUsrStat->bulkTransferDone) {
                    outUsrStat->bulkTransferDone = 0;
                  //reporting about errors-save in the variable
                   *errors = (uint8_t) outUsrStat->flagsOfTransfer;
                   //are there any error?
                    /*LIBUSB_TRANSFER_COMPLETED = OK, LIBUSB_TRANSFER_ERROR,
                    LIBUSB_TRANSFER_TIMED_OUT, LIBUSB_TRANSFER_CANCELLED,
                    LIBUSB_TRANSFER_STALL, LIBUSB_TRANSFER_NO_DEVICE,
                    LIBUSB_TRANSFER_OVERFLOW*/
                    //when there are an error:
                   if (outUsrStat->flagsOfTransfer != LIBUSB_TRANSFER_COMPLETED) {
                        //when error occured during transfer - terminate , free descriptor
                        libusb_free_transfer_d(transferOutDescriptor);
                        outUsrStat->statesMachine = USB_TH_IDLE;
                        outUsrStat->flagsOfTransfer = 0;
                        return USB_TH_ERR;
                   }
                   ///when there are no error:
                   libusb_free_transfer_d(transferOutDescriptor);
                    outUsrStat->statesMachine = USB_TH_IDLE;
                    outUsrStat->flagsOfTransfer = 0;
                   return  USB_TH_DONE;

              }

           //when full data volume has not been transferred yet
           return USB_TH_PROGRESS;
        break;
      default:
        return USB_TH_ERR;

     }


  }







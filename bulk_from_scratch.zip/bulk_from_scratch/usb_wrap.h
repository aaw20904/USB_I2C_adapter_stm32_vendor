#ifndef USB_WRAP_H_INCLUDED
#define USB_WRAP_H_INCLUDED


enum libInit {
 INIT_LIB_DONE,
 UNABLE_OPEN_LIB = -1,
 UNABLE_INIT_LIB = -2,
 UNABLE_ALLOC_MEM_LIB = -3,
};

enum libDevOpen {
 DEV_NOT_FOUND = -1,
 UNABLE_CLAIM_I = -2,
 UNABLE_DEATACH_K = -3,
};

enum usbMyStates {
  USB_TH_IDLE,
  USB_TH_PROGRESS,
  USB_TH_DONE,
  USB_TH_ERR = -1,
};

typedef struct {
   volatile int32_t sentBytes;
   volatile int32_t flagsOfTransfer;
   volatile int32_t statesMachine;
   volatile int32_t bulkTransferDone;
}transferUsbStatus;


int initLibraryW(uint32_t fifoSize);
void deInitLibraryW(void);
int writeDataToUsb( uint8_t* dPtr, int data_length, uint8_t* errors ,transferUsbStatus* outUsrStat );
int openDevice(uint16_t VID, uint16_t PID);
#endif // USB_WRAP_H_INCLUDED

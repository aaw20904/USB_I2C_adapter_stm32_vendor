#ifndef CIRC_FIFO_H_INCLUDED
#define CIRC_FIFO_H_INCLUDED


#include "stdint.h"

typedef struct
{
    uint8_t *buf;
    uint32_t buf_size;
    uint32_t mask;
    uint32_t head;
    uint32_t tail;

} ring_t;

void ring_init(ring_t *r, uint8_t *buffer, uint32_t len);
uint32_t ring_available(ring_t *r);
uint32_t ring_free(ring_t *r);
uint32_t ring_push(ring_t *r, const uint8_t *src, uint32_t len);
uint32_t ring_pop(ring_t *r, uint8_t *dst, uint32_t len);
//read new data without consumption - it is usefull for awaiting full packet
uint32_t ring_peek(ring_t *r, uint8_t *dst, uint32_t len);



#endif // CIRC_FIFO_H_INCLUDED

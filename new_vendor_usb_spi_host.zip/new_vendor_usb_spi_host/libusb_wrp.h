#ifndef LIBUSB_WRP_H_INCLUDED
#define LIBUSB_WRP_H_INCLUDED
#include <stdint.h>


int initLibraryW(void);
int deInitLibraryW(void);
int attachDeviceW (uint16_t vid, uint16_t pid);
int writeUsbToOut (uint8_t* data, uint16_t usize  );
int readUsbFromIn (uint8_t* data, uint16_t usize  );
 int getReadDataLengh(void);
#endif // LIBUSB_WRP_H_INCLUDED

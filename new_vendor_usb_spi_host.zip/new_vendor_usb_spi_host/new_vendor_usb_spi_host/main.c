#include <stdio.h>
#include <stdlib.h>
#include "libusb_wrp.h"

#define VID 0xCafe
#define PID 0x4000


int main()
{
    printf("Hello world!\n");

     if (initLibraryW() != 0){
   printf("The dll file not found!");
    return -1;
 }

  if ( attachDeviceW (VID,   PID) != 0) {
    printf ("Device not found");
    return 1;
  }

   usbWriteAsyncW(0x01,(unsigned char*)"hello word!----",16);
   waitForWriteW();
     // the main thread and execution continue from the next code line
    if (getWriteResultW() == 0)
        printf("Write OK!\n");
    else
        printf("Write FAILED!\n");

    usbReadAsyncW(0x81, 16);

        printf("Waiting for read...\n");
     //When a semaphore not released, the OS kernel stop execution
    //and reassign CPU to another tasks.When a semaphore released - the Kernel wakes up
    waitForReadW();
    // the main thread and execution continue from the next code line
    if (getReadDataLengh() > 0)
    {
        getReadDataLengh();
       printf("%s", getReadBuffer());
        /*

        */
    }
    else
    {
        printf("Read failed!\n");
    }



     deInitLibraryW();

    return 0;
}

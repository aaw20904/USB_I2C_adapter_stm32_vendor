
#include "packetize.h"
#include <string.h>
int packetParcer (packet_params *pars, uint8_t* circBuffer, uint16_t lastWrittenCell) {

	if (lastWrittenCell >= 4) {
		//when packet length have been already received

		            memcpy(pars,circBuffer,4);
		if (lastWrittenCell >= pars->packet_length ) {
			   ///DEBUG_ONLY
            ///copying parameters firstly
			//when full packet was received - copy it into a buffer
            memcpy(pars->data, circBuffer+4, pars->packet_length-4 );
			//- return packet length
			return pars->packet_length;
		}
		return -1;
	}
	return -1;
}
//has all the packet already arrived?
int hasPacketArrived(uint8_t* incomeTraffic, uint32_t arraived) {
   uint16_t len;
   if (arraived >=4 ) {
        len = incomeTraffic[3]; //high
        len <<= 8; //becomes b15-b7
        len |= incomeTraffic[2];
        if (arraived >= len) {
            return 0;
        }
   }
   return -1;
}

//NOTE: no need in internal header structure data buffer - payload copying directly to packetStore
int assemblyPacketInRam(packet_params *pars, uint8_t* payload, uint8_t* packetStore) {
    //type of command, flags, packet size
    memcpy(packetStore,pars,4);
    //when payload exists-copy it into buffer
    if (pars->packet_length > 4) {

        memcpy(packetStore+4, payload, (pars->packet_length - 4) );
    }
    return 0;

}




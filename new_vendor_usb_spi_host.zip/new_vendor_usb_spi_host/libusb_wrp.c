///The library-wrapper arund the LibUSB
#include <stdio.h>
#include <stdlib.h>
#include "libusb.h"
#include "libusb_dyn.h"
#include <string.h>
#include <windows.h>


#define EP_OUT 0x01   // endpoint 1 OUT
#define EP_IN  0x81   // endpoint 1 IN

#define MYUSB_BUFF_L 32768

#include "circ_fifo.h"

#define NUM_TRANSFERS 4
#define READ_BUF_SIZE 64


libusb_context *ctx = NULL;
libusb_device_handle *dev = NULL;
volatile LONG device_connected = 1;

static struct libusb_transfer *read_xfers[NUM_TRANSFERS];
static unsigned char read_bufs[NUM_TRANSFERS][READ_BUF_SIZE];


volatile LONG write_result;

 uint8_t* usbOutDynBuffer = 0;

 int usbOutDynBufferLen = 0;

 uint8_t fifo_x_buffer[32768];

//FIFO  structure, MUST be declared as "extern" in main file

ring_t fifoHeaderGl;

// Async READ semaphore
HANDLE sem_read_done;

// Async WRITE semaphore
HANDLE sem_write_done;

// Background USB events thread
HANDLE usb_thread_handle;
//a thread running flag
volatile int usb_thread_running = 1;



// ----------------- EVENT THREAD -----------------

DWORD WINAPI usb_event_thread (LPVOID param) {
    //This creates a POSIX-style timeout struct:
    //This is fast enough for high-performance USB transfers and slow enough to avoid CPU overload.
    struct timeval tv = {0, 1000}; // 1ms timeout
    //
    while (usb_thread_running)
    {
        //The libusb say to Kernel OS: “Wake me when a USB transfer completes, or after the timeout expires.”
        int r = libusb_handle_events_timeout_d(ctx, &tv);
        //The thread is not running until USB completion events
        //When USB event occured -  libusb wakes up
        if (r != LIBUSB_SUCCESS && r != LIBUSB_ERROR_TIMEOUT)
        {
            printf("libusb_handle_events_timeout error: %s\n",
                   libusb_error_name_d(r));
        }
    }
    return 0;
}


// ----------------- READ CALLBACK -----------------

void LIBUSB_CALL read_callback(struct libusb_transfer *t)
{

    switch(t->status){
      case LIBUSB_TRANSFER_COMPLETED:
          if ((ring_free(&fifoHeaderGl) >= t->actual_length) && device_connected ) {
                ///PUSHING (stacking) NEW DATA INTO FIFO when free space available
                ring_push(&fifoHeaderGl, t->buffer, t->actual_length);
                  //run read transfer request again continously
                 libusb_submit_transfer_d(t);
            } else {
               printf("FIFO overflow\n");
            }
            // notify main thread (unblocks WaitForSingleObject)
          ReleaseSemaphore(sem_read_done, 1, NULL);
        break;
      case LIBUSB_TRANSFER_CANCELLED:
              ReleaseSemaphore(sem_read_done, 1, NULL);
        break;
      case LIBUSB_TRANSFER_NO_DEVICE:
            ReleaseSemaphore(sem_read_done, 1, NULL);
             InterlockedExchange(&device_connected, 0);
             printf("USB device disconnected\n");
        break;
      default:
            printf("USB transfer error %d\n", t->status);
        }


}



// ----------------- WRITE CALLBACK -----------------

void LIBUSB_CALL write_callback(struct libusb_transfer *t)
{
    if (t->status == LIBUSB_TRANSFER_COMPLETED)
    {
        /*printf("[WRITE CALLBACK] Write OK (%d bytes)\n",
               t->actual_length);*/
       // write_result = 0;
       InterlockedExchange(&write_result,0);
    }
    else
    {
        printf("[WRITE CALLBACK] ERROR status=%d\n", t->status);
       InterlockedExchange(&write_result,-1);
    }

    ReleaseSemaphore(sem_write_done, 1, NULL);

    //free(t->buffer); dont need - because of buffer is persistent
    libusb_free_transfer_d(t);
}



 // ----------------- ASYNC READ FUNCTION -----------------
//new function with new logical self-commented name:
//Start read IN stream inside FIFO (IN data consumption to FIFO exists inside the read callback exactly)
int usbStartReadInStreamW(unsigned char ep)
{
    for (int i = 0; i < NUM_TRANSFERS; i++)
    {
        struct libusb_transfer *t = libusb_alloc_transfer_d(0);
        if (!t)
            return -1;

        read_xfers[i] = t;

        libusb_fill_bulk_transfer(
            t,
            dev,
            ep,
            read_bufs[i],
            READ_BUF_SIZE,
            read_callback,
            NULL,
            0
        );

        int r = libusb_submit_transfer_d(t);
        if (r != LIBUSB_SUCCESS)
        {
            printf("submit error: %s\n", libusb_error_name_d(r));
            return -2;
        }
    }

    return 0;
}



//deprecated, must be remove!

int usbReadAsyncW(unsigned char ep)
{
    for (int i = 0; i < NUM_TRANSFERS; i++)
    {
        struct libusb_transfer *t = libusb_alloc_transfer_d(0);
        if (!t)
            return -1;

        read_xfers[i] = t;

        libusb_fill_bulk_transfer(
            t,
            dev,
            ep,
            read_bufs[i],
            READ_BUF_SIZE,
            read_callback,
            NULL,
            0
        );

        int r = libusb_submit_transfer_d(t);
        if (r != LIBUSB_SUCCESS)
        {
            printf("submit error: %s\n", libusb_error_name_d(r));
            return -2;
        }
    }

    return 0;
}

// ----------------- ASYNC WRITE FUNCTION ----------------------


//improved version
int usbWriteAsyncW(unsigned char ep, unsigned char *data, int size) {
    if( usbOutDynBufferLen <= size){
        size = usbOutDynBufferLen-1;
    }
    ///write_result = 0;
    InterlockedExchange(&write_result,0);
    // 1) Allocate a libusb transfer structure
    struct libusb_transfer *t = libusb_alloc_transfer_d(0);
    if (!t){
        //when allocation failed
        return -1;
    }

    //copy data into Tx buffer
    memcpy(usbOutDynBuffer, data, size);
     // 3) Prepare the transfer object (endpoint, buffer, callback, timeout)
    libusb_fill_bulk_transfer(
        t, dev, ep,
        usbOutDynBuffer, size,
        write_callback,
        NULL,
        5000
    );
    // 4) Submit the transfer to libusb/kernel
    int r = libusb_submit_transfer_d(t);
    if (r != LIBUSB_SUCCESS)
    {
        //when an error has happened - free memory and release transfer
        printf("submit write error: %s\n", libusb_error_name_d(r));
        libusb_free_transfer_d(t);
        return -3;
    }

    return 0;
}
// ----------------- WAIT FUNCTIONS -----------------

void waitForReadW(void)
{
    //When a semaphore is not released, The kernel does NOT execute your thread anymore.
    //CPU core immediately gets reassigned to other runnable threads in the system.
    //When a semaphore releases - the scheduler wakes up this thread, and
    //the program continue execution fron the next string (after the  WaitForSingleObject() )
    WaitForSingleObject(sem_read_done, INFINITE);
}

void waitForWriteW(void) {
    //When a semaphore is not released, The kernel does NOT execute your thread anymore.
    //CPU core immediately gets reassigned to other runnable threads in the system.
    //When a semaphore releases - the scheduler wakes up this thread, and
    //the program continue execution fron the next string (after the  WaitForSingleObject() )
    WaitForSingleObject(sem_write_done, INFINITE);
}
// ----------------- THREAD START/STOP -----------------

void start_usb_thread()
{
    usb_thread_running = 1;

   usb_thread_handle = CreateThread(
        NULL,               // security attributes
        0,                  // stack size (0 = default size 1 MB reserved for Windows)
        usb_event_thread,   // thread function
        NULL,               // parameter to thread function
        0,                  // creation flags
        NULL                // receives thread ID
    );

}

void stop_usb_thread()
{
    usb_thread_running = 0;
    WaitForSingleObject(usb_thread_handle, INFINITE);
    Sleep(10); // allow callbacks to finish
    CloseHandle(usb_thread_handle);
}


LONG isDeviceConnected (void) {
  return device_connected;
}


int initLibraryW (void) {
   //load a library dynamically
    if (load_libusb()!=0)
        return -1;
  //initialize the library
    if (libusb_init_d(&ctx) < 0) {
        //printf("libusb_init failed\n");
        return -1;
    }
    //IMPORTANT-----FIFO-initialization
    ring_init(&fifoHeaderGl, fifo_x_buffer, MYUSB_BUFF_L);
     //fifoHeader.buf = read_buf; //physicall buffer for income data fifo
     //fifoHeader.buf_size = MYUSB_BUFF_L;//length of income buffer
    return 0;
}

LONG getWriteResultW(void) {
  return write_result;
}

int deInitLibraryW(void) {
    //cancel and remove read transfers
    for (uint32_t x=0; x< NUM_TRANSFERS; x++) {
         if (read_xfers[x]) {
            libusb_cancel_transfer_d(read_xfers[x]);
         }
    }
     // allow callbacks to execute
    Sleep(50);

    stop_usb_thread();

      // free transfers
    for (uint32_t x = 0; x < NUM_TRANSFERS; x++)
    {
        if (read_xfers[x])
        {
            libusb_free_transfer_d(read_xfers[x]);
            read_xfers[x] = NULL;
        }
    }

    //remove semaphores
    if (sem_read_done) {
        CloseHandle(sem_read_done);
    }

    if (sem_write_done) {
        CloseHandle(sem_write_done);
    }
    sem_read_done = NULL;
    sem_write_done = NULL;

    //relese USB interface 0
    if (dev) {
       libusb_release_interface_d(dev, 0);
       libusb_close_d(dev);
       dev = NULL;
    }
    //free OUT memory
    if (usbOutDynBuffer){
        free(usbOutDynBuffer);
    }
    usbOutDynBuffer = NULL;
    usbOutDynBufferLen =0;

    libusb_exit_d(ctx);
    //close DLL and free memory that was busy for DLL functions

    unload_libusb();
    return 0;

}
 //wen a device was lost - plugged out, call it to reconnect
 //check - if the device lost, call it periodically,
 //and after success usbStartReadInStreamW(unsigned char ep) to read IN stream inside FIFO
int reAttachDeviceW(uint16_t vid, uint16_t pid) {
     //open a device with given PID, VID
    dev = libusb_open_device_with_vid_pid_d (ctx, vid, pid);
    InterlockedExchange(&device_connected, 1);
    if (!dev) {
       InterlockedExchange(&device_connected, 0);
        printf ("Device not found\n");
        return 1;
    }
   /*
   this function checking
   - is a device driver was assigned to a device by OS
   - Choose the concrete interface (parameter 2) by sending a SETUP packet to a device.
   NOTE: The interface number can be assigned by a device developer.
       The endpoint 0 not need to be claimed.A device must have mandatory at teast one interface
       , for example easy USB device has one interface of only one IN OUT pair of bulk endpoints.
   */

   //for Linux
   if (libusb_kernel_driver_active_d(dev, 0) == 1) {
      libusb_detach_kernel_driver_d(dev, 0);
    }

    if ( libusb_claim_interface_d(dev, 0) < 0) {
        printf("Cannot claim interface 0\n");
        return 1;
    }
    return 0;
}

int attachDeviceW (uint16_t vid, uint16_t pid, int outBufferLength) {
        //open a device with given PID, VID
    dev = libusb_open_device_with_vid_pid_d (ctx, vid, pid);
    InterlockedExchange(&device_connected, 1);
    if (!dev) {
        InterlockedExchange(&device_connected, 0);
        printf ("Device not found\n");
        return 1;
    }
   /*
   this function checking
   - is a device driver was assigned to a device by OS
   - Choose the concrete interface (parameter 2) by sending a SETUP packet to a device.
   NOTE: The interface number can be assigned by a device developer.
       The endpoint 0 not need to be claimed.A device must have mandatory at teast one interface
       , for example easy USB device has one interface of only one IN OUT pair of bulk endpoints.
   */

   //for Linux
   if (libusb_kernel_driver_active_d(dev, 0) == 1) {
      libusb_detach_kernel_driver_d(dev, 0);
    }

    if ( libusb_claim_interface_d(dev, 0) < 0) {
        printf("Cannot claim interface 0\n");
        return 1;
    }

     // Create semaphores with initial count = 0
    sem_read_done = CreateSemaphore(NULL, 0, LONG_MAX, NULL);

    sem_write_done = CreateSemaphore(NULL, 0, LONG_MAX, NULL);

     // Start USB background thread

     usb_thread_running = 1;
     usb_thread_handle = CreateThread(NULL, 0,
                                     usb_event_thread,
                                     NULL, 0, NULL);
    //allocate OUT buffer for out going messages
    if (!usbOutDynBuffer) {
        usbOutDynBuffer = malloc(outBufferLength);
        if (!usbOutDynBuffer) {
            printf("OUT buffer allocation failed\n");
            return -3;
        }
        usbOutDynBufferLen = outBufferLength;
    }

      //when SUCCESS
    return 0;
}

uint8_t* getReadBuffer(void){
  return fifo_x_buffer;
}
//=======new functions===========
int writeUsbToOut (uint8_t* udata, uint16_t usize  ) {
   if (!device_connected){
      return -10;
    }
   int r = usbWriteAsyncW(0x01, udata, usize);
    if (r < 0) {
      return r;
    }

   waitForWriteW();
     // the main thread and execution continue from the next code line
    return write_result;
   //wnen 0 - it means "success"
}





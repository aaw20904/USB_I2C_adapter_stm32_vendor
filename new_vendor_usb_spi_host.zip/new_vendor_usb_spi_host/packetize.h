#ifndef PACKETIZE_H_INCLUDED
#define PACKETIZE_H_INCLUDED
#include  "stdint.h"
typedef struct {
    uint8_t type_of_command;
    uint8_t flags;
    uint16_t packet_length;
    uint8_t *data;
}packet_params;

int assemblyPacketInRam(packet_params *pars, uint8_t* payload, uint8_t* packetStore);
int hasPacketArrived(uint8_t* incomeTraffic, uint32_t arraived);
int packetParcer (packet_params *pars, uint8_t* circBuffer, uint16_t dataAval);

#define PACKET321_PAYLOAD      1
#define PACKET321_ACKNOWLEDGE  2

#define PACKET321_STATUS_OK    1
#define PACKET321_STATUS_FAIL  2
#endif // PACKETIZE_H_INCLUDED

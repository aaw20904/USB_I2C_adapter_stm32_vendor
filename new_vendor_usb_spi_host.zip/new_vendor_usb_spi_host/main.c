#include <stdio.h>
#include <stdlib.h>
#include "libusb_wrp.h"

#define VID 0xCafe
#define PID 0x4000

FILE* textFile;
uint8_t text_string[2048];
uint8_t infoForExchange[2048];

int main()
{

    textFile = fopen("mytext.txt","rb");
    if (textFile == NULL) {
        printf("text File not found!");
        return -1;
    }

    printf("Hello world!\n");

     if (initLibraryW() != 0){
   printf("The dll file not found!");
    return -1;
 }

  if ( attachDeviceW (VID,   PID) != 0) {
    printf ("Device not found");
    return 1;
  }

   fread(infoForExchange,512,1,textFile);

   writeUsbToOut(infoForExchange,512);

   readUsbFromIn(text_string,512);

   printf("\n ===FIRST STRING===> \n %.512s \n",text_string);



   fread(infoForExchange,512,1,textFile);

   writeUsbToOut(infoForExchange,512);

   readUsbFromIn(text_string,512);

   printf("\n ==SECOND STRING==> \n %.512s \n",text_string);


    fread(infoForExchange,512,1,textFile);

   writeUsbToOut(infoForExchange,512);

   printf("\n ==THIRD STRING==> \n %.512s \n",text_string);


   fread(infoForExchange,512,1,textFile);

   writeUsbToOut(infoForExchange,512);
   printf("\n ==FOURTH STR==> \n %.512s  \n",text_string);
   fclose(textFile);


     deInitLibraryW();
     getchar();

    return 0;
}

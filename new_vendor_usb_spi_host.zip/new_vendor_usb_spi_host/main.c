#include <stdio.h>
#include <stdlib.h>
#include "libusb_wrp.h"
#include "string.h"
#define VID 0xCafe
#define PID 0x4000
#include "packetize.h"
#include "circ_fifo.h"

FILE* textFile;
uint8_t text_string[2048];
uint8_t dbg_string[2048];
uint32_t writtenInData;
uint8_t infoForExchange[2048];
uint8_t* inUsbPayload[1024];
uint8_t* outUsbPayload[1024];
uint8_t test_msg []={0x01,0x00,0x01,0x32,0x41 ,0x6C ,0x69 ,0x63 ,0x65 ,0x20 ,0x77 ,0x61 ,0x73 ,0x20 ,0x62 ,0x65 ,0x67,
0x69 ,0x6E ,0x6E ,0x69 ,0x6E ,0x67 ,0x20 ,0x74 ,0x6F ,0x20 ,0x67 ,0x65 ,0x74 ,0x20 ,0x76 ,0x65 ,0x72 ,0x79 ,0x20 ,0x74 ,0x69,
0x72 ,0x65 ,0x64 ,0x20 ,0x6F ,0x66 ,0x20 ,0x73 ,0x69 ,0x74 ,0x74 ,0x69 ,0x6E ,0x67 ,0x20 ,0x62 ,0x79 ,0x20 ,0x68 ,0x65 ,0x72,
0x20 ,0x73 ,0x69 ,0x73 ,0x74 ,0x65 ,0x72 ,0x20 ,0x6F ,0x6E ,0x20 ,0x74 ,0x68 ,0x65 ,0x20 ,0x62 ,0x61 ,0x6E ,0x6B ,0x2C ,0x20,
 0x61 ,0x6E ,0x64 ,0x20 ,0x6F ,0x66 ,0x20 ,0x68 ,0x61 ,0x76 ,0x69 ,0x6E ,0x67 ,0x20 ,0x6E ,0x6F ,0x74 ,0x68 ,0x69 ,0x6E,
 0x67 ,0x20 ,0x74 ,0x6F ,0x20 ,0x64 ,0x6F ,0x3A ,0x20 ,0x6F ,0x6E ,0x63 ,0x65 ,0x20 ,0x6F ,0x72 ,0x20 ,0x74 ,0x77 ,0x69,
 0x63 ,0x65 ,0x20 ,0x73 ,0x68 ,0x65 ,0x20 ,0x68 ,0x61 ,0x64 ,0x20 ,0x70 ,0x65 ,0x65 ,0x70 ,0x65 ,0x64 ,0x20 ,0x69 ,0x6E,
  0x74 ,0x6F ,0x20 ,0x74 ,0x68 ,0x65 ,0x20 ,0x62 ,0x6F ,0x6F ,0x6B ,0x20 ,0x68 ,0x65 ,0x72 ,0x20 ,0x73 ,0x69 ,0x73 ,0x74,
  0x65 ,0x72 ,0x20 ,0x77 ,0x61 ,0x73 ,0x20 ,0x72 ,0x65 ,0x61 ,0x64 ,0x69 ,0x6E ,0x67 ,0x2C ,0x20 ,0x62 ,0x75 ,0x74 ,0x20 ,0x69 ,0x74,
  0x20 ,0x68 ,0x61 ,0x64 ,0x20 ,0x6E ,0x6F ,0x20 ,0x70 ,0x69 ,0x63 ,0x74 ,0x75 ,0x72 ,0x65 ,0x73 ,0x20 ,0x6F ,0x72 ,0x20,
  0x63 ,0x6F ,0x6E ,0x76 ,0x65 ,0x72 ,0x73 ,0x61 ,0x74 ,0x69 ,0x6F ,0x6E ,0x73 ,0x20 ,0x69 ,0x6E ,0x20 ,0x69 ,0x74,
  0x2C ,0x20 ,0x20 ,0x1C ,0x61 ,0x6E ,0x64 ,0x20 ,0x77 ,0x68 ,0x61 ,0x74 ,0x20 ,0x69 ,0x73 ,0x20 ,0x74 ,0x68 ,0x65 ,0x20,
  0x75 ,0x73 ,0x65 ,0x20 ,0x6F ,0x66 ,0x20 ,0x61 ,0x20 ,0x62 ,0x6F ,0x6F ,0x6B ,0x2C ,0x20 ,0x1D ,0x20 ,0x74 ,0x68 ,0x6F,
  0x75 ,0x67 ,0x68 ,0x74 ,0x20 ,0x41 ,0x6C ,0x69 ,0x63 ,0x65 ,0x20 ,0x20 ,0x1C ,0x77 ,0x69 ,0x74 ,0x68 ,0x6F ,0x75 ,0x74,
  0x20 ,0x70 ,0x69 ,0x63 ,0x74 ,0x75 ,0x72 ,0x65 ,0x73 ,0x20 ,0x6F ,0x72 ,0x20 ,0x63 ,0x6F ,0x6E ,0x76 ,0x65 ,0x72 ,0x73,
  0x61 ,0x74 ,0x69 ,0x6F ,0x6E ,0x73 ,0x3F ,0x20 ,0x1D}; //306 total

  /*
  [OPCODE_8| FLAGS_8 | PACKET_LENGTH_LSB_8 | PACKET_LENGTH_MSB_8 | DATA]
  **/
uint32_t parcel_len = 10;
uint8_t  circularInBuffer[2048];
uint8_t* circularInBufferLastCell;
uint8_t* circularBufferCurrentPosition;

uint8_t* circularOutBuffer[2048];

uint8_t fullPacketIn[2048];
uint8_t payloadStoreIn[1024];
uint16_t *circularInPtr;

uint8_t fullPacketOut[2048];
uint8_t payloadStoreOut[1024];
uint16_t *circularOutPtr;

extern ring_t fifoHeader;



packet_params parametersOfInPacket,parametersOfOutPacket;



int main()
{
    parametersOfInPacket.data = (uint8_t*)inUsbPayload;
    parametersOfOutPacket.data = (uint8_t*)outUsbPayload;
    parametersOfInPacket.type_of_command =  PACKET321_PAYLOAD;
    parametersOfInPacket.flags = 0; //no flags
    parametersOfInPacket.packet_length = 20;
    assemblyPacketInRam(&parametersOfInPacket,"Hello From Linux!", fullPacketIn);
    hasPacketArrived(fullPacketIn,20);
    parametersOfInPacket.packet_length=0;
    parametersOfInPacket.type_of_command=0;
    memset(parametersOfInPacket.data,0,32);
    packetParcer(&parametersOfInPacket,fullPacketIn,20);
    return 0;


    printf("enter paclet length \n");
    scanf("%d",&parcel_len);

    textFile = fopen("mytext.txt","rb");
    if (textFile == NULL) {
        printf("text File not found!");
        return -1;
    }

    printf("Hello world!\n");

     if (initLibraryW() != 0){
   printf("The dll file not found!");
    return -1;
 }

  if ( attachDeviceW (VID,   PID) != 0) {
    printf ("Device not found");
    return 1;
  }

   fread(payloadStoreOut, 256, 1, textFile);
   //assign type of packet, payload size, flags
   parametersOfOutPacket.type_of_command = 0x01;
   parametersOfOutPacket.flags = 0x00;
   parametersOfOutPacket.packet_length = 4 + 256;
   parametersOfOutPacket.data = payloadStoreOut;
  // assemblyPacketInRam(&parametersOfOutPacket,fullPacketOut);
   writeUsbToOut(fullPacketOut, parametersOfOutPacket.packet_length);
   readUsbFromIn(text_string, 256+4);
   writtenInData = getReadDataLengh();
   printf("%d \n",packetParcer(&parametersOfInPacket,text_string, writtenInData));
   printf("\n ===FIRST STRING===> \n %.512s \n",parametersOfInPacket.data);


      fread(payloadStoreOut, 256, 1, textFile);
   //assign type of packet, payload size, flags
   parametersOfOutPacket.type_of_command = 0x01;
   parametersOfOutPacket.flags = 0x00;
   parametersOfOutPacket.packet_length = 4 + 256;
   parametersOfOutPacket.data = payloadStoreOut;
  // assemblyPacketInRam(&parametersOfOutPacket,fullPacketOut);
   writeUsbToOut(fullPacketOut, parametersOfOutPacket.packet_length);
   readUsbFromIn(text_string, 256+4);
   writtenInData = getReadDataLengh();
   printf("%d \n",packetParcer(&parametersOfInPacket,text_string, writtenInData));
   printf("\n ===SECOND STRING===> \n %.512s \n",parametersOfInPacket.data);

      fread(payloadStoreOut, 256, 1, textFile);
   //assign type of packet, payload size, flags
   parametersOfOutPacket.type_of_command = 0x01;
   parametersOfOutPacket.flags = 0x00;
   parametersOfOutPacket.packet_length = 4 + 256;
   parametersOfOutPacket.data = payloadStoreOut;
 //  assemblyPacketInRam(&parametersOfOutPacket,fullPacketOut);
   writeUsbToOut(fullPacketOut, parametersOfOutPacket.packet_length);
   readUsbFromIn(text_string, 256+4);
   writtenInData = getReadDataLengh();
   printf("%d \n",packetParcer(&parametersOfInPacket,text_string, writtenInData));
   printf("\n ===FIRST STRING===> \n %.512s \n",parametersOfInPacket.data);


      fread(payloadStoreOut, 256, 1, textFile);
   //assign type of packet, payload size, flags
   parametersOfOutPacket.type_of_command = 0x01;
   parametersOfOutPacket.flags = 0x00;
   parametersOfOutPacket.packet_length = 4 + 256;
   parametersOfOutPacket.data = payloadStoreOut;
 //  assemblyPacketInRam(&parametersOfOutPacket,fullPacketOut);
   writeUsbToOut(fullPacketOut, parametersOfOutPacket.packet_length);
   readUsbFromIn(text_string, 256+4);
   writtenInData = getReadDataLengh();
   printf("%d \n",packetParcer(&parametersOfInPacket,text_string, writtenInData));
   printf("\n ===Thrid STRING===> \n %.512s \n",parametersOfInPacket.data);
 goto xxx1;


xxx1:
   fclose(textFile);


     deInitLibraryW();
     getchar();

    return 0;
}

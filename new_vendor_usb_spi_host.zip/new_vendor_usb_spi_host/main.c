#include <stdio.h>
#include <stdlib.h>
#include "libusb_wrp.h"

#define VID 0xCafe
#define PID 0x4000

FILE* textFile;
uint8_t text_string[2048];
uint8_t infoForExchange[2048];

uint32_t parcel_len = 10;

int main()
{
    printf("enter paclet length \n");
    scanf("%d",&parcel_len);

    textFile = fopen("mytext.txt","rb");
    if (textFile == NULL) {
        printf("text File not found!");
        return -1;
    }

    printf("Hello world!\n");

     if (initLibraryW() != 0){
   printf("The dll file not found!");
    return -1;
 }

  if ( attachDeviceW (VID,   PID) != 0) {
    printf ("Device not found");
    return 1;
  }

   fread(infoForExchange,parcel_len,1,textFile);

   writeUsbToOut(infoForExchange,parcel_len);

   readUsbFromIn(text_string,parcel_len);

   printf("\n ===FIRST STRING===> \n %.512s \n",text_string);


   fread(infoForExchange,parcel_len,1,textFile);

   writeUsbToOut(infoForExchange,parcel_len);

   readUsbFromIn(text_string,parcel_len);

   printf("\n ==SECOND STRING==> \n %.512s \n",text_string);


    fread(infoForExchange,parcel_len,1,textFile);

   writeUsbToOut(infoForExchange,parcel_len);

    readUsbFromIn(text_string,parcel_len);

   printf("\n ==THIRD STRING==> \n %.512s \n",text_string);


   fread(infoForExchange,parcel_len,1,textFile);

   writeUsbToOut(infoForExchange,parcel_len);
    readUsbFromIn(text_string,parcel_len);
   printf("\n ==FOURTH STR==> \n %.512s  \n",text_string);
   fclose(textFile);


     deInitLibraryW();
     getchar();

    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include "libusb_wrp.h"

#define VID 0xCafe
#define PID 0x4000


uint8_t text_string[2048];


int main()
{
    printf("Hello world!\n");

     if (initLibraryW() != 0){
   printf("The dll file not found!");
    return -1;
 }

  if ( attachDeviceW (VID,   PID) != 0) {
    printf ("Device not found");
    return 1;
  }


   writeUsbToOut((uint8_t*)" Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, 'and what is the use of a book,' thought Alice 'without pictures or conversations?'So she was considering in her own mind (as well as she could, for the hot day made her feel very sleepy and stupid), whether the pleasure of making a daisy-chain would be worth the trouble of getting up a 1234",512);

   readUsbFromIn(text_string,512);

   printf("%s \n",text_string);


      writeUsbToOut((uint8_t*)" Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, 'and what is the use of a book,' thought Alice 'without pictures or conversations?'So she was considering in her own mind (as well as she could, for the hot day made her feel very sleepy and stupid), whether the pleasure of making a daisy-chain would be worth the trouble of getting up a 1234",512);

   readUsbFromIn(text_string,512);

   printf("%s \n",text_string);


         writeUsbToOut((uint8_t*)" Alice was beginning to get very tired of sitting by her sister on the bank, and of having nothing to do: once or twice she had peeped into the book her sister was reading, but it had no pictures or conversations in it, 'and what is the use of a book,' thought Alice 'without pictures or conversations?'So she was considering in her own mind (as well as she could, for the hot day made her feel very sleepy and stupid), whether the pleasure of making a daisy-chain would be worth the trouble of getting up a 1234",512);

   readUsbFromIn(text_string,512);

   printf("%s \n",text_string);


     deInitLibraryW();

    return 0;
}
